var newOwner = ObjectId("5e183a7c43743c525ee74394");
var oldOwner = ObjectId("5a0ad27850232a3651857b22");
// noinspection SpellCheckingInspection
var dashOid = ObjectId("5a37b02a32a28e7371cfefe7");

db.getCollection('dashboards').updateMany(
    { "shares.shareId": newOwner, oid: dashOid },
    { "$set": { "shares.$.shareId": oldOwner  } }
);
db.getCollection('dashboards').updateMany(
    { "shares.shareId": oldOwner, oid: dashOid },
    { "$set": { "shares.$.shareId": newOwner  } }
);


db.getCollection('dashboards').find({ oid: dashOid, userId: newOwner }).forEach(function (dash) {
    db.getCollection('dashboards').updateOne(
        { _id: dash._id },
        { $set: { userId: oldOwner } },
        { upsert: true }
    );
});
db.getCollection('dashboards').find({ oid: dashOid, userId: oldOwner }).forEach(function (dash) {
    db.getCollection('dashboards').updateOne(
        { _id: dash._id },
        { $set: { userId: newOwner } },
        { upsert: true }
    );
});
db.getCollection('dashboards').find({ oid: dashOid }).forEach(function (dash) {
    db.getCollection('dashboards').updateOne(
        { _id: dash._id },
        { $set: { owner: newOwner } },
        { upsert: true }
    );
});

db.getCollection('widgets').find({ dashboardid: dashOid, userId: newOwner }).forEach(function (widget) {
    db.getCollection('widgets').updateOne(
        { _id: widget._id },
        { $set: { userId: oldOwner } },
        { upsert: true }
    );
});
db.getCollection('widgets').find({ dashboardid: dashOid }).forEach(function (widget) {
    db.getCollection('widgets').updateOne(
        { _id: widget._id },
        { $set: { owner: newOwner } },
        { upsert: true }
    );
});
