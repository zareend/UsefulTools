var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');


var revisionsCollection = prismWebDB.getCollection('elasticubeRevisions');

revisionsCollection.aggregate([
    { $sort: { _id: 1 } },
    {
        $group: {
            _id: '$elasticube.oid',
            title: { $last: '$elasticube.title' },
            lastRevision: { $last: '$oid' }
        }
    }
]).forEach(function (revisionToKeep) {
    if (!revisionToKeep) {
        print('there were no revisions');
        return;
    }


    print('');
    print('deleting revisions for ' + revisionToKeep.title + ' (' + revisionToKeep._id + ')');
    print('keeping last revision: ' + revisionToKeep.lastRevision);

    var result = revisionsCollection.deleteMany(
        { 'elasticube.oid': revisionToKeep._id, oid: { $ne: revisionToKeep.lastRevision } });

    if (result.deletedCount === 0) {
        print('nothing to delete for this elasticube');

        return;
    }

    print('deleted ' + result.deletedCount + ' revisions for ' + revisionToKeep._id);
});