// Set orphaned groups

var orphanedGroups = [
'5d5cf34ce6b8150029ef4df4',
'5d5d0a3ddd7f7400299780f2',
'5d5d1830e6b8150029ef4df9'
];

print(`Found ${orphanedGroups.length} orphaned groups.`);

// Change to relevant DB
var prismWebDB = db.getSiblingDB('prismWebDB');

var dataSecurityRulesBeforeDeletion = prismWebDB.getCollection('dataContext').count();
print(`Found ${dataSecurityRulesBeforeDeletion} data security rules prior to cleanup`);

// Iterate over all rules
orphanedGroups.forEach(group => {
    
    var dsRulesToBeDeleted = prismWebDB.getCollection('dataContext').find({shares: {$elemMatch: {partyId: ObjectId(group)}}}).toArray();
    print(`Found ${dsRulesToBeDeleted.length} data security rules for orphaned group ${group}`);
    
    dsRulesToBeDeleted.forEach(rule => {
        var ruleShares = rule.shares;
        
        // Check whether the rule has only the orphaned group as a share
        // If it has more than one share then remove only the orphaned group from the shares
        // If it doesn't, delete the rule completely
        
        var response;
        if(ruleShares.length > 1){
            print(`rule ${rule._id} has more than one share. Updating rule to remove particular group...`);
            response = prismWebDB.getCollection('dataContext').update({ $pull: { shares: { partyId: ObjectId(group) } } });
            
        } else {
            print(`rule ${rule._id} has only one share. Removing...`);
            response = prismWebDB.getCollection('dataContext').remove({_id: rule._id});
            
        }
        
        print(`Removal response: ${JSON.stringify(response)}`);
        
    })
    
});



dataSecurityRulesBeforeDeletion = prismWebDB.getCollection('dataContext').count();

print(`Found ${dataSecurityRulesBeforeDeletion} data security rules after cleanup`);