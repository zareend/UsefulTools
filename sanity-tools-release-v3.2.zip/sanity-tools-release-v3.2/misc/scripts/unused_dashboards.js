var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

// Set the number of days you'd like to compare
var daysBack = 730;
var dateToCompare = new Date();
dateToCompare.setDate(dateToCompare.getDate() - daysBack);
print('Find all last opened before ' + dateToCompare);
var unusedDashboards = prismWebDB.dashboards.find(
    { lastUsed: { $lt: dateToCompare } },
    { title: 1, _id: -1, oid: 1, created: 1, lastUsed: 1, instanceType: 1, owner: 1 }
    ).toArray();

var cleanResults = [];
unusedDashboards.forEach(function(dashboard) {
    var obj = {};
    obj._id = dashboard._id.valueOf();
    obj.dashboardId = dashboard.oid.valueOf();
    var ownerId = dashboard.owner;
    var owner = prismWebDB.users.findOne({ _id: ownerId });
    if (owner){
        obj.owner = owner.userName;
    } else {
        print('No owner ' + ownerId);
        obj.owner = ownerId;
    }
    obj.createdDate = dashboard.created;
    obj.lastUsed = dashboard.lastUsed;
    obj.type = dashboard.instanceType === 'owner' ? 'Original' : 'Shared';
    print(JSON.stringify(obj, null, 2));
    cleanResults.push(obj);
});
print('Unused dashboards: ' + cleanResults.length + ' in last ' + daysBack + ' days');
//printjson(cleanResults);