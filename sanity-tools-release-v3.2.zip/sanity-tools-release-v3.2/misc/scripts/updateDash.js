var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

function replaceDatasource (datasource) {
        if (datasource.fullname){
            datasource.fullname = datasource.fullname.replace("10.50.6.13", "LocalHost");
        }
        if (datasource.id){
            datasource.id = datasource.id.replace("a10LgAa50LgAa6LgAa13_a", "aLOCALHOST_a");
        }

        if (datasource.address){
            datasource.address = datasource.address.replace("10.50.6.13", "LocalHost");
        }
    return datasource;
}

try {
    prismWebDB.getCollection('dashboards').find({}).forEach(function(e) {
        if (e.datasource){
            e.datasource = replaceDatasource(e.datasource);
        }
        if (e.widgets) {
            e.widgets.forEach(function(r) {
                if (r.datasource){
                    r.datasource = replaceDatasource(r.datasource);
                }

                if (r.metadata && r.metadata.panels && r.metadata.panels.items) {
                    r.metadata.panels.items.forEach(function(h){
                        if (h.jaql && h.jaql.datasource) {
                            h.jaql.datasource = replaceDatasource(h.jaql.datasource);
                        }
                    });
                }

            });
        }
        if (e.filters) {
            e.filters.forEach(function(r) {
                if(r.jaql){
                    var datasource = r.jaql.datasource;
                }
                else {
                    print('no r.jaql')
                }

                if (datasource){
                    replaceDatasource(datasource);
                }

                if(r.levels){
                    r.levels.forEach(function(level) {
                        var levelDatasource = level.datasource;
                        if (levelDatasource){
                            replaceDatasource(levelDatasource);
                        }
                    })
                }
            });
        }
        if (e.defaultFilters) {
            e.defaultFilters.forEach(function(r) {
                if(r.jaql){
                    var datasource = r.jaql.datasource;
                }
                else {
                    print('no r.jaql')
                }
                if (datasource){
                    replaceDatasource(datasource);
                }
                if(r.levels){
                    r.levels.forEach(function(level) {
                        var levelDatasource = level.datasource;
                        if (levelDatasource){
                            replaceDatasource(levelDatasource);
                        }
                    })
                }

            });
        }

        prismWebDB.getCollection('dashboards').save(e);
   });
} catch (e){
   print (e);
}


try {
   prismWebDB.getCollection('widgets').find({}).forEach(function(e) {
       if (e.datasource){
            e.datasource = replaceDatasource(e.datasource);

       }
           if (e.metadata && e.metadata.panels && e.metadata.panels.items)
               e.metadata.panels.items.forEach(function(h){
                   if (h.jaql && h.jaql.datasource) {
                            h.jaql.datasource = replaceDatasource(h.jaql.datasource);
                    }
               });
       prismWebDB.getCollection('widgets').save(e);
   });
} catch(error) {
     print(error);
}
