var dashMap = [];
var dashOidMap = [];

var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');
prismWebDB.getCollection('widgets')
    .find({ userId: null, instanceType: { $nin: ['proxy'] } })
    .forEach(function (widget) {
        print(widget.dashboardid + ' ' + widget.created + ' ' + widget.instanceType);
        if (dashMap.indexOf(widget.dashboardid.str) === -1) {
            dashMap.push(widget.dashboardid.str);
            dashOidMap.push(widget.dashboardid);
        }

    });

function getUserName(oid) {
    var result = prismWebDB.users.find({ _id: oid })[0];
    if (result) {
        return result.userName;
    } else {
        //print(oid)
        return 'user doesn\'t exist';
    }
}

function getGroupName(oid) {

    return prismWebDB.groups.find({ _id: oid })[0].name;

}

function getFolderName(oid) {

    var id = new ObjectId(oid);

    return prismWebDB.tags.find({ oid: id })[0].name;

}

print(JSON.stringify(dashMap, null, 2));
prismWebDB.getCollection('dashboards')
    .find({ oid: { $in: dashOidMap, instanceType: { $nin: ['proxy'] } } })
    .forEach(function (d) {
        d.userName = getUserName(d.userId);
        d.ownerName = getUserName(d.owner);
        try {

            if (d.parentFolder) {

                d.parentFolder = getFolderName(d.parentFolder);

            }

        } catch (e) {}

        d.shares.forEach(function (s) {

            if (s.type === 'user') {

                //s.shareId = getUserName(s.shareId);

            } else {

                s.shareId = getGroupName(s.shareId);

            }

        });

        //print(JSON.stringify(d));
        var msg = 'dash (_id): ' + d._id +
            ' (title): ' + d.title +
            ' (owner): ' + d.owner +
            ' (ownerName): ' + d.ownerName +
            ' (user): ' + d.userId +
            ' (userName): ' + d.userName +
            ' (instance): ' + d.instanceType;
        //+ ' has lastPublish: ' + d.lastPublish
        // ;
        print(msg);

    });