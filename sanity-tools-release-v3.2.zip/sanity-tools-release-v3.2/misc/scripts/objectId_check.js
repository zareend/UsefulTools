var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

var collections = prismWebDB.getCollectionNames();

collections.forEach((collection) => {

    var currentCollection = prismWebDB.getCollection(collection);

    var invalidDocs = currentCollection.find({ '_id': { $not: { $type: 7 } } }).toArray();
    if (invalidDocs.length > 0) {
        print('Collection ' + collection + ' has ' + invalidDocs.length + ' invalid objects');
        print(invalidDocs);
    }
});