// General Info
var version = '3.1.3';

if (global._babelPolyfill) {
    throw new Error('only one instance of babel-polyfill is allowed');
}
global._babelPolyfill = true;
