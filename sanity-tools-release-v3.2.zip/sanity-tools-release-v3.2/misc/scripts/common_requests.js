var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

/*
Update server list for Elasticube Sets
Script Collapse source
 */

var servers = ['sisense1.ost.com/', 'sisense2.ost.com/'];

prismWebDB.getCollection('elasticubes').find({ routingMode: { $exists: true } }).forEach(function (set) {
    prismWebDB.elasticubes.update(
        { _id: set._id },
        { $addToSet: { fullNames: { $each: [servers[0], servers[1]] } } }
    );
});
/*
Query all dashboards that their datasource is not an Elasticube Set
Script Collapse source
*/
prismWebDB.getCollection('dashboards')
    .find({ 'datasource.fullname': { $not: /Set/ } })
    .forEach(function (dashboard) {
        print(
            'Dashboard Title: ' + dashboard.title + '\nDatasource: ' + dashboard.datasource.title +
            '\n---------------------------------\n');
    });

// Finding duplicate usernames
// Script Collapse source
prismWebDB.getCollection('users').aggregate([
    { $group: { _id: '$userName', count: { $sum: 1 } } },
    { $match: { count: { $gt: 1 } } }]);
