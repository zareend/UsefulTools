var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

function getUserById(userId){
    return prismWebDB.users.find({_id: userId}).toArray()[0];
}
function getGroupById(groupId){
    return prismWebDB.groups.find({_id: groupId}).toArray()[0];
}
function printDashboardShares(job, dashboard){
    print(dashboard.title);
    dashboard.shares.forEach(function(share){
        if (share.type === 'user'){
            var user = getUserById(share.shareId);
            print('Job ' + job._id.str + ' of dashboard oid:' + dashboard.oid.str + ' is shared to user (userName:"' + user.userName + '", email:"' + user.email + '")');
        } else if (share.type === 'group'){
            var group = getGroupById(share.shareId);
            print('Job ' + job._id.str + ' of dashboard oid:' + dashboard.oid.str + ' is shared to group (name:"' + group.name+ '")');
        }
    });
    print()
}
prismWebDB.jobs.find({jobType: 'dashboardSubscription', active: true}).forEach(function(job){
    //print(job);
    var dashboardQuery = prismWebDB.dashboards.find({oid: ObjectId(job.dashboardId), instanceType: 'proxy'}).limit(1);
    if (dashboardQuery.hasNext()){
        var dash = dashboardQuery.toArray()[0];
        printDashboardShares(job, dash);
    } else {
        print('---------------------------------------------------------------------------------------------------------------------------------');
        print('dashboard ' + job.dashboardId + ' does not exists but has an active job. it is recommend to delete this job (' + job._id + ')');
        print('db.jobs.find({_id: ObjectId("' + job._id.str + '")});');
    }
});