/**
 * Created by yaroslav.korzh
 * Updated 16/12/2019
 */
// General Info
var version = '3.1.3';
var scriptName = 'Test scripts';

// Configuration
var showLogs = true;
var doCleanup = false;
var globalCleanup;
if (typeof cleanup !== 'undefined') {
    doCleanup = cleanup;
    globalCleanup = doCleanup;
}

var scriptsList = [
    'indexes_check.js',
    //'unused_dashboards.js'
];


//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

var globalRun = true;
var collectedStats = {};

var startDate = new Date();
var endDate;
var showDBStats = true;

var logsStatus = getStatus(showLogs);
var cleanupStatus = getStatus(doCleanup);
prismWebDB.stats(1024);

function preRun() {
    prismWebDB.adminCommand(
        { 'setParameter': 1, 'internalQueryExecMaxBlockingSortBytes': 134217728 });  // old sort = 33554432
    //print(JSON.stringify(sortChange, undefined, 2));
}

function postRun() {
    prismWebDB.adminCommand(
        { 'setParameter': 1, 'internalQueryExecMaxBlockingSortBytes': 33554432 });  // old sort = 134217728
    //print(JSON.stringify(sortChange, undefined, 2));
}

function printHeader() {
    print('==============================================================');
    print(scriptName + ' ' + version + ' © Sisense ');
    print('Total scripts to apply: ' + scriptsList.length + ' ');
    print('Cleanup ' + cleanupStatus + ' | Logs ' + logsStatus);
    print(' ');
    print(startDate);
}

function postProcessExecution() {
    logger('============================================');
    logger('Post-processing script changes');
    print(' ');
}

function printSummary() {
    print('   ');
    print('==============================================================');
    logger('Scripts statistics ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    endDate = new Date();
    var execTime = timeDiff(startDate, endDate);
    var total = 0;
    logger('Execution time ' + execTime.seconds + ' seconds ');
    Object.keys(collectedStats).sort().forEach(function (key) {
        var value = collectedStats[key];
        if (value > 0) {
            print(' - ' + key + ': ' + value + ' items');
        }
        total += value;
    });
    if (total > 0) {
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + total);
    }

    logger('==============================================================');
}

function loadScripts() {
    scriptsList.forEach(function (script, index) {
        logger('==============================================================');
        var startTime = new Date();
        logger('Starting script  ' + index +': ' + script + ' from ' + scriptsList.length + ' © Sisense');
        if (scriptsFolder) {
            var path = scriptsFolder + '/' + script;
            load(path);
        } else {
            load(script);
        }
        var endTime = new Date();
        var scriptTime = timeDiff(startTime, endTime);
        logger('Execution time of the script  ' + index +': ' + script + ' from ' + scriptsList.length + ' © Sisense: '+ scriptTime.seconds + ' seconds ');
        logger('==============================================================');
        //sleep(timeout);
    });
}

function completed() {
    logger('Scripts have finished execution successfully ' + ' © Sisense');
}

printHeader();
preRun();
loadScripts();
postProcessExecution();
postRun();
printSummary();
completed();
