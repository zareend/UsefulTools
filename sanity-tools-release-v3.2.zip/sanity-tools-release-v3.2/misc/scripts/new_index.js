var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

prismWebDB.dashboards.createIndex({oid: 1, userId: 1}, {unique: true, dropDups: true});