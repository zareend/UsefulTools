// General Info
var version = '3.1.3';

var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

// noinspection SpellCheckingInspection
var oldCubeId = '5c087460a7477c2bbcdf5497';
var newCubeId = '5c07021eef91784410d46fd0';
var doUpdate = false;
prismWebDB.getCollection('dataContext').find({ cubeId: ObjectId(oldCubeId) }).forEach(function (rule) {
    print('rule:' + rule._id);
    if (doUpdate) {
        prismWebDB.getCollection('dataContext').updateOne(
            { '_id': rule._id },
            { $set: { 'cubeId': ObjectId(newCubeId) } }
        );
    }
});
