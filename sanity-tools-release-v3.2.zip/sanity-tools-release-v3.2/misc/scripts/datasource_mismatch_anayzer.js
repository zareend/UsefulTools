/**
 * Script: Datasource mismatch analyzer.
 * @author taras.vdovyn@sisense.com
 * @description
 * Analyzes dashboard and widget documents to see if EXPECTED_DATASOURCE_FULLNAME is present
 * in all dependent models of dashboard and widget documents(filters, metadata, jaqls, formulas, etc...)
 * Uses deep search to get all properties with `datasource` in the dashboard or widget objects
 * And then compares all found datasources with expected datasource. If mismatch is found it is added to mismatch
 * array. When all results are gathered it prints the detailed results.
 */
(function () {

    const prismWebDB = db.getSiblingDB('prismWebDB');
    let doCleanup = false;
    if (typeof globalCleanup !== 'undefined') {
        // global cleanup
        // comment line below to use local cleanup flag
        doCleanup = globalCleanup;
    }

    //region Common utils
    var scriptsFolder = '../scripts';
    var utilsFolder = '../utils';

    function loadScript(script, scriptPath) {
        var path;
        if (scriptPath) {
            path = scriptPath + '/' + script;
            load(path);
        } else if (scriptsFolder) {
            path = scriptsFolder + '/' + script;
            load(path);
        } else {
            load(script);
        }
    }

    loadScript('utils.js', utilsFolder);
    //endregion
    printHeader();

    function fatDelimiter() {
        print('================================================================================================================');
    }

    function thinDelimiter() {
        print('----------------------------------------------------------------------------------------------------------------');
    }

    /**
     * Configuration section of the script
     */

    /**
     * Expected datasource fullname. Any found datasource object will be checked against this property to find any mismatch
     * This prop must be specified in format ${serverAddress/elasticubeTitle}
     * Example 'Localhost/Sample Ecommerce'
     * @type {string}
     */
    const EXPECTED_DATASOURCE_FULLNAME = 'LocalHost/PSC';
    /**
     * For performance considerations you con exclude some properties from checking in this array
     * Layout, style and shares are not supposed to have datasource property in them.
     * If you want full and exhaustive check leave this array empty
     * @type {string[]}
     */
    const EXCLUDE_KEYS_FROM_DEEP_SEARCH = ['layout', 'style', 'shares'];
    /**
     * If you want to see the progress of run specify the this flag as true, then you'll see how many dashboards are checked
     * and how many are left to check. Also you will see how much time each dashboard check consumes
     * @type {boolean}
     */
    const PRINT_DEBUG_INFO = true;

    const getAllPathsOfKeyInObject = (obj, keyToFind, path, allPaths) => {
        path = path || [];
        allPaths = allPaths || [];

        for (let key in obj) {
            if (EXCLUDE_KEYS_FROM_DEEP_SEARCH.indexOf(key) >= 0) continue;

            path.push(key);
            if (obj[key] && typeof obj[key] === 'object' && key !== keyToFind) {
                getAllPathsOfKeyInObject(obj[key], keyToFind, path, allPaths);
            }
            if (key !== keyToFind) {
                path.pop();
            }
            if (key === keyToFind) {
                allPaths.push(path.slice());
                path.pop();
            }

        }

        return allPaths;
    };

    const getValueByPathInObject = (obj, path) => {
        let val = obj;

        for (let prop of path) {
            val = val[prop];
        }

        return val;
    };

    const setValueInObjectByPath = (obj, multipartKey, path, value) => {
        let pointer = obj;
        const [pointerKey, keyToChange] = multipartKey.split('.');

        for (let prop of path) {
            if (prop !== pointerKey) {
                pointer = pointer[prop];
            }
        }

        if (pointer[pointerKey] && typeof pointer[pointerKey] === 'object') {
            pointer[pointerKey][keyToChange] = value;
        }
    };

    const pathToString = (path) => {
        let stringPath = '';

        for (let prop of path) {
            stringPath += `["${prop}"]`;
        }

        return stringPath;
    };

    const isDatasourceMatchesToExpected = (object, datasourcePath) => {
        const actualDatasource = getValueByPathInObject(object, datasourcePath);

        if (!EXPECTED_DATASOURCE_FULLNAME || !actualDatasource) {
            return false;
        }

        if (typeof actualDatasource === 'string') {
            return EXPECTED_DATASOURCE_FULLNAME === actualDatasource;
        }

        return actualDatasource.fullname === EXPECTED_DATASOURCE_FULLNAME;
    };

    const validateScriptConfiguration = () => {
        if (!EXPECTED_DATASOURCE_FULLNAME) {
            throw new Error('The expected datasource is not specified. Please refer to the configuration section of the script');
        }
    };

    const operationTime = () => {
        const start = new Date();

        return () => `${new Date() - start} ms`;
    };

    const mismatch = (object, datasourcePath) => ({
        oid: object.oid,
        actualDatasource: getValueByPathInObject(object, datasourcePath),
        path: pathToString(datasourcePath),
        expectedDatasource: EXPECTED_DATASOURCE_FULLNAME
    });

    const debug = msg => {
        PRINT_DEBUG_INFO && print(msg);
    };

    const printMismatch = (mismatchName, _mismatch) => {
        print(`${mismatchName} with oid ${_mismatch.oid.str} has datasource mismatch in path: ${_mismatch.path}`);
        print(`Expected is "${_mismatch.expectedDatasource}" But actual is ${JSON.stringify(_mismatch.actualDatasource)}`);
        thinDelimiter();
    };

    function printScriptConfiguration() {
        print(`Starting datasource analyze script run. Buckle up...`);
        print(`Script will be running with the following configuration:`);
        thinDelimiter();
        print(`Expected datasource full name: ${EXPECTED_DATASOURCE_FULLNAME}`);
        thinDelimiter();
        print(`The following keys will be excluded from deep search: ${JSON.stringify(EXCLUDE_KEYS_FROM_DEEP_SEARCH)}`);
        thinDelimiter();
        print(`Printing of debug info is ${PRINT_DEBUG_INFO ? 'enabled' : 'disabled'}`);
        fatDelimiter();
    }

    try {
        validateScriptConfiguration();
        printScriptConfiguration();
        const query = {'datasource.fullname': EXPECTED_DATASOURCE_FULLNAME};
        const scriptTime = operationTime();
        fatDelimiter();
        print(`Fetching dashboards by query: ${JSON.stringify(query)}`);

        const dashboardCursor = prismWebDB.getCollection('dashboards').find(query);
        const numOfDashboards = dashboardCursor.count();
        let allDashboardMismatches = [];
        let allWidgetMismatches = [];
        let dashboardIndex = 1;
        print(`Num of dashboards to check: ${numOfDashboards}`);
        fatDelimiter();

        dashboardCursor.forEach(dashboard => {
            const dashboardTimeConsumed = operationTime();
            debug(`Checking dashboard ${dashboard.oid.str}. Instance type: ${dashboard.instanceType}. User id: ${dashboard.userId ? dashboard.userId.str : dashboard.userId} -- ${dashboardIndex}/${numOfDashboards}`);
            const datasourcePaths = getAllPathsOfKeyInObject(dashboard, 'datasource');
            const dashboardMismatches = [];

            datasourcePaths.forEach(datasourcePath => {
                if (!isDatasourceMatchesToExpected(dashboard, datasourcePath)) {
                    dashboardMismatches.push(mismatch(dashboard, datasourcePath));

                    if (doCleanup) {
                        setValueInObjectByPath(
                            dashboard,
                            'datasource.fullname',
                            datasourcePath,
                            EXPECTED_DATASOURCE_FULLNAME
                        );
                    }
                }
            });
            allDashboardMismatches = allDashboardMismatches.concat(dashboardMismatches);

            if (doCleanup && dashboardMismatches.length) {
                prismWebDB.getCollection('dashboards').replaceOne({_id: dashboard._id}, dashboard);
            }

            const widgetsCursor = prismWebDB.getCollection('widgets').find({
                dashboardid: dashboard.oid,
                userId: dashboard.userId
            });
            const numOfWidgets = widgetsCursor.count();
            let widgetIndex = 1;
            widgetsCursor.forEach(widget => {
                debug(`Checking widget ${widget.oid.str}. Instance type: ${widget.instanceType}. User id: ${widget.userId ? widget.userId.str : widget.userId} -- ${widgetIndex}/${numOfWidgets}`);
                const wDatasourcePaths = getAllPathsOfKeyInObject(widget, 'datasource');
                const widgetMismatches = [];

                wDatasourcePaths.forEach(datasourcePath => {
                    if (!isDatasourceMatchesToExpected(widget, datasourcePath)) {
                        widgetMismatches.push(_mismatch(widget, datasourcePath));

                        if (doCleanup) {
                            setValueInObjectByPath(
                                widget,
                                'datasource.fullname',
                                datasourcePath,
                                EXPECTED_DATASOURCE_FULLNAME
                            );
                        }
                    }
                });
                allWidgetMismatches = allWidgetMismatches.concat(widgetMismatches);

                if (doCleanup && widgetMismatches.length) {
                    prismWebDB.getCollection('widgets').replaceOne({_id: widget._id}, widget);
                }
                widgetIndex++;
            });

            dashboardIndex++;
            debug(`Dashboard ${dashboard.oid.str} check time consumed ${dashboardTimeConsumed()}`);
        });
        fatDelimiter();
        print('Analyze ended. The results of analyze operation are:');
        fatDelimiter();
        print(`Total number of mismatches is: ${allDashboardMismatches.length + allWidgetMismatches.length}`);
        thinDelimiter();
        print(`Number of mismatches in dashboard documents is: ${allDashboardMismatches.length}`);
        thinDelimiter();
        print(`Number of mismatches in widget documents is: ${allWidgetMismatches.length}`);
        fatDelimiter();
        print('Here are some details about found mismatches...');
        fatDelimiter();
        print('Dashboard datasource mismatches are: ');
        thinDelimiter();

        allDashboardMismatches.forEach(_mismatch => {
            printMismatch('Dashboard', _mismatch)
        });

        print('Widget datasource mismatches are: ');
        fatDelimiter();

        allWidgetMismatches.forEach(_mismatch => {
            printMismatch('Widget', _mismatch);
        });

        print(`Run ended successfully.`);
        debug(`Time consumed: ${scriptTime()}`);

    } catch (error) {
        print(`Error occurred during script execution: ${error}`);
        error.stack && print(error.stack);
        print('Please see the usage notes at the top. If the error is not clear, please contact the author of the script.');
    }
})();
