/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
//TODO why widget has shares?

// General Info
var version = '3.1.3';
var scriptName = 'Schema analyzer';

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion
function getSchemas(db) {
    var collections = db.getCollectionNames();
    collections.forEach(function (item) {
        var cursor = db.getCollection(item).find();
        var schema = getSchema(cursor);
        logger(item);
        logger(JSON.stringify(schema, null, 2));
    });

}

function getKP(target, db_structure) {
    for (const k in target) {
        if (typeof target[k] !== "object") {
            if (target.hasOwnProperty(k) && !db_structure.hasOwnProperty(k)) {
                db_structure[k] = typeof target[k];
            }
        } else {
            db_structure[k] = {};
            getKP(target[k], db_structure[k]);
        }
    }
}

function getSchema(cursor) {
    let items = cursor.toArray();
    const db_structure = {};

    for (let i = 0; i < items.length; ++i) {
        const target = items[i];
        getKP(target, db_structure);
    }
    return db_structure;
}

getSchemas(prismWebDB);
getSchemas(prismConfig);
getSchemas(prismMonitor);
