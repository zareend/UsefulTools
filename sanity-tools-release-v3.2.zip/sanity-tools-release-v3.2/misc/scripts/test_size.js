// General Info
var version = '3.1.3';
var scriptName = 'Size checker';

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    conditions: {
        arrSize: 50,
        checkElements: true,
        sortedResult: true,
        definedCollections: true,
        showHigherThanAvg: true,
        checkObjectsArr: ['dashboards', 'widgets']
    },
    logging: {
        showLogs: showLogs
    }
};

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

printHeader();
printConfig(config);

// Global variables

// Functions
function createMessage(elem, count, item) {
    var msg = '  - ' + count + ' _id: ' + elem[0]._id + ' ';
    msg += 'size: ' + elem[1];

    if (elem[0].type) {
        msg += ' type: ' + elem[0].type + ' ';
    }
    if (elem[0].title) {
        msg += ' title: ' + elem[0].title + ' ';
    }
    if (elem[0].oid) {
        msg += ' oid: ' + elem[0].oid + ' ';
    }

    msg += ' | ' + item;

    return msg;
}

function checkObject(obj, item, parent, path) {
    if (!parent) {
        parent = obj;
    }



    Object.keys(obj).forEach(function (key) {
        var newPath = path ? path : '';
        var value = obj[key];

        //following statement added by Zareen
        if (value !== null) {
            if (typeof (value) == 'object') {
                newPath += key;
                var keys = Object.keys(value);
                if (keys.length > config.conditions.arrSize) {
                    print('    object ' + path + key + ' has too many keys: ' + keys.length +
                        ' elements  size: ' + Object.bsonsize(value));

                    collectStats('size_too_big_object', 1);
                    var property = path + key;

                    if (doCleanup) {
                        print('      Run manually: ' + 'db.getCollection(' + item +
                            ').update({ _id: ObjectId(\'' + parent._id + '\') },{ $unset: { \'' +
                            property + '\': \'\' } },{ multi: true })');
                        // TODO requires MongoDB 4.2
                        // var res = prismWebDB.getCollection(item).aggregate([
                        //     { $match: { _id: parent._id } },
                        //     { $unset: [property] }
                        // ]);
                        // print(JSON.stringify(res));
                    }
                    print('  ');

                } else {
                    newPath += '.';
                    checkObject(value, item, parent, newPath);
                }
            }
        }

        if (Array.isArray(value) && (value && value.length > config.conditions.arrSize) ) {
            print('    array is too big: ' + value.length + ' elements  size: ' +
                Object.bsonsize(value));
            print('    - ' + key + ': ' + value + ' ' + typeof (value) + ' ' +
                Array.isArray(value));
            collectStats('size_too_long_array', 1);
        }
    });
}

function testCollection(item) {
    var maxSize = 0;

    var sortable = [];

    var stats = prismWebDB.getCollection(item).stats();
    var collectionTotal = prismWebDB.getCollection(item).count();
    //print(JSON.stringify(stats, null, 2));
    print(item + ' : ' + collectionTotal + ' items');
    print(' ' + 'average object size ' + stats.avgObjSize);
    print(' ' + stats.ns + ' ' + stats.size);
    collectStats(stats.ns, stats.size);
    if (config.conditions.checkElements) {
        prismWebDB.getCollection(item).find({}).forEach(function (colItem) {
            var size = Object.bsonsize(colItem);

            //print('colItem size: ' + size);
            if (size > maxSize) {
                maxSize = size;
                print('new max size: ' + maxSize);
            }

            if (size > limit) {
                print('document bigger than mongo limit ');
            }

            if (!config.conditions.sortedResult) {
                if (size > stats.avgObjSize) {
                    //print('!!! document bigger than avg collection size ');
                    var msg = createMessage([colItem, size], 1, null);
                    logger(msg);
                    checkObject(colItem, item);
                }


            } else {
                sortable.push([colItem, size]);
            }
        });

        if (config.conditions.sortedResult) {
            sortable.sort(function (a, b) {
                return b[1] - a[1];
            });
            print(' max size: ' + maxSize);
            print(' ');

            if (sortable.length === 0) {
                logger(' No data for ' + item);
            } else {
                logger(' Object size stats in ' + item);
                var prevElem = null;
                var count = 1;
                sortable.forEach(function (elem) {

                    if (prevElem == null) {
                        if (config.conditions.checkObjectsArr.indexOf(item) !== -1) {
                            //print('  check object');
                            checkObject(elem[0], item);
                        }
                        prevElem = elem[0];
                        prevElem.size = elem[1];
                    } else if (parseObjectIdToString(prevElem.oid) ===
                        parseObjectIdToString(elem[0].oid)) {
                        if (prevElem.size !== elem[1]) {

                            count += 1;
                            if (config.conditions.checkObjectsArr.indexOf(item) !== -1) {
                                //print('  check object');
                                checkObject(elem[0], item);
                            }
                        } else {
                            count += 1;
                        }
                    } else {
                        if (config.conditions.checkObjectsArr.indexOf(item) !== -1) {
                            //print('  check object');
                            checkObject(elem[0], item);
                        }
                        prevElem = elem[0];
                        count = 1;
                        prevElem.size = elem[1];
                    }
                    var msg = createMessage(elem, count, item);
                    if (config.conditions.showHigherThanAvg) {
                        if (elem[1] > stats.avgObjSize) {
                            logger(msg);
                        }
                    }
                    else {
                        logger(msg);
                    }

                });
            }
        }
        else {
            print('Total element max size: ' + maxSize);
        }

    }
}
// Main script
var collections;
if (config.conditions.definedCollections) {
    collections = config.conditions.checkObjectsArr;
}
else {
    collections = prismWebDB.getCollectionNames();
}

var limit = 16777216;
print('  ');
print('Collection items count: ');
collections.forEach(function (item) {
    print(
        '================================================================================================================');
    testCollection(item);
});

printStats();
logger('Script has finished execution successfully ' + ' © Sisense');
