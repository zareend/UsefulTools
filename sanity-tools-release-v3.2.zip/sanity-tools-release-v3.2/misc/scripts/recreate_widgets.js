var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

// By Oleksii Demianyk
/*Fix widgets if widgets are lost in the dashboard bu do exist in proxy instance*/

var targetBoard = '5da89446c91da42a18bbb805';

prismWebDB.getCollection('widgets')
    .find({ dashboardid: ObjectId(targetBoard), instanceType: 'proxy' })
    .toArray()
    .forEach(function (w) {
        delete w._id;
        w.instanceType = 'owner';
        w.userId = w.owner;
        prismWebDB.getCollection('widgets')
            .update({
                dashboardid: ObjectId(targetBoard),
                owner: w.owner,
                instanceType: 'owner',
                oid: w.oid
            }, w, { upsert: true });
    });

// or from dashboard.widgets
var dashboardId = ObjectId('{dashboard_id}');
prismWebDB.getCollection('dashboards')
    .find({ $and: [{ oid: dashboardId }, { widgets: { $not: { $size: 0 } } }] }, { widgets: 1, _id: 0 })
    .forEach(doc => {
        doc.widgets.forEach(widget => {
            prismWebDB.getCollection('widgets').insert(widget, { multi: true, upsert: false });
        });
    });
