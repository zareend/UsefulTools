/**
 * Created by yaroslav.korzh
 * Updated 02/05/2019
 */
// General Info
var version = '2.1.1';
var scriptName = 'Jobs validate';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

printHeader();
printConfig(config);

// Global variables
var brokenJobs = 0;
var jobDashboards = [];
// Functions
// *** Jobs Validation Functions ***
function validateSubscriptionJob(job) {
    var dashboardId = parseStringToObjectId(job.dashboardId);
    var dashCount = prismWebDB.dashboards.count({ oid: dashboardId });
    var widgetCount = prismWebDB.widgets.count({ dashboardid: dashboardId });
    // If there are no dashboards and no widgets (meaning that the dashboard was deleted)
    return !(dashCount === 0 && widgetCount === 0);
}

function validateJob(job) {
    var isValid = true,
        isJobToDelete = false;

    if (!validateObjectId(job._id)) {
        isValid = false;
        collectStats('job_invalid_id', 1);
        print('Job (_id): ' + job._id + ' has invalid job id');
    }

    if (job.jobType === 'dashboardSubscription' && !validateSubscriptionJob(job)) {
        isJobToDelete = true;
        collectStats('job_on_nonexistent_dashboard', 1);
        print('Job (_id): ' + job._id + ' is related to a dashboard which does not exist (oid): ' +
            job.dashboardId);
        //print("db.getSiblingDB('prismWebDB').jobs.remove({_id: ObjectId('" + job._id + "')});");

        brokenJobs += 1;
        if (doCleanup) {
            prismWebDB.jobs.remove({ _id: job._id });
        }
        //print("db.dashboards.find({oid: ObjectId('" + job.dashboardId + "')})");
    }

    if (!isValid && !isJobToDelete) {
        print('db.getSiblingDB(\'prismWebDB\').jobs.find({_id: ObjectId(\'' + job._id + '\')});');
    }
}

function validateAllJobs() {

    var bulkSize = 10;
    print('Validating all ' + jobCount + ' jobs ');
    for (var i = 0; i < jobCount; i = i + bulkSize) {
        var bulkJobs = prismWebDB.jobs
            .find({}, { _id: 1, jobType: 1, dashboardId: 1 })
            .skip(i).limit(bulkSize).toArray();
        print('Validating job chunk ' + bulkJobs.length + ' jobs, step ' + i + ' size ' +
            bulkSize);
        bulkJobs.forEach(function (job) {
            validateJob(job);
        });
    }

    //prismWebDB.jobs.find({}, {_id: 1, jobType: 1, dashboardId: 1}).forEach(function(job){

    //});
    logger('Broken jobs ' + brokenJobs + ' copies');
    print('Validating all jobs has ended.');
}

// Main script
var jobCount = prismWebDB.jobs.count();
print('Validating all ' + jobCount + ' jobs ');

prismWebDB.getCollection('jobs')
    .find({ active: false, jobType: 'dashboardSubscription' })
    .forEach(function (job) {
        jobDashboards.push(job.dashboardId);
    });
print('Job dashboards ' + jobDashboards.length + ' ');
/*
jobDashboards.forEach(function (dashboard) {
    //print(dashboard)
    prismWebDB.getCollection('dashboards')
        .find({ oid: ObjectId(dashboard), instanceType: 'owner' })
        .forEach(function (dash) {
            //print(secureOutput(widget.title));
        });
});
*/

validateAllJobs();

