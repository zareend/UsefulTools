var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

function getUserName(oid) {

    return prismWebDB.users.find({ _id: oid })[0].email;

}

function getGroupName(oid) {

    return prismWebDB.groups.find({ _id: oid })[0].name;

}

function getFolderName(oid) {

    var id = new ObjectId(oid);

    return prismWebDB.tags.find({ oid: id })[0].name;

}

prismWebDB.dashboards.find({}).forEach(function (d) {

    d.owner = getUserName(d.owner);

    try {

        if (d.parentFolder) {

            d.parentFolder = getFolderName(d.parentFolder);

        }

    } catch (e) {}

    d.shares.forEach(function (s) {

        if (s.type === 'user') {

            s.shareId = getUserName(s.shareId);

        } else {

            s.shareId = getGroupName(s.shareId);

        }

    });

    print(d);

});