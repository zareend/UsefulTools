// General Info
var version = '3.1.3';

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

function validateObjectId(id) {
    var stringId = parseObjectIdToString(id);
    return checkForHexRegExp.test(stringId);
}

// *** Group Validation Functions ***
function isGroupIdExists(id) {
    var groupId = parseStringToObjectId(id);
    // If we found a group with the given id
    return prismWebDB.groups.find({ _id: groupId }).limit(1).hasNext();
}

function validateGroupId(id) {
    return (validateObjectId(id) && isGroupIdExists(id));
}

//  *** Folder Validation Functions ***
function isFolderIdExists(id) {
    var folderOid = parseStringToObjectId(id);
    // If we found a group with the given id
    return prismWebDB.tags.find({ oid: folderOid }).limit(1).hasNext();
}

function validateFolderId(id) {
    return (validateObjectId(id) && isFolderIdExists(id));
}

// *** Jobs Validation Functions ***
function validateSubscriptionJob(job) {
    var dashboardId = parseStringToObjectId(job.dashboardId);
    var dashCount = prismWebDB.dashboards.count({ oid: dashboardId });
    var widgetCount = prismWebDB.widgets.count({ dashboardid: dashboardId });
    // If there are no dashboards and no widgets (meaning that the dasboard was deleted)
    return !(dashCount === 0 && widgetCount === 0);
}

// *** Dashboards Validation Functions ***
function validateSharedDashboard(dashboard) {
    var objectOid = parseStringToObjectId(dashboard.oid);
    return prismWebDB.dashboards.find({ oid: objectOid, instanceType: 'owner' }).limit(1).hasNext();
}

function validateParentFolder(dashboard) {
    if (dashboard.parentFolder && !!dashboard.parentFolder) {
        return validateFolderId(dashboard.parentFolder);
    } else {
        return true;
    }
}

// This code was updated in 06.10.16 by Alon Berkman (It might not be relevant in later versions than 6.5)
function clearLayoutFromGhostWidget(dashboard, ghostWidget) {
    // removing element
    ghostWidget.subcell.elements.splice(ghostWidget.elementIdx, 1);
    if (ghostWidget.subcell.elements.length === 0) {
        // removing subcell
        ghostWidget.cell.subcells.splice(ghostWidget.subcellIdx, 1);
        if (ghostWidget.cell.subcells.length === 0) {
            // removing cell
            ghostWidget.col.cells.splice(ghostWidget.cellIdx, 1);
            /* decided to leave the column empty when there are no cells */
            //if (ghostWidget.col.cells.length == 0) {
            // remove column
            //ghostWidget.columns.splice(ghostWidget.colIdx, 1);
            //}
        }
    }

    // Beware!!! Uncommentting this line would delete ghost widgets
    /*print(prismWebDB.dashboards.update(
        {
            oid: dashboard.oid, userId: dashboard.userId
        },
        {
            $set: {
                layout: dashboard.layout
            }
        }
    ));*/
}

function validateDashboardLayout(dashboard) {

    var isLayoutValid = true;

    // The layout is validate if there are no columns
    if (!dashboard.layout.columns) { return true; }

    var dashboardWidgets = [];

    prismWebDB.widgets.find({ dashboardid: dashboard.oid, userId: dashboard.userId },
        { oid: 1, _id: 0 }
    ).forEach(function (widget) {
        dashboardWidgets.push(parseObjectIdToString(widget.oid));
    });

    for (var colidx = 0; colidx < dashboard.layout.columns.length; colidx++) {
        var col = dashboard.layout.columns[colidx];
        if (col.cells && col.cells.length > 0) {
            for (var cellidx = 0; cellidx < col.cells.length; cellidx++) {
                var cell = col.cells[cellidx];
                if (cell.subcells && cell.subcells.length > 0) {
                    for (var subcellidx = 0; subcellidx < cell.subcells.length; subcellidx++) {
                        var subcell = cell.subcells[subcellidx];
                        if (subcell.elements && subcell.elements.length > 0) {
                            for (var elementidx = 0; elementidx <
                            subcell.elements.length; elementidx++
                            ) {
                                var element = subcell.elements[elementidx];

                                // If the widget exists on the layout but not for real
                                if (dashboardWidgets.indexOf(element.widgetid) === -1) {
                                    isLayoutValid = false;

                                    var ghostWidget = {
                                        col: col,
                                        colidx: colidx,
                                        cell: cell,
                                        cellidx: cellidx,
                                        subcell: subcell,
                                        subcellidx: subcellidx,
                                        element: element,
                                        elementidx: elementidx
                                    };

                                    clearLayoutFromGhostWidget(dashboard, ghostWidget);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return (isLayoutValid);
}

// *** Roles Validation Functions ***
var allRoles = {}; // Hashmap of all roles
function initAllRoles() {
    prismConfig.roles.find({}, { _id: 1 }).forEach(function (role) {
        var roleIdString = parseObjectIdToString(role._id);
        allRoles[roleIdString] = roleIdString;
    });
}

function isRoleIdExists(id) {
    var roleIdString = parseObjectIdToString(id);
    // Initializing the roles hashmap
    if (isEmptyObject(allRoles)) {
        initAllRoles();
    }

    return allRoles.hasOwnProperty(roleIdString);
}

function validateRoleId(userRole) {
    return isRoleIdExists(userRole);
}

// *** Main Functions ***
function validateAllUsers() {
    print('Validating all users...');
    prismWebDB.users.find({}, { roleId: 1, _id: 1, groups: 1 }).forEach(function (user) {
        var isValid = true;

        if (!validateObjectId(user._id)) {
            isValid = false;
            print('User (_id): ' + user._id + ' has invalid user id');
        }

        if (user.groups) {
            user.groups.forEach(function (groupIdString) {
                if (!validateGroupId(groupIdString)) {
                    isValid = false;
                    print('User (_id): ' + user._id + ' has invalid group id: ' + groupIdString);
                }
            });
        }

        if (!validateRoleId(user.roleId)) {
            isValid = false;
            print('User (_id): ' + user._id + ' has invalid role id: ' + user.roleId);
        }

        if (!isValid) {
            print('db.getSiblingDB(\'prismWebDB\').users.find({_id: ObjectId(\'' + user._id +
                '\')});');
        }
    });
    print('Validating all users has ended.');
}

function validateJob(job) {
    var isValid = true,
        isJobToDelete = false;

    if (!validateObjectId(job._id)) {
        isValid = false;
        print('Job (_id): ' + job._id + ' has invalid job id');
    }

    if (job.jobType === 'dashboardSubscription' && !validateSubscriptionJob(job)) {
        isJobToDelete = true;
        //print("Job (_id): " + job._id + " is related to a dashboard which does not exist (oid): " + job.dashboardId);
        print('db.getSiblingDB(\'prismWebDB\').jobs.remove({_id: ObjectId(\'' + job._id + '\')});');
        //db.getSiblingDB('prismWebDB').jobs.remove({_id: job._id });
        //print("db.dashboards.find({oid: ObjectId('" + job.dashboardId + "')})");
    }

    if (!isValid && !isJobToDelete) {
        print('db.getSiblingDB(\'prismWebDB\').jobs.find({_id: ObjectId(\'' + job._id + '\')});');
    }
}

function validateAllJobs() {
    print('Validating all jobs...');

    var bulkSize = 100;
    var jobCount = prismWebDB.jobs.count();

    for (var i = 0; i < jobCount; i = i + bulkSize) {
        var bulkJobs = prismWebDB.jobs
            .find({}, { _id: 1, jobType: 1, dashboardId: 1 })
            .skip(i).limit(bulkSize);

        bulkJobs.forEach(function (job) {
            validateJob(job);
        });
    }

    //prismWebDB.jobs.find({}, {_id: 1, jobType: 1, dashboardId: 1}).forEach(function(job){

    //});
    print('Validating all jobs has ended.');
}

function validateDashboard(dashboard) {
    var isValid = true;

    if (!validateObjectId(dashboard._id)) {
        isValid = false;
        print('Dashboard (_id): ' + dashboard._id + ' has invalid dashboard id');
    }

    if (!validateObjectId(dashboard.oid)) {
        isValid = false;
        print('Dashboard (_id): ' + dashboard._id + ' has invalid dashboard oid: ' + dashboard.oid);
    }

    if (!validateParentFolder(dashboard)) {
        isValid = false;
        print('Dashboard (_id): ' + dashboard._id + ' has invalid parent folder: ' +
            dashboard.parentFolder);
    }

    // If it's a shared dashboard (shared to the owner and to another one)
    if (dashboard.instanceType === 'proxy' || dashboard.instanceType === 'user') {
        if (!validateSharedDashboard(dashboard)) {
            isValid = false;
            print('Dashboard (oid): ' + dashboard.oid +
                ' is shared and does not have an owner instance');
        }
    }

    if (dashboard.instanceType !== 'proxy' && !validateDashboardLayout(dashboard)) {
        isValid = false;
        print('Dashboard (oid): ' + dashboard.oid + ' of user ' + dashboard.userId +
            ' has a GHOST widget');
    }

    if (!isValid) {
        print('db.getSiblingDB(\'prismWebDB\').dashboards.find({_id: ObjectId(\'' + dashboard._id +
            '\')});');
    }
}

function validateAllDashboards() {
    print('Validating all dashboards...');

    var bulkSize = 1000;
    var dashCount = prismWebDB.dashboards.count();

    print('Total dashboards', dashCount);

    for (var i = 0; i < dashCount; i = i + bulkSize) {
        var bulkDashboards = prismWebDB.dashboards
            .find({}, { _id: 1, oid: 1, parentFolder: 1, instanceType: 1, layout: 1, userId: 1 })
            .skip(i).limit(bulkSize);

        bulkDashboards.forEach(function (dashboard) {
            validateDashboard(dashboard);
        });
    }

    print('Valiadting all dashboards has ended.');
}

validateAllUsers();
validateAllJobs();
validateAllDashboards();
