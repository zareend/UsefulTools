/**
 * Created by yaroslav.korzh
 * Updated 09/02/2019
 */
// General Info
var version = '3.1.3';
var scriptName = 'Collections entries cleaner';

// Configuration
var showLogs = true;
var doCleanup = true;

if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    conditions: {
        allCollections: true,
        arrSize: 50,
        checkObjectsArr: ['widgets', 'dashboards']
    },
    logging: {
        showLogs: showLogs
    }
};

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

function cleanCollection(item) {

    var stats = prismWebDB.getCollection(item).stats();
    var collectionTotal = prismWebDB.getCollection(item).count();
    print(item + ' : ' + collectionTotal + ' items');
    print(JSON.stringify(stats, null, 2));
    var result = prismWebDB.getCollection(item).remove({});
    print('removed: ');
    print(JSON.stringify(result, null, 2));
    var key = item + '_deleted';
    collectStats(key, result.nRemoved);

}

var collectionsDefined = ['widgets', 'dashboards'];
var collectionsAll = prismWebDB.getCollectionNames();
var collections;
if (config.conditions.allCollections) {
    collections = collectionsAll;
} else {
    collections = collectionsDefined;
}

var limit = 16777216;
print('  ');
print('Collection items count: ');
collections.forEach(function (item) {
    divider();
    cleanCollection(item);
});

printStats();
