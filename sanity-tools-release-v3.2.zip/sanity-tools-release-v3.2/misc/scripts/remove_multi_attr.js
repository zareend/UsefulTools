var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

prismWebDB.getCollection('dashboards').find({ 'filters.levels.isMultiAttribute': { $exists: true } });
prismWebDB.getCollection('dashboards').find({ 'filters.isMultiAttributeEnabled': { $exists: true } });
prismWebDB.getCollection('dashboards').find({ 'defaultFilters.levels.isMultiAttribute': { $exists: true } });
prismWebDB.getCollection('dashboards').find({ 'defaultFilters.isMultiAttributeEnabled': { $exists: true } });