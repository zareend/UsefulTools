//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

print('jobID, dashboardID, number_Of_Executions, lastExecution, isDataChange, schedule');
prismWebDB.jobs.find({ active: true, jobType: 'dashboardSubscription' }).forEach(function (job) {

    print(job._id + ',' + job.context.dashboardid + ',' +
        Object.keys(job.executionDayCounter).length + ',' + job.lastExecution + ',' +
        job.isDataChange + ',' + job.schedule);

});
