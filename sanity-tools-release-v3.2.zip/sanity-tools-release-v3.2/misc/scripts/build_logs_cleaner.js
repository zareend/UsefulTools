/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Elasticube build logs cleaner';

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

printHeader();
printConfig(config);

// Global variables
var sessionsToKeep = [];
var logsToKeep = 0;


var logKeys = {
    timestamp: '$timestamp',
    sessionId: '$sessionId',
    cubeId: '$cubeId',
    serverName: '$serverName',
    _id: '$_id'
};
var aggregationOptions = {
    allowDiskUse: true
};
var logsCount = prismWebDB.getCollection('elasticubeBuildLogs').count({});

// Functions
function cleanCappedCollection() {
    logger('Cleaning capped collection');
    var size = prismWebDB.getCollection('elasticubeBuildLogs').stats().maxSize;
    prismWebDB.createCollection('elasticubeBuildLogs_backup');
    db.getCollection('elasticubeBuildLogs').find().forEach( function(doc) { db.getCollection('elasticubeBuildLogs_backup').insert(doc); } );
    logger('Cloned');
    logger(JSON.stringify(cloned));
    var indexes = prismWebDB.getCollection('elasticubeBuildLogs').getIndexes();
    indexes.forEach(function (index) {
        delete index.v;
        delete index.ns;
        var key = index.key;
        delete index.key;
        var options = [];
        for (var option in index) {
            options.push(index[option]);
        }
        var indexCreate = prismWebDB.getCollection('elasticubeBuildLogs_backup')
            .createIndex(key, options);
        logger('indexCreate');
        logger(JSON.stringify(indexCreate));

    });

    logger('removed');
    var removed = prismWebDB.getCollection('elasticubeBuildLogs_backup')
        .remove({ sessionId: { $nin: sessionsToKeep } });
    logger(JSON.stringify(removed));
    logger('dropped');
    var dropped = prismWebDB.getCollection('elasticubeBuildLogs').drop();
    logger(JSON.stringify(dropped));
    logger('newCapped');
    var newCapped = prismWebDB.runCommand(
        { convertToCapped: 'elasticubeBuildLogs_backup', size: size });
    logger(JSON.stringify(newCapped));
    logger('renamed');
    var renamed = prismWebDB.getCollection('elasticubeBuildLogs_backup')
        .renameCollection('elasticubeBuildLogs');
    logger(JSON.stringify(renamed));
    prismWebDB.getCollection('elasticubeBuildLogs').createIndex({
        'cubeId': 1,
        'serverId': 1
    });
    prismWebDB.getCollection('elasticubeBuildLogs').createIndex({
        'cubeId': 1,
        'serverId': 1,
        'timestamp': 1
    });
    logger('Finished');
    var newLogsCount = prismWebDB.getCollection('elasticubeBuildLogs').count({});
    logger('New collection size: ' + newLogsCount);
}

function cleanCollection() {
    logger('Cleaning regular collection');
    logger('removed');
    var removed = prismWebDB.getCollection('elasticubeBuildLogs')
        .remove({ sessionId: { $nin: sessionsToKeep } });
    logger(JSON.stringify(removed));
    var newLogsCount = prismWebDB.getCollection('elasticubeBuildLogs').count({});
    logger('New collection size: ' + newLogsCount);
}

function cleanLogs() {
    logger(' ');
    if (doCleanup) {
        logger('Start cleaning logs');
        var isCapped = prismWebDB.getCollection('elasticubeBuildLogs').isCapped();
        logger('Collection elasticubeBuildLogs ' + logsCount + ' capped: ' + isCapped);
        if (isCapped) {
            cleanCappedCollection();
        } else {
            cleanCollection();
        }
    }
}

// Main script

var cubesAgg = prismWebDB.getCollection('elasticubeBuildLogs').aggregate([
    { $sort: { _id: 1 } },
    {
        $group: {
            _id: {
                cubeId: '$cubeId',
                serverId: '$serverId',
                serverName: '$serverName'
            },
            count: { $sum: 1 },
            docs: {  $push: logKeys  }
        }
    }], aggregationOptions).toArray();

cubesAgg.forEach(function (cube) {
    logger(' ');
    var searchObj = { serverId: cube._id.serverId, cubeId: cube._id.cubeId };
    logger(cube._id.serverName + ' ' + cube._id.cubeId + ' ' + cube._id.serverId);
    prismWebDB.getCollection('elasticubeBuildLogs')
        .find(searchObj)
        .sort({ timestamp: -1 })
        .limit(1)
        .forEach(function (log) {
            logger('  last session: ' + log.sessionId + ' time: ' + log.timestamp);
            sessionsToKeep.push(log.sessionId);
        });
    var sessionsAgg = prismWebDB.getCollection('elasticubeBuildLogs').aggregate([
        { $match: { serverId: cube._id.serverId, cubeId: cube._id.cubeId } },
        { $sort: { timestamp: -1 } },
        {
            $group: {
                _id: {
                    sessionId: '$sessionId'
                },
                count: { $sum: 1 },
                docs: {
                    $push: {
                        timestamp: '$timestamp'
                    }
                }
            }
        }], aggregationOptions).toArray();
    logger('  sessions: ' + sessionsAgg.length);
    sessionsAgg.forEach(function (session) {
        logger('  session: ' + session._id.sessionId + ' items: ' + session.docs.length);
        logger('    ' + session.docs[session.docs.length - 1].timestamp);
        logger('    ' + session.docs[0].timestamp);
        if (sessionsToKeep.indexOf(session._id.sessionId) !== -1) {
            logsToKeep += session.docs.length;
        }
        // session.docs.forEach(function (sessionInstance) {
        //     logger('    ' + sessionInstance.timestamp);
        // });
    });
});

logger(' ');
logger('====================================');
logger('Logs total: ');
logger(logsCount);

logger('Sessions to keep: ');
logger(JSON.stringify(sessionsToKeep, null, 2));
logger('Logs to keep: ');
logger(logsToKeep);
logger('Logs to remove: ');
logger(logsCount - logsToKeep);

cleanLogs();

logger('Script has finished execution successfully ' + ' © Sisense');

