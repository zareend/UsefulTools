db.serverStatus();
db.runCommand( {serverStatus: 1} );
// https://www.virtual-dba.com/mongodb-serverstatus-health-check-tips/
db.stats();
db.runCommand({ collStats: 'authors', scale: 1024 });
db.adminCommand({ replSetGetStatus: 1 });
db.collection.stats();
db.getCollection('dashboards').aggregate( [ { $indexStats: { } } ], { cursor: {} } );
db.getProfilingStatus();
db.currentOp().inprog.forEach(function (op) {
    if (op.secs_running > 5) {
        var output = {
            Optid: op.opid,
            Long_running_query: op.query,
            Running_time: op.secs_running
        };
        printjson(output);
    }
});
//
db.setLogLevel();
db.getLogComponents();
// security.redactClientLogData

//var my_exp = db.getCollection('dashboards').find({}).explain("executionStats");
//logger(my_exp)
var my_exp = db.getCollection('dashboards').find({'instanceType': 'owner'}).explain("allPlansExecution");
logger(my_exp);
db.printShardingStatus();

//
db.adminCommand( { getLog: "*" } );
db.adminCommand( { getLog : "global" } );

db.setProfilingLevel(2);
//Sort queries by when they were recorded, showing just commands
db.system.profile.find({
"command.pipeline": { $exists: true }
}, {
"command.pipeline":1
}).sort({$natural:-1}).pretty();

// Find all queries doing a COLLSCAN because there is no suitable index
db.system.profile.find({"planSummary":{$eq:"COLLSCAN"},
"op" : {$eq:"query"}}).sort({millis:-1});

// any query or command doing range or full scans
db.system.profile.find({"nreturned":{$gt:1}});

// Find the source of the top ten slowest queries
db.system.profile.find({"op" : {$eq:"query"}}, {
"query" : NumberInt(1),
"millis": NumberInt(1)
}
).sort({millis:-1},{$limit:10}).pretty();

// the source of the top ten slowest commands/aggregations
db.system.profile.find({"op" : {$eq:"command"}}, {
"command.pipeline" : NumberInt(1),
"millis": NumberInt(1)
}
).sort({millis:-1},{$limit:10}).pretty();

// find all queries that take more than ten milliseconds, in descending order,
// displaying both queries and aggregations
db.system.profile.find({"millis":{$gt:10}}) .sort({millis:-1});

//find all queries and aggregations that take more than ten milliseconds, in descending  order, displaying either the query or aggregation
db.system.profile.find({ "millis": { $gt: 10 } }, { millis: NumberInt(1),
"query": NumberInt(1), "command.pipeline": 1 }).sort({ millis: -1 });

db.Customers.find({
"Name.Last Name" : "Johnston"
}, {
"_id" : NumberInt(0),
"Full Name" : NumberInt(1)
}).sort({
"Name.First Name" : NumberInt(1)
}).comment( "Find all Johnston's and display their full names alphabetically" );
// display all queries with comments
db.system.profile.find({ "query.comment": {$exists: true} }, { query: 1 }).pretty();

db.setLogLevel(1); // 1-5 levels
// find anything that took more than 20 ms

db.system.profile.find({"millis":{$gt:20}});
db.setProfilingLevel(1, { slowms: 30 });
db.setProfilingLevel(2);
db.getProfilingStatus();

start = new Date;
db.getCollection('widgets').explain().aggregate([
    {
        $group: {
            _id: {
                //_id: "$_id",
                title: '$title',
                oid: '$oid',
                userId: '$userId',
                instanceType: '$instanceType',
                dashboardid: '$dashboardid'
                //source: '$source'
            },
            count: { $sum: 1 },
            docs: { $push: '$_id' }
        }
    },
    {
        $match: {
            count: { $gt: 1 }
        }
    }
]);
logger(new Date - start + 'ms');

db.getCollection('dashboards').explain().find({});
db.getCollection('dashboards').getIndexes();


var exp = db.getCollection('dashboards').find({ 'datasource.title': { $in: ['Sample ECommerce', 'Sample Healthcare'] } }).explain("executionStats");
//var res = exp.find({ 'datasource.title': { $in: ['Sample ECommerce', 'Sample Healthcare'] } });
logger(exp);

var currentOp = db.currentOp().inprog.forEach(function (op) {
    if (op.secs_running > 5) {
        var output = {
            Optid: op.opid,
            Long_running_query: op.query,
            Running_time: op.secs_running
        };
        logger(JSON.stringify(output));
    }
});
var indexStat = db.getCollection('dashboards').aggregate([{ $indexStats: {} }], { cursor: {} });
var start = new Date;
var explainStat = db.getCollection('widgets').explain().aggregate([
    {
        $group: {
            _id: {
                //_id: "$_id",
                title: '$title',
                oid: '$oid',
                userId: '$userId',
                instanceType: '$instanceType',
                dashboardid: '$dashboardid'
                //source: '$source'
            },
            count: { $sum: 1 },
            docs: { $push: '$_id' }
        }
    },
    {
        $match: {
            count: { $gt: 1 }
        }
    }
]);

printResult(serverStatus);
printResult(dbStats);
printResult(profilingStatus);
printResult(currentOp);
printResult(log);
printResult(logs);
logger('index stats');
printResult(indexStat);
printResult(explainStat);
printResult(db.serverStatus());
