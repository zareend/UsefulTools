// General Info

var version = '3.1.3';
var scriptName = 'Memory cleaner';
var scriptsPath = '../../mongo_tools/scripts/';

var globalRun = true;
var collectedStats = {};
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');
var memStartTime = new Date();
var memEndTime;

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

function printCleanerStats() {
    if (typeof globalRun == 'undefined') {
        logger('Memory cleaner' +  ' statistics ' + version + ' © Sisense');

        memEndTime = new Date();
        var execTime = timeDiff(memStartTime, memEndTime);
        var total = 0;
        logger('Execution time '  + execTime.seconds + ' seconds ');
        if (typeof collectedStats !== 'undefined') {
            Object.keys(collectedStats).forEach(function (key) {
                var value = collectedStats[key];
                print(' - ' + key + ': ' + value + ' items');
                total += value;
            });
        }
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + total);

        divider()
    }
}
function timeDiff(d1, d2) {
    var dateDiff = d2.getTime() - d1.getTime();
    var secDiff = dateDiff / (1000);
    var minDiff = dateDiff / (1000 * 60);
    var hourDiff = dateDiff / (1000 * 60 * 60);
    var milliseconds = dateDiff;
    var hh = Math.floor(milliseconds / 1000 / 60 / 60);
    milliseconds -= hh * 1000 * 60 * 60;
    var mm = Math.floor(milliseconds / 1000 / 60);
    milliseconds -= mm * 1000 * 60;
    var ss = Math.floor(milliseconds / 1000);
    milliseconds -= ss * 1000;
    if(hh<10){
        hh = '0'+hh;
    }
    if(mm<10){
        mm = '0'+mm;
    }
    if(ss<10){
        ss = '0'+ss;
    }

    return {
        text: hh+':'+mm+':'+ss,
        milliseconds: milliseconds,
        seconds: secDiff > 0 ? secDiff : 0,
        minutes: minDiff > 0 ? minDiff : 0,
        hours: hourDiff > 0 ? hourDiff : 0
    };
}
function run() {
    print('MongoDB statistics');
    load(scriptsPath + 'mongo_stats.js');

    print('Removing dashboard.widgets from user & owner instances');
    var result = prismWebDB.dashboards.updateMany(
        { 'instanceType': { $nin: ['proxy'] } },
        { $unset: { widgets: '' } }
    );
    print(JSON.stringify(result, null, 2));

    /*
    // todo update below can be also relevant based on test_size results
    prismWebDB.widgets.updateMany(
        { 'instanceType': { $nin: ['proxy'] } },
        { $unset: { 'metadata.drillHistory': '' } }
    );
     */

    print('Removing entries from trace collection');
    var result_trace = prismMonitor.trace.remove({});
    print(JSON.stringify(result_trace, null, 2));

    load(scriptsFolder + '/' +'test_size.js');
    load(scriptsPath + 'mongo_normalize.js');
    //load('revisions_cleaner.js');
    //load('connections_cleaner.js');
    load(scriptsPath + 'mongo_stats.js');
    print('For general cleaning run AnalyzeMongo.bat & BackupAndCleanMongo.bat');
}


printHeader();
run();
printCleanerStats();
