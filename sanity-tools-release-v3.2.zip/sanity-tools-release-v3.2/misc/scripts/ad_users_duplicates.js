/**
 * Created by yaroslav korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'AD user duplicates cleaner';

var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var documentKeys = {
    userName: '$userName',
    _id: '$_id'
};

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

var bulk = prismWebDB.getCollection('users').initializeUnorderedBulkOp();
var results = prismWebDB.getCollection('users').aggregate([
    {
        $group: {
            _id: {
                //_id: "$_id",
                objectSid: '$objectSid'
            },
            count: { $sum: 1 },
            docs: { $push: documentKeys }
        }
    },
    {
        $match: {
            count: { $gt: 1 }
        }
    }
]).toArray();
results.forEach(function (result) {
    result.docs.forEach(function (item, resIndex) {
        if (resIndex > 1) {
            logger(item._id);
            bulk.find({ '_id': item._id }).remove();
        }
    });
});

var bulkResult = bulk.execute();
logger(bulkResult);
