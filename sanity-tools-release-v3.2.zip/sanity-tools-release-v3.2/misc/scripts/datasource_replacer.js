/**
 * Created by yaroslav.korzh
 * Updated 09/02/2019
 */
// General Info
var version = '3.1.3';
var scriptName = 'Datasource replacer';

// Configuration
var showLogs = true;
var doCleanup = true;
var scriptsPath = '../mongo_tools/scripts/';
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs,
        findByDIM: false
    }
};

// Common utils
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

printHeader();
printConfig(config);

// Global variables
var old_ds = 'CRM SmartVideo Engagement';
var new_ds = 'Owned Media SmartVideo Engagement';

// noinspection SpellCheckingInspection
var new_ds_obj = {
    'title': 'Owned Media SmartVideo Engagement',
    'fullname': 'LocalHost/Owned Media SmartVideo Engagement',
    'id': 'aLOCALHOST_aOWNEDIAAaMEDIAIAAaSMARTVIDEOIAAaENGAGEMENT',
    'address': 'LocalHost',
    'database': 'aOwnedIAAaMediaIAAaSmartVideoIAAaEngagement'
};
// noinspection SpellCheckingInspection
var replaceDictionary = [
    {
        from: 'Sessions.sessionstartdate1 (Calendar)',
        to: 'Daily.sessionstartdate1 (Calendar)'
    }
];
// Functions
var bulkDashboards = prismWebDB.getCollection('dashboards').initializeUnorderedBulkOp();
var bulkWidgets = prismWebDB.getCollection('widgets').initializeUnorderedBulkOp();

function matchNewDS(metadataObj, newMetadataObj, target) {
    logger(' Dimension usage stats in ' + target);
    for (var dim in metadataObj) {
        logger(dim + ' - old: ' + metadataObj[dim] + ' new: ' + newMetadataObj[dim]);
        if(config.logging.findByDIM){
            findByDIM(dim);
        }
    }

}

function replaceDS(jaql, dash) {
    jaql.datasource = new_ds_obj;
    replaceDictionary.forEach(function (pair) {
        if (jaql.dim === pair.from) {
            jaql.dim = pair.to;
        }
    });
    bulkDashboards.find({ _id: dash._id }).updateOne(dash);
}

function replaceWidgetDS(jaql, widget) {
    jaql.datasource = new_ds_obj;
    replaceDictionary.forEach(function (pair) {
        if (jaql.dim === pair.from) {
            jaql.dim = pair.to;
        }
    });
    bulkWidgets.find({ _id: widget._id }).updateOne(widget);
}

function findByDIM(dim) {
    var result = prismWebDB.getCollection('dashboards')
        .find({ 'filters.jaql.dim': { $in: [dim] } })
        .toArray();
    prismWebDB.getCollection('dashboards').find({ 'defaultFilters.jaql.dim': { $in: [dim] } });
    prismWebDB.getCollection('widgets')
        .find({ 'metadata.panels.items.jaql.dim': { $in: [dim] } });

    result.forEach(function (item) {
        logger('   ' + item.title);
    });
}

// Main script
load(scriptsPath + 'analyze_dim.js');
logger('   ');
logger('Compare two datasources usage');
//doCleanup = true;

var old_stat = datasourcesObj[old_ds];
var new_stat = datasourcesObj[new_ds];
var fCount = prismWebDB.getCollection('dashboards')
    .count({ 'filters.jaql.datasource.title': { $in: [old_ds] } });
var dfCount = prismWebDB.getCollection('dashboards')
    .count({ 'defaultFilters.jaql.datasource.title': { $in: [old_ds] } });
var dsCount = prismWebDB.getCollection('dashboards')
    .count({ 'datasource.title': { $in: [old_ds] } });
var wCount = prismWebDB.getCollection('widgets')
    .count({ 'metadata.panels.items.jaql.datasource.title': { $in: [old_ds] } });
logger('Old cube: ' + fCount + ' ' + 'filters');
logger('Old cube: ' + dfCount + ' ' + 'default filters');
logger('Old cube: ' + dsCount + ' ' + 'dashboard datasources');
logger('Old cube: ' + wCount + ' ' + 'widgets');

//logger(JSON.stringify(old_stat, undefined, 2));
logger('   ');
//logger(JSON.stringify(new_stat, undefined, 2));
//logger('   ');
//var result = findDifferences(new_stat, old_stat);
//print(JSON.stringify(result, undefined, 2));
if (old_stat) {
    Object.keys(old_stat).forEach(function (key) {
        var values = old_stat[key];
        var new_values = new_stat[key];

        if (typeof values == 'object') {
            //logger('Old cube: ' + old_ds);
            //printDIMStats(values, key);
            matchNewDS(values, new_values, key);
            //logger('New cube: ' + new_ds);
            //printDIMStats(new_values, key);
        }
        logger('   ');
    });
}

prismWebDB.getCollection('dashboards')
    .find({ 'filters.jaql.datasource.title': { $in: [old_ds] } })
    .forEach(function (dash) {
        logger(' ' + dash._id);
        if (dash.filters) {
            dash.filters.forEach(function (filter) {
                if (filter.jaql && filter.jaql.datasource) {
                    if (filter.jaql.datasource.title === old_ds) {

                        logger('Should replace filters DS ');
                        logger('  ' + filter.jaql.table + ' ' + filter.jaql.column + ' ' +
                            filter.jaql.dim + ' ');
                        //logger(JSON.stringify(filter.jaql, undefined, 2));
                        replaceDS(filter.jaql, dash);
                    }
                }
            });
        }
        replaceDS(dash, dash);
        logger('   ');
    });
prismWebDB.getCollection('dashboards')
    .find({ 'defaultFilters.jaql.datasource.title': { $in: [old_ds] } }).forEach(function (dash) {
    logger(' ' + dash._id);
    if (dash.defaultFilters) {
        dash.defaultFilters.forEach(function (filter) {
            if (filter.jaql && filter.jaql.datasource) {
                if (filter.jaql.datasource.title === old_ds) {
                    logger('   ');
                    logger('Should replace default filters DS ');
                    //logger(JSON.stringify(filter.jaql, undefined, 2));
                    logger('  ' + filter.jaql.table + ' ' + filter.jaql.column + ' ' +
                        filter.jaql.dim + ' ');
                    replaceDS(filter.jaql, dash);
                }
            }
        });
    }
    logger(' ');
});
prismWebDB.getCollection('widgets')
    .find({ 'metadata.panels.items.jaql.datasource.title': { $in: [old_ds] } })
    .forEach(function (widget) {
        widget.metadata.panels.forEach(function (panel) {
            panel.items.forEach(function (item) {
                if (item.jaql) {
                    if (item.jaql && item.jaql.datasource) {
                        if (item.jaql.datasource.title === old_ds) {
                            logger('   ');
                            logger('Should replace widget items DS ');
                            //logger(JSON.stringify(item.jaql, undefined, 2));
                            logger('  ' + item.jaql.table + ' ' + item.jaql.column + ' ' +
                                item.jaql.dim + ' ');
                            replaceWidgetDS(item.jaql, widget);
                        }
                    }
                }
            });
        });
        replaceWidgetDS(widget, widget);
    });

if (doCleanup) {
    logger(' Bulk execute');
    var resultD = bulkDashboards.execute();
    var resultW = bulkWidgets.execute();
    print(JSON.stringify(resultD, undefined, 2));
    print(JSON.stringify(resultW, undefined, 2));
}



