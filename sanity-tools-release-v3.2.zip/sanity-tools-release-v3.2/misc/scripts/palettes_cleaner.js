var palNames = [];
var palToRemove = [];
db.getCollection('palettes').find({}).forEach(function(pal){
    print(pal._id + ' ' + pal.name);
    if(palNames.indexOf(pal.name) === -1){
        palNames.push(pal.name)
    }
    else {
        palToRemove.push(pal._id)
    }
});
print(JSON.stringify(palToRemove, null, 2));
var result = db.palettes.remove({ '_id': { $in: palToRemove } });
print(JSON.stringify(result, null, 2));