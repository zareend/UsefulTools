/**
 * Script: Conditional formatting analyzer.
 * @author roman.hamretskyi@sisense.com
 * @description
 * Analyzes conditions in all widgets
 */
(function () {

    const prismWebDB = db.getSiblingDB('prismWebDB');
    let doCleanup = false;
    if (typeof globalCleanup !== 'undefined') {
        // global cleanup
        // comment line below to use local cleanup flag
        doCleanup = globalCleanup;
    }

    //region Common utils
    var scriptsFolder = '../scripts';
    var utilsFolder = '../utils';

    function loadScript(script, scriptPath) {
        var path;
        if (scriptPath) {
            path = scriptPath + '/' + script;
            load(path);
        } else if (scriptsFolder) {
            path = scriptsFolder + '/' + script;
            load(path);
        } else {
            load(script);
        }
    }

    loadScript('utils.js', utilsFolder);
    //endregion
    printHeader();

    function fatDelimiter() {
        print('================================================================================================================');
    }

    function thinDelimiter() {
        print('----------------------------------------------------------------------------------------------------------------');
    }

    /**
     * Configuration section of the script
     */
    /**
     * If you want to see the progress of run specify the this flag as true, then you'll see how many dashboards are checked
     * and how many are left to check. Also you will see how much time each dashboard check consumes
     * @type {boolean}
     */
    const PRINT_DEBUG_INFO = true;

    if (!Object.entries) {
        Object.entries = function( obj ){
            var ownProps = Object.keys( obj ),
                i = ownProps.length,
                resArray = new Array(i); // preallocate the Array
            while (i--)
                resArray[i] = [ownProps[i], obj[ownProps[i]]];

            return resArray;
        };
    }

    const operationTime = () => {
        const start = new Date();

        return () => `${new Date() - start} ms`;
    };

    const debug = msg => {
        PRINT_DEBUG_INFO && print(msg);
    };

    function printScriptConfiguration() {
        print(`Starting conditionals analyze script run. Buckle up...`);
        print(`Script will be running with the following configuration:`);
        thinDelimiter();
        print(`Printing of debug info is ${PRINT_DEBUG_INFO ? 'enabled' : 'disabled'}`);
        fatDelimiter();
    }

    function guidFast (len) {

        if (!len) {

            len = 20;
        }

        var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
        var uuid = new Array(len), rnd = 0, r;

        for (var i = 0; i < len; i++) {

            if (i > 0 && i % 5 === 0) {

                uuid[i] = '-';
                continue;
            }

            if (rnd <= 0x02) {

                rnd = 0x2000000 + (Math.random() * 0x1000000) | 0;
            }

            r = rnd & 0xf;
            rnd = rnd >> 4;
            uuid[i] = chars[(i === 19) ? (r & 0x3) | 0x8 : r];
        }
        return uuid.join('');
    }

    function generateGuid(bracket) {
        if (bracket) {
            return '[' + guidFast(9) + ']';
        }
        return guidFast(9);
    }

    const outBrackets = (string) => {

        // validate;
        if (typeof string === 'string' || !string.length) {
            return;
        }

        if (string[0] === '[') {
            string = string.substring(1);
        }

        if (string.length > 0) {
            if (string[string.length - 1] === ']') {
                string = string.substring(0, string.length - 1);
            }
        }

        return string;
    };

    const sortBy = (iterateFunc) => {
        return (a, b) => (iterateFunc(a) > iterateFunc(b)) ? 1 : ((iterateFunc(b) > iterateFunc(a)) ? -1 : 0);
    };

    function generateNewGUID (jaql) {

        // validate.
        if (!jaql || !jaql.context || !jaql.formula) {
            return;
        }

        let key, val, guid;

        const entries = Object.entries(jaql.context);
        const pairs = entries.concat().sort(sortBy(function (p) { return p[0].length; })).reverse();

        pairs.forEach(p => {

            key = p[0];
            val = p[1];
            guid = generateGuid(true);

            jaql.context[guid] = val;
            val.title = val.title || outBrackets(key);
            delete jaql.context[key];
            let i = 100;
            while (--i && jaql.formula.indexOf(key) > -1) jaql.formula = jaql.formula.replace(key, guid);
        });
    }

    try {
        printScriptConfiguration();
        const query = {
            'metadata.panels': {
                $elemMatch: {
                    items: {
                        $elemMatch: {
                            'format.color.conditions': {
                                $elemMatch: {
                                    'expression.jaql': { $exists: true }
                                }
                            }
                        }
                    }
                }
            }
        };
        const scriptTime = operationTime();
        fatDelimiter();
        print(`Fetching all widgets: ${JSON.stringify(query)}`);

        const widgetsCursor = prismWebDB.getCollection('widgets').find(query);

        const numOfWidgets = widgetsCursor.count();
        let widgetIndex = 1;
        let numOfCorrupted = 0;
        let numOfFixed = 0;
        print(`Num of widgets to check: ${numOfWidgets}`);
        fatDelimiter();

        widgetsCursor.forEach(widget => {
            const widgetTimeConsumed = operationTime();
            let contextList = [];
            let hasGUIDDuplicate = false;
            let numOfBroken = 0;
            debug(`Checking widget ${widget._id.str}. Dashboard id: ${widget.dashboardid.str} -- ${widgetIndex}/${numOfWidgets}`);
            widget.metadata.panels.forEach(panel => {
                (panel.items || []).forEach(item => {
                    try {
                        if (item.format && item.format.color && item.format.color.type === 'condition') {
                            const { conditions } = item.format.color;
                            conditions.forEach(condition => {
                                let { jaql } = condition.expression;

                                if (jaql) {
                                    const { context } = jaql;
                                    const keys = Object.keys(context);
                                    for (let key of keys) {
                                        if (contextList.includes(key)) {
                                            numOfBroken++;
                                            hasGUIDDuplicate = true;

                                            if (doCleanup) {
                                                // generate and replace GUID
                                                generateNewGUID(jaql);
                                                prismWebDB.getCollection('widgets').update({
                                                    _id: widget._id
                                                }, widget);
                                            }
                                            break;
                                        } else {
                                            contextList.push(key);
                                        }
                                    }
                                }
                            });
                        }
                    } catch (e) {
                        print(`Widget conditionals analyze error: ${e}`);
                    }
                })
            })

            if (hasGUIDDuplicate) {
                print('Conditions have duplicates');
                numOfCorrupted++;

                if (doCleanup) {
                    numOfFixed++;
                    print(`${numOfBroken} conditions fixed!`);
                }
            }

            widgetIndex++;
            debug(`Widget ${widget._id.str} check time consumed ${widgetTimeConsumed()}`);
            thinDelimiter();
        });

        fatDelimiter();
        print('Analyze ended. The results of analyze operation are:');
        fatDelimiter();
        print(`Total number of widgets with corrupted conditions: ${numOfCorrupted}`);
        thinDelimiter();
        print(`Total number of widgets with fixed conditions: ${numOfFixed}`);
        fatDelimiter();

        print(`Run ended successfully.`);
        debug(`Time consumed: ${scriptTime()}`);
    } catch (error) {
        print(`Error occurred during script execution: ${error}`);
        error.stack && print(error.stack);
        print('Please see the usage notes at the top. If the error is not clear, please contact the author of the script.');
    }
})();
