var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

//Dashboards: (will include all instances of the dashboard owner, proxy, user)

prismWebDB.getCollection('dashboards').find({ script: { '$exists': true, '$ne': '' } });

//Widgets: (will include all instances of the widget owner, proxy, user)

prismWebDB.getCollection('widgets').find({ script: { '$exists': true, '$ne': '' } });