var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

var stringToReplace = "https://oldserverdomain.com"; //Enter the string
var findURL = new RegExp(stringToReplace, "gi");
var replaceURL = 'https://newserverdomain.com';

prismWebDB.getCollection('dashboards').find({ script: findURL }).forEach(function(a){
    print(a);
    var newScript = a.script.replace(findURL, replaceURL);
    prismWebDB.getCollection('dashboards').update(
        { _id: a._id },
        { $set: { 'script': newScript } },
        { multi: false }
    )
});