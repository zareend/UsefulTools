var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

// Script to delete unused connection objects (username/password) which aren't being used anymore

prismWebDB.connections.aggregate([
    {
        $lookup:
            {
                from: 'datasets',
                localField: '_id',
                foreignField: 'connection',
                as: 'matched_docs'
            }
    },
    {
        $match: { 'matched_docs': { $eq: [] } }
    }
]).forEach(function (connectionDoc) {
    //print(connectionDoc);
    const isConnectionBeingUsed = prismWebDB.datasets.findOne({ connection: connectionDoc._id });
    if (!isConnectionBeingUsed) {
        const result = prismWebDB.connections.deleteOne({ _id: connectionDoc._id });
        if (result.deletedCount !== 1) {
            print('did not manage to delete connection _id:' + connectionDoc._id.str);
        }
    }
});