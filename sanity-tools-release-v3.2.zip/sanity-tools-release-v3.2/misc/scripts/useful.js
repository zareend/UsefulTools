db.getCollection('dashboards').aggregate([
    { '$project': { 'datasource': '$datasource' } }, {$group: {_id: "$datasource", count: {$sum: 1}}}, {$sort: {count: -1}},
]);
db.getCollection('widgets').aggregate([
    { '$project': { 'datasource': '$datasource' } }, {$group: {_id: "$datasource", count: {$sum: 1}}}, {$sort: {count: -1}},
]);