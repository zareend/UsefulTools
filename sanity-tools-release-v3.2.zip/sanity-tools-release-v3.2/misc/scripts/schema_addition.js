/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Schemas Script';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion
printHeader();
printConfig(config);

var result = prismWebDB.runCommand( {
    collMod: "users",
    validator: {
        $jsonSchema: {
            "bsonType": "object",
            "required": [ "userName", "email", "groups", "created", "lastUpdated" ],
            "additionalProperties": true,
            "properties": {
                "active": {
                    "bsonType": "bool",
                    "description": "must be a string and is required"
                },
                "created": {
                    "bsonType": "date",
                    "description": "must be a date and is required"
                },
                "lastActivity": {
                    "bsonType": "date",
                    "description": "must be a date and is required"
                },
                "lastLogin": {
                    "bsonType": "date",
                    "description": "must be a date and is required"
                },
                "lastUpdated": {
                    "bsonType": "date",
                    "description": "must be a date and is required"
                },
                "ssoTokenIat": {
                    "bsonType": "double",
                    "description": "must be a number"
                },
                "userName": {
                    "bsonType": "string",
                    "description": "must be a string and is required"
                },
                "firstName": {
                    "bsonType": "string",
                    "description": "must be a string if the field exists"
                },
                "lastName": {
                    "bsonType": "string",
                    "description": "must be a string if the field exists"
                },
                "email": {
                    "bsonType": "string",
                    "pattern" : "^(([^<>()[\\]\\\\.,;:\\s@\\\"]+(\\.[^<>()[\\]\\\\.,;:\\s@\\\"]+)*)|(\\\".+\\\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$",
                    "description": "must be a string and match the regular expression pattern"
                },
                "groups": {
                    "bsonType": "array",
                    "items": {
                        "bsonType": "string",
                        "description": ""
                    },
                    "uniqueItems": true,
                    "description": "can only be one of the enum values and is required"
                },
                "preferences": {
                    "bsonType": "object",
                    "properties": {
                        "language": {
                            "bsonType": "string",
                            "description": "must be a string and is required"
                        },
                        "localeId": {
                            "bsonType": "string",
                            "description": "must be a string and is required"
                        }
                    }
                },
                "secrets": {
                    "bsonType": "object",
                    "required": [ "devices", "tokens" ],
                    "properties": {
                        "tokens": {
                            "bsonType": "object",
                            "required": [ "api" ],
                            "properties": {
                                "api": {
                                    "bsonType": "string",
                                    "description": "must be a string and is required"
                                },
                                "sso": {
                                    "bsonType": "string",
                                    "description": "must be a string and is required"
                                }
                            }
                        },
                        "devices": {
                            "bsonType": "object",
                            "description": "must be a string and is required"
                        }
                    }
                },
                "hash": {
                    "bsonType": "object",
                    "required": [ "hash", "salt", "type" ],
                    "properties": {
                        "hash": {
                            "bsonType": "string",
                            "description": "must be a string and is required"
                        },
                        "salt": {
                            "bsonType": "string",
                            "description": "must be a string and is required"
                        },
                        "type": {
                            "bsonType": "string",
                            "description": "must be a string and is required"
                        }
                    }
                },
                "roleId": {
                    "bsonType": "objectId",
                    "description": "can only be one of the specified objectId values"
                }
            }
        }
    },
    validationLevel: "strict", // strict / moderate
    validationAction : "error" // error / warn
});

print(JSON.stringify(result));
