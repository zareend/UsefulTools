// General Info
var version = '3.1.3';

var prismWebDB = db.getSiblingDB('prismWebDB');

prismWebDB.getCollection('users')
    .find({ ldapDomainId: { $type: 'string' } })
    .forEach(function (user) {
        prismWebDB.getCollection('users').updateOne(
            { _id: user._id },
            { $set: { ldapDomainId: ObjectId(user.ldapDomainId) } },
            { upsert: true }
        );
    });
