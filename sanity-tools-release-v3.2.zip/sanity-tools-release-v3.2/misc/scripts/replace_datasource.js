// General Info
var version = '3.1.3';

var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

var address = '10.50.6.13';
var newAddress = 'LocalHost';

function replaceDatasource(datasource) {
    if (datasource.fullname) {
        datasource.fullname = datasource.fullname.replace(address, newAddress);
    }
    if (datasource.id) {
        var searchStr = address.replace('.', 'LgAa');
        searchStr = 'a' + searchStr.toUpperCase() + '_a';
        var replaceStr = 'a' + newAddress.toUpperCase() + '_a';
        datasource.id = datasource.id.replace(searchStr, replaceStr);
    }

    if (datasource.address) {
        datasource.address = datasource.address.replace(address, newAddress);
    }
    return datasource;
}

function replaceDIM (jaql) {
    if (jaql.table && jaql.column) {
        jaql.dim = '[' + jaql.table + '.' + jaql.column + ']';
    }

    return jaql;
}

try {
    prismWebDB.getCollection('dashboards').find({ 'datasource.address': address }).forEach(function (e) {
        if (e.datasource) {
            e.datasource = replaceDatasource(e.datasource);
        }
        if (e.widgets) {
            e.widgets.forEach(function (r) {
                if (r.datasource) {
                    r.datasource = replaceDatasource(r.datasource);
                }

                if (r.metadata && r.metadata.panels && r.metadata.panels.items) {
                    r.metadata.panels.items.forEach(function (h) {
                        if (h.jaql && h.jaql.datasource) {
                            h.jaql.datasource = replaceDatasource(h.jaql.datasource);
                        }
                        if (h.jaql) {
                            h.jaql = replaceDIM(h.jaql);
                        }
                    });
                }

            });
        }
        if (e.filters) {
            e.filters.forEach(function (r) {
                if (r.jaql) {
                    var datasource = r.jaql.datasource;
                    r.jaql = replaceDIM(r.jaql);
                } else {
                    print('no r.jaql');
                }

                if (datasource) {
                    r.jaql.datasource = replaceDatasource(datasource);
                }

                if (r.levels) {
                    r.levels.forEach(function (level) {
                        var levelDatasource = level.datasource;
                        if (levelDatasource) {
                            level.datasource = replaceDatasource(levelDatasource);
                        }
                        replaceDIM(level);
                    });
                }
            });
        }
        if (e.defaultFilters) {
            e.defaultFilters.forEach(function (r) {
                if (r.jaql) {
                    var datasource = r.jaql.datasource;
                    r.jaql = replaceDIM(r.jaql);
                } else {
                    print('no r.jaql');
                }
                if (datasource) {
                    r.jaql.datasource = replaceDatasource(datasource);
                }
                if (r.levels) {
                    r.levels.forEach(function (level) {
                        var levelDatasource = level.datasource;
                        if (levelDatasource) {
                            level.datasource = replaceDatasource(levelDatasource);
                        }
                        replaceDIM(level);
                    });
                }

            });
        }

        prismWebDB.getCollection('dashboards').save(e);
    });
} catch (e) {
    print(e);
}

try {
    prismWebDB.getCollection('widgets').find({ 'datasource.address': address }).forEach(function (e) {
        if (e.datasource) {
            e.datasource = replaceDatasource(e.datasource);
        }
        if (e.metadata && e.metadata.panels) {
            e.metadata.panels.forEach(function (panel) {
                panel.items.forEach(function (h) {
                    if (h.jaql && h.jaql.datasource) {
                        h.jaql.datasource = replaceDatasource(h.jaql.datasource);
                    }
                    if (h.jaql) {
                        h.jaql = replaceDIM(h.jaql);
                    }
                });
            });
        }
        prismWebDB.getCollection('widgets').save(e);
    });
} catch (error) {
    print(error);
}
