var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

// Insert dashboards you'd like to retrieve the owner for:
var dashboards = [
    ObjectId('553a4347743e0a6812000002'),
    ObjectId('56fe384b4427711048000024')
];

var arr = [];
prismWebDB.dashboards.find({ oid: { $in: dashboards }, instanceType: 'owner' }).forEach((dashboard) => {

    var obj = {
        dash: dashboard.oid.valueOf(),
        user: dashboard.owner
    };
    arr.push(obj);

});

arr.forEach((obj) => {
    obj.userName = prismWebDB.getCollection('users').findOne({ _id: obj.user }).userName;
    delete obj.user;
});

arr.forEach((obj) => {
    print(obj.dash + ',' + obj.userName);
});