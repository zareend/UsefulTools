//only print stats

var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

var statsArr = [];
var collectionsDB = prismWebDB.getCollectionNames();
var collectionsConfig = prismConfig.getCollectionNames();
var collectionsMonitor = prismMonitor.getCollectionNames();
// print('  ');
// print('Data Size (GB) = ' + dataSizeInGB + '\nIndex Size (MB) = ' + indexSizeInGB);
// print('  ');
//print('prismWebDB collections items count: ');
collectionsDB.forEach(function (collection) {
    var stats = prismWebDB.getCollection(collection).stats();
    var obj = {};

    obj.Name = collection;
    obj.TotalSizeInMB = stats.size / 1000000;
    obj.NumberOfDocuments = stats.count;
    obj.StorageSizeInMB = stats.storageSize / 1000000;
    obj.totalIndexSizeInMB = stats.totalIndexSize / 1000000;
    obj.currentCacheInMB = stats.wiredTiger.cache['bytes currently in the cache'] / 1000000;
    obj.fileSizeInMB = stats.wiredTiger['block-manager']['file size in bytes'] / 1000000;

    statsArr.push(obj);
});
//print('  ');
//print('prismConfig collections items count: ');
collectionsConfig.forEach(function (collection) {
    var stats = prismConfig.getCollection(collection).stats();
    var obj = {};

    obj.Name = collection;
    obj.TotalSizeInMB = stats.size / 1000000;
    obj.NumberOfDocuments = stats.count;
    obj.StorageSizeInMB = stats.storageSize / 1000000;
    obj.totalIndexSizeInMB = stats.totalIndexSize / 1000000;
    obj.currentCacheInMB = stats.wiredTiger.cache['bytes currently in the cache'] / 1000000;
    obj.fileSizeInMB = stats.wiredTiger['block-manager']['file size in bytes'] / 1000000;

    statsArr.push(obj);
});
//print('  ');
//print('monitor collections items count: ');
collectionsMonitor.forEach(function (collection) {
    var stats = prismMonitor.getCollection(collection).stats();
    var obj = {};

    obj.Name = collection;
    obj.TotalSizeInMB = stats.size / 1000000;
    obj.NumberOfDocuments = stats.count;
    obj.StorageSizeInMB = stats.storageSize / 1000000;
    obj.totalIndexSizeInMB = stats.totalIndexSize / 1000000;
    obj.currentCacheInMB = stats.wiredTiger.cache['bytes currently in the cache'] / 1000000;
    obj.fileSizeInMB = stats.wiredTiger['block-manager']['file size in bytes'] / 1000000;

    statsArr.push(obj);
});
//print('  ');
print(JSON.stringify(statsArr, null, 2));
//print('  ');
