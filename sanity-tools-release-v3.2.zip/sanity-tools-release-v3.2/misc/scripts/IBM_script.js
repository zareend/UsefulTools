var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

var doUpdate = false;

var oldDomainId = '';
var newDomainId = '5c98ef4c7879fa1748fa3d2b';
prismWebDB.getCollection('groups')
    .find({ 'ldapDomainId': ObjectId(oldDomainId) })
    .forEach(function (group) {
        prismWebDB.getCollection('groups').update(
            { '_id': group._id },
            { $unset: { 'objectSid': '' }, $set: { 'ldapDomainId': ObjectId(newDomainId) } },
            { multi: true }
        );
    });
prismWebDB.getCollection('users')
    .find({ 'ldapDomainId': ObjectId(oldDomainId) })
    .forEach(function (user) {
        prismWebDB.getCollection('users').update(
            { '_id': user._id },
            { $unset: { 'objectSid': '' }, $set: { 'ldapDomainId': ObjectId(newDomainId) } },
            { multi: true }
        );
    });

prismWebDB.getCollection('users')
    .find({ 'ldapDomainId': ObjectId(newDomainId) })
    .forEach(function (user) {
        print(user.principalName);
        if (user.principalName.indexOf('@il.ibm.com') !== -1) {
            print('should update principalName');
            var newPrincipalName = user.principalName.split('@')[0] + '@xxx.il.ibm.com';
            print(' new principalName ' + newPrincipalName);
            if (doUpdate) {
                prismWebDB.getCollection('users').update(
                    { '_id': user._id },
                    { $set: { 'principalName': newPrincipalName } },
                    { multi: true }
                );
            }

        } else {
            print(' principal name ok');
        }
    });

// do force sync ldap after this changes
