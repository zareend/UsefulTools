// This script replaces the current Sisense web application Sys Admin user with another existing user
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');


// Valid roles (friendly name in parentheses):
//     "admin" (administrator)
//     "contributor" (designer)
//     "dataAdmin" (data administrator)
//     "dataViewer" (data viewer)

var new_sys_admin_email = 'sovenshinery@gmail.com'; // Email address of new Sys. Admin user (user must already exist)
var current_sys_admin_new_role = 'contributor'; // New role for the current Sys. Admin user

var valid_users = [];
prismWebDB.users.find().forEach(function (row) {
    valid_users.push(row.email);
});

var valid_roles = [];
prismConfig.compiled_roles.find().forEach(function (row) {
    valid_roles.push(row.name);
});

if (!valid_roles.includes(current_sys_admin_new_role)) {

    print('Error: Invalid role name');

} else {

    if (!valid_users.includes(new_sys_admin_email)) {

        print('Error: Invalid user email address');

    } else {

        var super_id = prismConfig.compiled_roles.findOne({ name: { $in: ['super'] } },
            { _id: 1 }
        )['_id'].valueOf();
        var alt_id = prismConfig.compiled_roles.findOne({ name: { $in: [current_sys_admin_new_role] } },
            { _id: 1 }
        )['_id'].valueOf();

        var current_super = prismWebDB.users.find({ 'roleId': ObjectId(super_id) }, { 'email': 1, '_id': 0 })
            .toArray()[0]['email'];

        if (current_super === new_sys_admin_email) {
            print('Error: New Sys. Admin is identical to the current Sys. admin');
        } else {

            prismWebDB.users.updateOne(
                { 'email': new_sys_admin_email },
                { $set: { 'roleId': ObjectId(super_id) } }
            );

            prismWebDB.users.updateOne({
                    'email': current_super
                },
                { $set: { 'roleId': ObjectId(alt_id) } }
            );
        }
    }
}
