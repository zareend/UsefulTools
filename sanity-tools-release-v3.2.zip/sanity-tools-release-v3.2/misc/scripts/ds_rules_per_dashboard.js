var dashboardId = '5c0713fdb577c44a38c06734'; // Set the dashboard ID here

var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

var filters = prismWebDB.getCollection('dashboards')
    .findOne({ instanceType: 'owner', oid: ObjectId(dashboardId) }).filters;

var filterDims = [];

function getDims(jaql) {

    var tbl = jaql.table;

    var col = jaql.column;
    var obj = {
        table: tbl,
        column: col
    };
    filterDims.push(obj);
}

// iterate over each filter, also dependent filters
filters.forEach((filter) => {

    if (!filter.isCascading && filter.jaql) {
        getDims(filter.jaql);
    } else if (filter.isCascading && filter.levels) {
        filter.levels.forEach(jaql => {
            getDims(jaql);
        });
    }
});

print(filterDims);

// Check Data Security rules per dimension
filterDims.forEach((filterDim) => {

    print('Found ' + db.getCollection('dataContext')
        .find({ table: filterDim.table, column: filterDim.column })
        .count() + ' rules for dimension [' + filterDim.table + '.' + filterDim.column + ']');

});