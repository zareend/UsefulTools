/**
 * Created by yaroslav.korzh
 * Updated 27/07/2020
 */

// General Info
var version = 'custom';
var scriptName = 'Widget normalizer';

// Configuration
var showLogs = true;
var startDate = new Date();
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showWidgetDuplicates: true,
        showLogs: showLogs
    }
};
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';

function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    } else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}

loadScript('utils.js', utilsFolder);
//endregion
var collectedStats = {};
var bulk = prismWebDB.getCollection('widgets').initializeUnorderedBulkOp();
var limit = 1000;
var queryLimit = 0;
var skip = 0;
var logsStatus = getStatus(showLogs);
var cleanupStatus = getStatus(doCleanup);
function printSummary() {
    logger('   ');
    divider();
    logger('Scripts statistics ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    var endDate = new Date();
    var execTime = timeDiff(startDate, endDate);
    logger('Execution time ' + execTime.seconds + ' seconds ');
    var total = 0;
    if (typeof collectedStats !== 'undefined') {
        Object.keys(collectedStats).sort().forEach(function (key) {
            var value = collectedStats[key];
            if (value > 0) {
                logger(' - ' + key + ': ' + value + ' items');
            }
            total += value;
        });
    }

    if (total > 0) {
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + total);
    }
    logger(' ');

    divider();
}

function checkAggCases(agg) {
    if (agg.length > 0) {
        logger('Widgets have multiple documents with same oid and different instanceType');
        logger(' ');
        agg.forEach(function (elem) {
            collectStats('widget_same_oid_for_different_instance_types', 1);
            var dashboards = [];
            var message = ' duplicated case: ' + secureOutput(elem.docs[0].title) +
                ' oid ' + elem.docs[0].oid +
                ' dashboardid ' + elem.docs[0].dashboardid +
                ' instanceType ' + elem.docs[0].instanceType +
                ' userId ' + elem.docs[0].userId +
                ' created ' + elem.docs[0].created +
                ' has ' + elem.docs.length +
                ' items';

            var realOwner;
            prismWebDB.getCollection('dashboards').find({instanceType: 'owner', oid: elem.docs[0].dashboardid}).forEach(function (dash) {
                realOwner = dash.owner;
                logger('Real owner: '+ realOwner);
            });
            logger(message);
            elem.docs.forEach(function (doc) {
                var msg = '  - ';
                var shouldRemove = false;
                if ((parseObjectIdToString(doc['userId']) !==
                    parseObjectIdToString(doc['owner'])) && doc['instanceType'] === 'owner') {
                    shouldRemove = true;
                    msg += ' ! remove owner instance: ';
                    bulk.find({'_id': doc._id}).remove();
                }
                if ((parseObjectIdToString(doc['userId']) ===
                    parseObjectIdToString(doc['owner'])) && doc['instanceType'] !== 'owner') {
                    shouldRemove = true;
                    msg += ' ! remove not owner instance: ';
                    bulk.find({'_id': doc._id}).remove();
                }
                if ((parseObjectIdToString(doc['userId']) === null) && doc['instanceType'] !==
                    'proxy') {
                    shouldRemove = true;
                    msg += ' ! remove not proxy instance: ';
                    bulk.find({'_id': doc._id}).remove();
                }
                if ((parseObjectIdToString(realOwner) !==
                    parseObjectIdToString(doc['owner'])) && doc['instanceType'] === 'owner') {
                    shouldRemove = true;
                    msg += ' ! widget owner is not dash owner: ';
                    collectStats('widget_owner_is_not_dash_owner', 1);
                    bulk.find({'_id': doc._id}).remove();
                }
                if(!shouldRemove) {
                    msg += '!!! valid: ';
                    collectStats('widget_same_oid_for_valid_instance', 1);
                }
                Object.keys(documentKeys).forEach(function (key) {
                    if (key === 'title') {
                        msg += key + ': ' + secureOutput(doc[key]) + ' | ';
                    } else if (key === 'oid' || key === '_id' || key === 'dashboardid') {
                        msg += '';
                    } else {
                        msg += key + ': ' + doc[key] + ' | ';
                    }

                });
                var dash = parseObjectIdToString(doc.dashboardid);
                if (dashboards.indexOf(dash) === -1) {
                    dashboards.push(dash);
                }

                if (config.logging.showWidgetDuplicates) {
                    logger(msg);
                }
            });
            if (dashboards.length > 1) {
                logger('Dashboards: ' + JSON.stringify(dashboards));
                collectStats('widget_same_oid_for_different_dashboards', dashboards.length);
            }
            logger(' ');
        });
        logger(' ');
    }
}
function getAggQuery(aggObject) {
    var query = [];
    if (queryLimit > 0) {
        query.push({ $limit: queryLimit });
    }
    if (skip > 0) {
        query.push({ $skip: skip });
    }
    query.push({
        $group: {
            _id: aggObject,
            count: { $sum: 1 },
            docs: { $push: documentKeys }
        }
    });
    query.push({
        $match: {
            count: { $gt: 1 }
        }
    });

    return query;
}
var documentKeys = {
    title: '$title',
    oid: '$oid',
    instanceType: '$instanceType',
    dashboardid: '$dashboardid',
    userId: '$userId',
    owner: '$owner',
    created: '$created',
    _id: '$_id'
};
var widgetAgg = {
    dashboardid: "$dashboardid",
    oid: '$oid',
    userId: '$userId'
};
var aggregationOptions = {
    allowDiskUse: true
};
var widgetAggQuery = getAggQuery(widgetAgg);
var resultsGlobal = prismWebDB.getCollection('widgets')
    .aggregate(widgetAggQuery, aggregationOptions)
    .toArray();
logger('Aggregated widgets by oid & userId where count > 1: ' + resultsGlobal.length);

checkAggCases(resultsGlobal);
if (config.cleanup.doCleanup) {
    logger('Bulk widgets delete execute');
    var bulkResult = bulk.execute();
    logger(bulkResult);
}

printSummary();
