// noinspection SpellCheckingInspection
function findByProp(o, prop, val, retprop) {
    if (o[prop] === val) {
        return (retprop) ? o[retprop] : o;
    }
    var result = {}, p;
    for (p in o) {
        if (o[p] === val) {
            return (retprop) ? o[retprop] : o;
        }
        if (o.hasOwnProperty(p) && typeof o[p] === 'object') {
            result = findByProp(o[p], prop, val);
            if (result) {
                return (retprop) ? result[retprop] : result;
            }
        }
    }
    return (retprop) ? result[retprop] : result;
}

var prismWebDB = db.getSiblingDB('prismWebDB');
var collections = prismWebDB.getCollectionNames();


var targetString = '';


collections.forEach(function (item) {
    var collectionTotal = prismWebDB.getCollection(item).count();
    print('==========================================');
    print(item + ' : ' + collectionTotal + ' items');
    print(' ');
    var results = prismWebDB.getCollection(item).aggregate([
        { '$project': { 'arrayofkeyvalue': { '$objectToArray': '$$ROOT' } } },
        { '$addFields': { 'values': '$arrayofkeyvalue.v' } },
        { '$addFields': { 'keys': '$arrayofkeyvalue.k' } },
        { '$addFields': { 'types': '$keys' } },
        {
            $project: {
                keys: '$keys',
                values: '$values',
                types:
                    {
                        $map:
                            {
                                input: '$values',
                                as: 'type',
                                in: { $type: '$$type' }
                            }
                    }
            }
        }
    ]);
    results.forEach(function (result) {
        result.types.forEach(function (type, index) {
            var key = result.keys[index];
            var val = result.values[index];

            var res = findByProp(val, null, targetString);
            if (res && res.length > 0) {
                print(result.values[0] + ' ' + key + ': ' + JSON.stringify(res));
            }
            // if (val === targetString) {
            //     print(type + ' ' + key + ': ' + val);
            // }
        });
    });
});

/*
var collections = ['dashboards'];

prismWebDB.dashboards.aggregate([
    {
        '$project': {
            'data': { '$objectToArray': '$$ROOT' }
        }
    },
    { '$project': { 'data': '$data.k' } },
    { '$unwind': '$data' },
    {
        '$group': {
            '_id': null,
            'keys': { '$addToSet': '$data' }
        }
    }
]);

prismWebDB.getCollection('dashboards').aggregate(
    [
        {
            '$project': {
                'userId': '$userId',
                'fieldTypeUserId': { '$type': '$userId' },
                'fieldTypeOwner': { '$type': '$owner' }
            }
        }
    ]
);

db.dashboards.aggregate([
    {"$project":{"arrayofkeyvalue":{"$objectToArray":"$$ROOT"}}},
    {"$project":{"keys":"$arrayofkeyvalue.k"}}
])

mr = db.runCommand({
    "mapreduce" : "dashboards",
    "map" : function() {
        for (var key in this) { emit(key, null); }
    },
    "reduce" : function(key, stuff) { return null; },
    "out": "dashboards" + "_keys"
})
db[mr.result].distinct("_id")
 */



