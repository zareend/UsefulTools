/**
 * Created by yaroslav korzh on 8/11/2017.
 * Updated 11/06/2018
 */
var version = '3.1.3';
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var cleanupStatus = doCleanup ? 'enabled' : 'disabled';
var showLogs = true;
var logsStatus = showLogs ? 'enabled' : 'disabled';
var showUserAndProxy = false;
var showParentInfo = true;

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion
function getWidgetInfo(id, sourceSearch) {
    var text;
    if (showParentInfo) {
        var searchId = parseStringToObjectId(id);
        var result = db.getCollection('widgets').find({
            _id: searchId
        }).toArray();
        db.getCollection('widgets').find({
            _id: searchId
        }).forEach(function (widget) {
            text = 'widget info';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('********************* ' + text + ' ********************************');
            logger(secureOutput(widget.title) + ' | ' + widget.oid + ' | ' + widget._id + ' | ' + widget.source +
                ' | ' + widget.created + ' | ' + widget.dashboardid + ' | ' + widget.owner + ' | ' +
                widget.instanceType + ' | ' + widget.userId + ' | ' + widget.lastUpdated + ' | ' +
                widget.lastUsed);
            //getDashboardInfo(widget.dashboardid)
            if (widget.source) {
                getWidgetInfo(widget.source, true);
            }
            logger('******************************************************************');
        });

        if (result.length === 0) {
            text = 'widget not found';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('************************* ' + text + ' *******************************');
        }
    }

}

function getDashboardInfo(id, sourceSearch) {
    var text;
    if (showParentInfo) {
        logger('Sourced from:');
        var searchId = parseStringToObjectId(id);
        var searchObj = {
            instanceType: 'owner'
        };
        if (sourceSearch) {
            searchObj['_id'] = searchId;
        } else {
            searchObj['oid'] = searchId;
        }
        var result = db.getCollection('dashboards').find(searchObj).toArray();

        db.getCollection('dashboards').find(searchObj).forEach(function (dash) {
            text = 'Dashboard info';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('********************* ' + text + ' ********************************');
            logger('Dashboard: ' + dash._id + ' | ' + secureOutput(dash.title) + ' | ' + dash.oid + ' | ' +
                dash.instanceType + ' | ' + dash.owner + ' | ' + dash.source + ' | ' +
                dash.lastUpdated);
            if (dash.source) {
                getDashboardInfo(dash.source, true);
            }
            logger('*********************************************************************');
        });

        if (result.length === 0) {
            text = 'dashboard not found';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('************************* ' + text + '*******************************');
        }
    }

}

function fixWidgetAggInstance(widgetAggResult) {
    var data = {};
    var isOwner = widgetAggResult._id.instanceType === 'owner';

    if (widgetAggResult) {
        if (isOwner) {
            var owner = {};

            db.getCollection('users').find({ _id: widgetAggResult._id.userId }).forEach(function (user) {
                logger('User: ' + user.userName + ' | ' + user._id);
                Object.keys(owners).forEach(function (item) {
                    var userObj = owners[item];
                    if (userObj.name === user.userName) {
                        owner = owners[user.userName];
                    }
                });

                data.user = user.userName;
                owner.name = user.userName;

                db.getCollection('dashboards').find({
                    oid: widgetAggResult._id.dashboardid,
                    instanceType: widgetAggResult._id.instanceType
                }).forEach(function (dash) {
                    var dashboard = {};
                    logger('Dashboard: ' + secureOutput(dash.title) + ' | ' + dash.oid + ' | ' +
                        dash.instanceType + ' | ' + dash.owner + ' | ' + dash.created + ' | ' +
                        dash.lastUpdated + ' | ' + dash.source);
                    data.dashoid = dash.oid;
                    data.dashboardtitle = secureOutput(dash.title);
                    dashboard.dashboardId = dash.oid;
                    dashboard.dashboardtitle = secureOutput(dash.title);

                    if (!owner.dashboards) {
                        owner.dashboards = {};
                    }
                    if (!owner.dashboards[dashboard.dashboardId.valueOf()]) {
                        owner.dashboards[dashboard.dashboardId.valueOf()] = dashboard;
                    }
                    if (dash.source !== 'undefined') {
                        getDashboardInfo(dash.source, true);
                    }

                });
                owners[owner.name] = owner;
            });
            var dashboardCount = db.getCollection('dashboards').count({
                oid: widgetAggResult._id.dashboardid,
                instanceType: widgetAggResult._id.instanceType
            });
        } else if (showUserAndProxy) {
            logger('widgetAggResult is ' + widgetAggResult._id.instanceType +
                ' instance. Fixing owner instances solves it.');//+ ' | ' + widgetAggResult._id.owner + ' | ' + widgetAggResult._id.userId
            //logger('Widget: ' + widgetAggResult._id.title + ' | ' + widgetAggResult._id.oid + ' | ' + widgetAggResult._id._id + ' | ' + widgetAggResult._id.source  +' | ')
            db.getCollection('widgets').find({
                oid: widgetAggResult._id.oid,
                userId: widgetAggResult._id.userId,
                instanceType: widgetAggResult._id.instanceType
            }).sort({ lastUpdated: -1 }).forEach(function (widget) {
                logger(secureOutput(widget.title) + ' | ' + widget.oid + ' | ' + widget._id + ' | ' +
                    widget.source + ' | ' + widget.instanceType + ' | ' + widget.owner + ' | ' +
                    widget.userId + ' | ' + widget.dashboardid + ' | ' + widget.lastUpdated +
                    ' | ' + widget.created + ' | ' + widget.lastUsed);
                getWidgetInfo(widget.source, true);
            });
            //logger('******************************************************************');
        }

        if (dashboardCount > 0 && isOwner) {

            logger('You have multiple owner widgets with the same oid:');
            logger(
                ' title |  oid  |  _id  | source  | instanceType | owner | user | dashboardid |  lastUpdated  | created  | lastUsed ');
            var widgetsArr = db.getCollection('widgets')
                .find({
                    oid: widgetAggResult._id.oid,
                    userId: widgetAggResult._id.userId,
                    instanceType: widgetAggResult._id.instanceType
                })
                .sort({ lastUpdated: -1 })
                .toArray();
            db.getCollection('widgets').find({
                oid: widgetAggResult._id.oid,
                userId: widgetAggResult._id.userId,
                instanceType: widgetAggResult._id.instanceType
            }).sort({ lastUpdated: -1 }).forEach(function (widget) {
                logger('==================== Widget ========================');
                logger(secureOutput(widget.title) + ' | ' + widget.oid + ' | ' + widget._id + ' | ' +
                    widget.source + ' | ' + widget.created + ' | ' + widget.dashboardid +
                    ' | ' + widget.owner + ' | ' + widget.instanceType + ' | ' + widget.userId +
                    ' | ' + widget.lastUpdated + ' | ' + widget.lastUsed);
                if (widget.source) {
                    getWidgetInfo(widget.source, true);
                }
                logger('====================================================');
            });

            if (doCleanup) {
                for (var ii = 1; ii < widgetsArr.length; ii++) {
                    var widgetToRemove = widgetsArr[ii];
                    deleteIdsArr.push(widgetToRemove._id);
                }
                logger('Now dashboard owner ' + data.user + ' needs to republish ' +
                    data.dashboardtitle + ' with id ' + data.dashoid);
            }

            logger('    ');
        } else if (dashboardCount === 0) {
            logger('no related dashboard found, you need to delete ' + widgetAggResult.docs.length +
                ' redundant widgets');
            for (var k = 0; k < widgetAggResult.docs.length; k++) {
                var result = widgetAggResult.docs[k];

                db.getCollection('widgets')
                    .find({ _id: result })
                    .sort({ lastUpdated: -1 })
                    .forEach(function (widget) {
                        logger(secureOutput(widget.title) + ' | ' + widget.oid + //' | ' + widget._id.getTimestamp().getTime() +
                            ' | ' + widget._id + ' | ' + widget.instanceType + ' | ' +
                            widget.lastUpdated + ' | ' + widget.created + ' | ' +
                            widget.lastUsed);
                        var deleteItem = db.widgets.deleteOne({ '_id': widget._id });
                        logger(secureOutput(widget.title) + ' deleted: ' + deleteItem.deletedCount);
                    });

            }
            logger(
                '==================================================================================================================================================================================================================');
        }
    }
}

function checkWidgetsAgg(widgetsResults) {
    if (widgetsResults.length > 0) {
        var action = doCleanup ? 'start cleaning' : 'set "doCleanup = true;" to start cleaning';
        var deleteIdsArr = [];

        print('Widget duplicates cleaner ' + version + ' © Sisense | widget cleanup ' + cleanupStatus +
            ' | logs ' + logsStatus);
        print(
            '================================================================================================================');
        print('Found ' + widgetsResults.length + ' duplicate widget instances, ' + action);
        print(
            '================================================================================================================');
        for (var i = 0; i < widgetsResults.length; i++) {
            var widgetAggResult = widgetsResults[i];
            fixWidgetAggInstance(widgetAggResult)
        }

        print('========== ACTIONS ==========');
        logger(
            'to normalize these dashboards we remove all the junk widgets, most recently updated is kept, all others should be removed');
        logger('to delete widgets set flag doCleanup = true');
        logger('And you need these users to republish their dashboards');
        logger('After running this script for cleaning');
        print('=============================');

        Object.keys(owners).forEach(function (item) {

            var userObj = owners[item];

            print(userObj.name + ' should republish dashboards:');
            Object.keys(userObj.dashboards).forEach(function (key) {
                item = userObj.dashboards[key];
                print(item.dashboardtitle + ' with oid ' + item.dashboardId);
            });
            print('--------------------------');
        });
        if (doCleanup) {
            var deleteResult = db.getCollection('widgets').deleteMany(
                { '_id': { $in: deleteIdsArr } }
            );
            print('Deleted: ' + deleteResult.deletedCount);
        }
    } else {
        print('Your mongo is free from widget duplicates');
    }
}


var bulk = db.getCollection('widgets').initializeUnorderedBulkOp();
var owners = {};
var widgetAggResults = db.getCollection('widgets').aggregate([
    {
        $group: {
            _id: {
                //_id: "$_id",
                title: '$title',
                oid: '$oid',
                userId: '$userId',
                instanceType: '$instanceType',
                dashboardid: '$dashboardid'
                //source: '$source'
            },
            count: { $sum: 1 },
            docs: { $push: '$_id' }
        }
    },
    {
        $match: {
            count: { $gt: 1 }
        }
    }
]).toArray();

checkWidgetsAgg(widgetAggResults);
