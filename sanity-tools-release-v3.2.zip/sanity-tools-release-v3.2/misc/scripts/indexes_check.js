/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Index check';
// TODO add index usage count support

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    indexing: {
        restore: true,
        addIndex: true,
        get: true
    },
    logging: {
        showLogs: showLogs,
        showFullDBInfo: false
    }
};

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

var indexes = {
    prismWebDB: {},
    prismMonitor: {},
    prismConfig: {}
};

var defaultIndexes = {
    'prismWebDB': {
        'activities': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.activities'
            },
            {
                'v': 2,
                'key': {
                    'userId': 1
                },
                'name': 'userId_1',
                'ns': 'prismWebDB.activities'
            }
        ],
        'alerts': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.alerts'
            }
        ],
        'configurations': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.configurations'
            },
            {
                'v': 2,
                'unique': true,
                'key': {
                    'name': 1
                },
                'name': 'name_1',
                'ns': 'prismWebDB.configurations'
            }
        ],
        'connections': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.connections'
            }
        ],
        'dashboardVersions': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.dashboardVersions'
            }
        ],
        'dashboards': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.dashboards'
            },
            {
                'v': 2,
                'key': {
                    'owner': 1
                },
                'name': 'owner_1',
                'ns': 'prismWebDB.dashboards'
            },
            {
                'v': 2,
                'key': {
                    'userId': 1
                },
                'name': 'userId_1',
                'ns': 'prismWebDB.dashboards'
            },
            {
                'v': 2,
                'key': {
                    'parentFolder': 1
                },
                'name': 'parentFolder_1',
                'ns': 'prismWebDB.dashboards'
            },
            {
                'v': 2,
                'key': {
                    'oid': 1
                },
                'name': 'oid_1',
                'ns': 'prismWebDB.dashboards'
            },
            {
                'v': 2,
                'key': {
                    'oid': 1,
                    'instanceType': 1
                },
                'name': 'oid_1_instanceType_1',
                'ns': 'prismWebDB.dashboards'
            },
            {
                'v': 2,
                'key': {
                    'instanceType': 1
                },
                'name': 'instanceType_1',
                'ns': 'prismWebDB.dashboards'
            },
            {
                'v': 2,
                'key': {
                    'lastOpened': 1
                },
                'name': 'lastOpened_1',
                'ns': 'prismWebDB.dashboards'
            }
        ],
        'dataContext': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.dataContext'
            },
            {
                'v': 2,
                'key': {
                    'cubeId': 1
                },
                'name': 'cubeId_1',
                'ns': 'prismWebDB.dataContext'
            },
            {
                'v': 2,
                'key': {
                    'dataSourceId': 1
                },
                'name': 'dataSourceId_1',
                'ns': 'prismWebDB.dataContext'
            }
        ],
        'datasetTables': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.datasetTables'
            },
            {
                'v': 2,
                'unique': true,
                'key': {
                    'oid': 1
                },
                'name': 'oid_1',
                'ns': 'prismWebDB.datasetTables'
            },
            {
                'v': 2,
                'key': {
                    'dataset': 1
                },
                'name': 'dataset_1',
                'ns': 'prismWebDB.datasetTables'
            }
        ],
        'datasets': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.datasets'
            },
            {
                'v': 2,
                'unique': true,
                'key': {
                    'name': 1
                },
                'name': 'name_1',
                'ns': 'prismWebDB.datasets'
            },
            {
                'v': 2,
                'key': {
                    'fullname': 1
                },
                'name': 'fullname_1',
                'ns': 'prismWebDB.datasets'
            },
            {
                'v': 2,
                'key': {
                    'connection': 1
                },
                'name': 'connection_1',
                'ns': 'prismWebDB.datasets'
            },
            {
                'v': 2,
                'unique': true,
                'key': {
                    'oid': 1
                },
                'name': 'oid_1',
                'partialFilterExpression': {
                    'oid': {
                        '$exists': true
                    }
                },
                'ns': 'prismWebDB.datasets'
            },
            {
                'v': 2,
                'key': {
                    'elasticube': 1
                },
                'name': 'elasticube_1',
                'ns': 'prismWebDB.datasets'
            }
        ],
        'elasticubeBuildLogs': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.elasticubeBuildLogs'
            },
            {
                'v': 2,
                'key': {
                    'cubeId': 1,
                    'serverId': 1
                },
                'name': 'cubeId_1_serverId_1',
                'ns': 'prismWebDB.elasticubeBuildLogs'
            },
            {
                'v': 2,
                'key': {
                    'cubeId': 1,
                    'serverId': 1,
                    'timestamp': 1
                },
                'name': 'cubeId_1_serverId_1_timestamp_1',
                'ns': 'prismWebDB.elasticubeBuildLogs'
            }
        ],
        'elasticubeRelations': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.elasticubeRelations'
            },
            {
                'v': 2,
                'key': {
                    'elasticube': 1
                },
                'name': 'elasticube_1',
                'ns': 'prismWebDB.elasticubeRelations'
            },
            {
                'v': 2,
                'unique': true,
                'key': {
                    'oid': 1
                },
                'name': 'oid_1',
                'ns': 'prismWebDB.elasticubeRelations'
            }
        ],
        'elasticubeRevisions': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.elasticubeRevisions'
            },
            {
                'v': 2,
                'key': {
                    'oid': 1
                },
                'name': 'oid_1',
                'ns': 'prismWebDB.elasticubeRevisions'
            },
            {
                'v': 2,
                'key': {
                    'elasticube.oid': 1,
                    'buildId': 1
                },
                'name': 'elasticube.oid_1_buildId_1',
                'ns': 'prismWebDB.elasticubeRevisions'
            },
            {
                'v': 2,
                'key': {
                    'elasticube.oid': 1,
                    'status': 1
                },
                'name': 'elasticube.oid_1_status_1',
                'ns': 'prismWebDB.elasticubeRevisions'
            }
        ],
        'elasticubes': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.elasticubes'
            },
            {
                'v': 2,
                'unique': true,
                'key': {
                    'server': 1,
                    'title': 1
                },
                'name': 'server_1_title_1',
                'ns': 'prismWebDB.elasticubes'
            },
            {
                'v': 2,
                'unique': true,
                'key': {
                    'oid': 1
                },
                'name': 'oid_1',
                'ns': 'prismWebDB.elasticubes',
                'partialFilterExpression': {
                    'oid': {
                        '$exists': true
                    }
                }
            },
            {
                'v': 2,
                'key': {
                    'title': 1
                },
                'name': 'title_1',
                'ns': 'prismWebDB.elasticubes'
            },
            {
                'v': 2,
                'key': {
                    'title': 1,
                    'server': 1
                },
                'name': 'title_1_server_1',
                'ns': 'prismWebDB.elasticubes'
            }
        ],
        'events': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.events'
            },
            {
                'v': 2,
                'key': {
                    'users': 1
                },
                'name': 'users_1',
                'ns': 'prismWebDB.events'
            },
            {
                'v': 2,
                'key': {
                    'time': 1
                },
                'name': 'time_1',
                'ns': 'prismWebDB.events'
            },
            {
                'v': 2,
                'key': {
                    'usersInterested': 1
                },
                'name': 'usersInterested_1',
                'ns': 'prismWebDB.events',
                'sparse': true
            },
            {
                'v': 2,
                'key': {
                    'interest': 1
                },
                'name': 'interest_1',
                'ns': 'prismWebDB.events',
                'sparse': true
            },
            {
                'v': 2,
                'key': {
                    'alert': 1
                },
                'name': 'alert_1',
                'ns': 'prismWebDB.events'
            },
            {
                'v': 2,
                'key': {
                    'usersSeen': 1
                },
                'name': 'usersSeen_1',
                'ns': 'prismWebDB.events'
            },
            {
                'v': 2,
                'key': {
                    'usersHide': 1
                },
                'name': 'usersHide_1',
                'ns': 'prismWebDB.events'
            }
        ],
        'explorationPreparedData': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.explorationPreparedData'
            },
            {
                'v': 2,
                'key': {
                    'type': 1
                },
                'name': 'type_1',
                'ns': 'prismWebDB.explorationPreparedData'
            },
            {
                'v': 2,
                'key': {
                    'datasource': 1
                },
                'name': 'datasource_1',
                'ns': 'prismWebDB.explorationPreparedData'
            }
        ],
        'explorationRanking': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.explorationRanking'
            },
            {
                'v': 2,
                'key': {
                    '_fts': 'text',
                    '_ftsx': 1
                },
                'name': 'key_text',
                'ns': 'prismWebDB.explorationRanking',
                'weights': {
                    'key': 1
                },
                'default_language': 'english',
                'language_override': 'language',
                'textIndexVersion': 3
            },
            {
                'v': 2,
                'key': {
                    'datasource': 1
                },
                'name': 'datasource_1',
                'ns': 'prismWebDB.explorationRanking'
            }
        ],
        'expressions': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.expressions'
            },
            {
                'v': 2,
                'unique': true,
                'key': {
                    'oid': 1
                },
                'name': 'oid_1',
                'ns': 'prismWebDB.expressions'
            }
        ],
        'filesInfo': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.filesInfo'
            }
        ],
        'groups': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.groups'
            },
            {
                'v': 2,
                'key': {
                    'name': 1
                },
                'name': 'name_1',
                'ns': 'prismWebDB.groups'
            },
            {
                'v': 2,
                'key': {
                    'ad': 1
                },
                'name': 'ad_1',
                'ns': 'prismWebDB.groups',
                'sparse': true
            },
            {
                'v': 2,
                'key': {
                    'sId': 1
                },
                'name': 'sId_1',
                'ns': 'prismWebDB.groups',
                'sparse': true
            },
            {
                'v': 2,
                'key': {
                    'objectSid': 1
                },
                'name': 'objectSid_1',
                'ns': 'prismWebDB.groups',
                'sparse': true
            }
        ],
        'hierarchies': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.hierarchies'
            }
        ],
        'jobs': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.jobs'
            },
            {
                'v': 2,
                'key': {
                    'owner': 1
                },
                'name': 'owner_1',
                'ns': 'prismWebDB.jobs'
            },
            {
                'v': 2,
                'key': {
                    'context.dashboardId': 1
                },
                'name': 'context.dashboardId_1',
                'ns': 'prismWebDB.jobs'
            }
        ],
        'kpi': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.kpi'
            }
        ],
        'ldapDomains': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.ldapDomains'
            },
            {
                'v': 2,
                'key': {
                    'name': 1
                },
                'name': 'name_1',
                'ns': 'prismWebDB.ldapDomains'
            }
        ],
        'loginMonitoring': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.loginMonitoring'
            },
            {
                'v': 2,
                'key': {
                    'lastUpdate': 1
                },
                'name': 'lastUpdate_1',
                'ns': 'prismWebDB.loginMonitoring',
                'expireAfterSeconds': 86400
            }
        ],
        'metadata': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.metadata'
            },
            {
                'v': 2,
                'key': {
                    'oid': 1
                },
                'name': 'oid_1',
                'ns': 'prismWebDB.metadata'
            },
            {
                'v': 2,
                'key': {
                    'title': 1
                },
                'name': 'title_1',
                'ns': 'prismWebDB.metadata'
            }
        ],
        'palettes': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.palettes'
            },
            {
                'v': 2,
                'unique': true,
                'key': {
                    'name': 1
                },
                'name': 'name_1',
                'ns': 'prismWebDB.palettes'
            }
        ],
        'ranking': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.ranking'
            }
        ],
        'scopeConfiguration': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.scopeConfiguration'
            },
            {
                'v': 2,
                'unique': true,
                'key': {
                    'column': 1,
                    'table': 1,
                    'cubeId': 1,
                    'server': 1
                },
                'name': 'column_1_table_1_cubeId_1_server_1',
                'ns': 'prismWebDB.scopeConfiguration'
            }
        ],
        'serverAccess': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.serverAccess'
            },
            {
                'v': 2,
                'unique': true,
                'key': {
                    'serverName': 1
                },
                'name': 'serverName_1',
                'ns': 'prismWebDB.serverAccess'
            }
        ],
        'servers': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.servers'
            },
            {
                'v': 2,
                'key': {
                    'address': 1
                },
                'name': 'address_1',
                'ns': 'prismWebDB.servers'
            },
            {
                'v': 2,
                'key': {
                    'owner': 1
                },
                'name': 'owner_1',
                'ns': 'prismWebDB.servers'
            },
            {
                'v': 2,
                'key': {
                    'identity': 1
                },
                'name': 'identity_1',
                'ns': 'prismWebDB.servers'
            }
        ],
        'sessions': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.sessions'
            },
            {
                'v': 2,
                'key': {
                    'expires': 1
                },
                'name': 'expires_1',
                'ns': 'prismWebDB.sessions',
                'expireAfterSeconds': 0
            }
        ],
        'suggestions': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.suggestions'
            }
        ],
        'system.profile': [],
        'tags': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.tags'
            },
            {
                'v': 2,
                'key': {
                    'oid': 1
                },
                'name': 'oid_1',
                'ns': 'prismWebDB.tags'
            },
            {
                'v': 2,
                'key': {
                    'userId': 1
                },
                'name': 'userId_1',
                'ns': 'prismWebDB.tags'
            },
            {
                'v': 2,
                'key': {
                    'owner': 1
                },
                'name': 'owner_1',
                'ns': 'prismWebDB.tags'
            }
        ],
        'userInfluences': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.userInfluences'
            },
            {
                'v': 2,
                'key': {
                    'userId': 1
                },
                'name': 'userId_1',
                'ns': 'prismWebDB.userInfluences'
            },
            {
                'v': 2,
                'key': {
                    'datasource': 1
                },
                'name': 'datasource_1',
                'ns': 'prismWebDB.userInfluences'
            },
            {
                'v': 2,
                'key': {
                    '_fts': 'text',
                    '_ftsx': 1
                },
                'name': 'formulaKey_text',
                'ns': 'prismWebDB.userInfluences',
                'weights': {
                    'formulaKey': 1
                },
                'default_language': 'english',
                'language_override': 'language',
                'textIndexVersion': 3
            },
            {
                'v': 2,
                'key': {
                    'jaql': 1
                },
                'name': 'jaql_1',
                'ns': 'prismWebDB.userInfluences'
            }
        ],
        'users': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.users'
            },
            {
                'v': 2,
                'key': {
                    'firstName': 1
                },
                'name': 'firstName_1',
                'ns': 'prismWebDB.users'
            },
            {
                'v': 2,
                'key': {
                    'lastName': 1
                },
                'name': 'lastName_1',
                'ns': 'prismWebDB.users'
            },
            {
                'v': 2,
                'key': {
                    'email': 1
                },
                'name': 'email_1',
                'ns': 'prismWebDB.users'
            },
            {
                'v': 2,
                'key': {
                    'groups': 1
                },
                'name': 'groups_1',
                'ns': 'prismWebDB.users',
                'sparse': true
            },
            {
                'v': 2,
                'key': {
                    'objectSid': 1
                },
                'name': 'objectSid_1',
                'ns': 'prismWebDB.users',
                'sparse': true
            },
            {
                'v': 2,
                'key': {
                    'userName': 1
                },
                'name': 'userName_1',
                'ns': 'prismWebDB.users'
            }
        ],
        'widgets': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismWebDB.widgets'
            },
            {
                'v': 2,
                'key': {
                    'oid': 1
                },
                'name': 'oid_1',
                'ns': 'prismWebDB.widgets'
            },
            {
                'v': 2,
                'key': {
                    'dashboardid': 1
                },
                'name': 'dashboardid_1',
                'ns': 'prismWebDB.widgets'
            },
            {
                'v': 2,
                'key': {
                    'userId': 1
                },
                'name': 'userId_1',
                'ns': 'prismWebDB.widgets'
            },
            {
                'v': 2,
                'key': {
                    'owner': 1
                },
                'name': 'owner_1',
                'ns': 'prismWebDB.widgets'
            },
            {
                'v': 2,
                'key': {
                    'datasource.title': 1
                },
                'name': 'datasource.title_1',
                'ns': 'prismWebDB.widgets'
            }
        ]
    },
    'prismMonitor': {
        'trace': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'monitor.trace'
            },
            {
                'v': 2,
                'key': {
                    'userId': 1
                },
                'name': 'userId_1',
                'ns': 'monitor.trace'
            },
            {
                'v': 2,
                'key': {
                    'timestamp': -1
                },
                'name': 'timestamp_1',
                'ns': 'monitor.trace'
            }
        ]
    },
    'prismConfig': {
        'compiled_roles': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismConfig.compiled_roles'
            }
        ],
        'configurations': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismConfig.configurations'
            },
            {
                'v': 2,
                'unique': true,
                'key': {
                    'name': 1
                },
                'name': 'name_1',
                'ns': 'prismConfig.configurations'
            }
        ],
        'roles': [
            {
                'v': 2,
                'key': {
                    '_id': 1
                },
                'name': '_id_',
                'ns': 'prismConfig.roles'
            },
            {
                'v': 2,
                'unique': true,
                'key': {
                    'name': 1
                },
                'name': 'name_1',
                'ns': 'prismConfig.roles'
            }
        ]
    }
};

// todo add update index by db.collection.reIndex();
function restoreIndex(db, target) {
    var collections = db.getCollectionNames();
    var colIndex = defaultIndexes[target];
    collections.forEach(function (item) {
        logger('Restore index for ' + item);
        var indexesArr = colIndex[item];
        if (indexesArr) {
            var result = db.runCommand(
                {
                    createIndexes: item,
                    indexes: indexesArr
                }
            );
            print(JSON.stringify(result, null, 2));
        } else {
            logger('No default index for ' + item);
        }

    });

}

function getIndexes(db, target) {
    var collections = db.getCollectionNames();
    var colIndex = indexes[target];
    collections.forEach(function (item) {
        colIndex[item] = db.getCollection(item).getIndexes();
    });
}

function newIndex(collection, indexObj){
    var result = prismWebDB.getCollection(collection).createIndexes([indexObj]);
    print(JSON.stringify(result, null, 2));
}

function addIndex() {
    newIndex('dashboards', { 'oid': 1, 'userId': 1 });
    newIndex('widgets', { 'oid': 1, 'userId': 1 });
    prismWebDB.getCollection('alerts').createIndexes([{ 'type': 1, 'enabled': 1 }]);
    prismWebDB.getCollection('alerts').createIndexes([{ 'context.sources': 1 }]);
    prismWebDB.getCollection('dataContext').createIndexes([{ 'cubeId': 1, 'shares': 1 }]);
    prismWebDB.getCollection('elasticubes').createIndexes([{ 'type': 1 }]);
    prismWebDB.getCollection('elasticubes').createIndexes([{ 'fullNames': 1 }]);
    prismWebDB.getCollection('ldapDomains').createIndexes([{ 'enabled': 1 }]);
    prismWebDB.getCollection('dashboardVersions').createIndexes([{ 'oid': 1 }]);
    prismWebDB.getCollection('suggestions').createIndexes([{ 'datasource.title': 1 }]);
    prismWebDB.getCollection('groups').createIndexes([{ 'everyone': 1 }]);
    prismWebDB.getCollection('groups').createIndexes([{ 'public': 1 }]);
    prismWebDB.getCollection('groups').createIndexes([{ 'admin': 1 }]);
    prismWebDB.getCollection('users').createIndexes([{ 'adgroups': 1 }]);
    prismWebDB.getCollection('users').createIndexes([{ 'roleId': 1 }]);
    prismWebDB.getCollection('users').createIndexes([{ 'principalName': 1 }]);
    prismWebDB.getCollection('users').createIndexes([{ 'sAMAccountName': 1 }]);
    prismWebDB.getCollection('connections').createIndexes([{ 'owner': 1 }]);
    prismWebDB.getCollection('datasets').createIndexes([{ 'owner': 1 }]);
    prismWebDB.getCollection('jobs').createIndexes([{ 'jobType': 1, active: 1 }]);
    prismWebDB.getCollection('userInfluences').createIndexes([{ 'formulaKey': 1 }]);
    prismWebDB.getCollection('userInfluences').createIndexes([{ 'datasource': 1 }]);
    prismWebDB.getCollection('userInfluences').createIndexes([{ 'datasource.title': 1 }]);
    prismWebDB.getCollection('userInfluences').createIndexes([{ 'datasource.fullname': 1 }]);
    prismWebDB.getCollection('userInfluences').createIndexes([{ 'datasource.address': 1 }]);
    prismWebDB.getCollection('ranking').createIndexes([{ 'datasource.title': 1 }]);
    prismWebDB.getCollection('ranking').createIndexes([{ 'datasource.address': 1 }]);
    prismWebDB.getCollection('ranking').createIndexes([{ 'target': 1 }]);
    prismWebDB.getCollection('ranking').createIndexes([{ 'probability': 1 }]);
    prismWebDB.getCollection('dashboards').createIndexes([{ 'lastUpdated': 1 }]);
    prismWebDB.getCollection('widgets').createIndexes([{ 'instanceType': 1 }]);
    prismWebDB.getCollection('widgets').createIndexes([{ 'lastUpdated': 1 }]);
    prismWebDB.getCollection('widgets').createIndexes([{ 'dashboardId': 1, 'userId': 1 }]);
}

if (config.indexing.get) {
    print('Get index');
    print(' ');

    getIndexes(prismWebDB, 'prismWebDB');
    getIndexes(prismConfig, 'prismConfig');
    getIndexes(prismMonitor, 'prismMonitor');
    print(JSON.stringify(indexes, null, 2));
}
if (config.indexing.restore) {
    print('Restoring index');

    restoreIndex(prismWebDB, 'prismWebDB');
    restoreIndex(prismConfig, 'prismConfig');
    restoreIndex(prismMonitor, 'prismMonitor');
}

if (config.indexing.addIndex) {
    print('Adding index');

    addIndex();
}

//print(JSON.stringify(indexes, null, 2));
