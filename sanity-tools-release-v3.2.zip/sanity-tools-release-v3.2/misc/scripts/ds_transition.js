var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');
// General Info
var version = '3.1.3';

var groupId = '5c11e00312663a0958c3497f';
prismWebDB.getCollection('dataContext')
    .find({ table: 'CompanyDim', column: 'GroupAccountDepartmentID', allMembers: true })
    .forEach(function (rule) {
        var userCount = 0;

        rule.shares.forEach(function (share) {
            print(share.type + ' ' + share.partyId);

            if (share.type === 'user' && groupId !== '') {
                db.getCollection('users').update(
                    { _id: share.partyId },
                    { $push: { groups: groupId } }
                );
                userCount += 1;
            }

        });

        if (rule.shares.length === userCount) {
            db.getCollection('dataContext').deleteOne({ '_id': rule._id });
        }

        print('=============================');
    });

