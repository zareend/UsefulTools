// General Info
var version = '3.1.3';

var conn = new Mongo('localhost:27020');
var dbBkp = conn.getDB('prismWebDB');

var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');

prismWebDB.users.find({ active: false }).forEach(function (user) {
    var userBkp = dbBkp.users.findOne({ 'email': user.email });
    if (userBkp) {
        // remove corrupted
        db.users.deleteOne({ _id: user._id }, {});
        // insert backup'ed
        db.users.insert(userBkp);
    }
});
