/**
 * Created by yaroslav.korzh on 8/11/2017.
 * Updated 10/01/2019
 */
var version = '3.1.3';

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var deleteUserInstances = true;
var cleanupStatus = doCleanup ? 'enabled' : 'disabled';
var showLogs = true;
var logsStatus = showLogs ? 'enabled' : 'disabled';
var useUserAndProxy = false;
var showParentInfo = false;

// Common utils
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

var bulk = db.getCollection('widgets').initializeUnorderedBulkOp();
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

function printInfo(results) {
    var action = doCleanup ? 'start cleaning' : 'set "doCleanup = true;" to start cleaning';
    var duplicatesTotal = 0;
    var widgetsTotal = db.getCollection('widgets').count();

    for (var k = 0, l = results.length; k < l; k++) {
        var result = results[k];
        duplicatesTotal += result.docs.length;
    }
    var duplicatesPercentage = Math.round((duplicatesTotal / widgetsTotal) * 100);

    print('Widget duplicates cleaner ' + version + ' © Sisense | widget cleanup ' + cleanupStatus +
        ' | logs ' + logsStatus);
    print(
        '================================================================================================================');
    print('Found ' + results.length + ' duplication widget cases and ' + duplicatesTotal +
        ' duplicated widget instances');
    print('Total widgets ' + widgetsTotal + ' duplication: ' + duplicatesPercentage + ' %');
    print(action);
    print(
        '================================================================================================================');
}

function printActions(owners) {
    print('========== ACTIONS ==========');
    logger(
        'to normalize these dashboards we remove all the junk widgets, most recently updated is kept, all others should be removed');
    logger('to delete widgets set flag doCleanup = true');
    logger('And you need these users to republish their dashboards');
    logger('After running this script for cleaning');
    print('=============================');

    Object.keys(owners).forEach(function (item) {

        var userObj = owners[item];

        print(userObj.name + ' should republish dashboards:');
        Object.keys(userObj.dashboards).forEach(function (key) {
            item = userObj.dashboards[key];
            print(item.dashboardtitle + ' with oid ' + item.dashboardId);
        });
        print('--------------------------');
    });
}

function getWidgetInfo(id, sourceSearch) {
    if (showParentInfo) {
        var searchId = parseStringToObjectId(id);
        var result = db.getCollection('widgets').find({
            _id: searchId
        }).toArray();
        db.getCollection('widgets').find({
            _id: searchId
        }).forEach(function (widget) {
            var text = 'widget info';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('********************* ' + text + ' ********************************');
            logger(secureOutput(widget.title) + ' | ' + widget.oid + ' | ' + widget._id + ' | ' + widget.source +
                ' | ' + widget.created + ' | ' + widget.dashboardid + ' | ' + widget.owner + ' | ' +
                widget.instanceType + ' | ' + widget.userId + ' | ' + widget.lastUpdated + ' | ' +
                widget.lastUsed);
            //getDashboardInfo(widget.dashboardid)
            if (widget.source) {
                getWidgetInfo(widget.source, true);
            }
            logger('******************************************************************');
        });

        if (result.length === 0) {
            var msg = 'widget not found';
            if (sourceSearch) {
                msg = 'Parent ' + msg;
            }
            logger('************************* ' + msg + ' *******************************');
        }
    }
}

function getDashboardInfo(id, sourceSearch) {
    if (showParentInfo) {
        logger('Sourced from:');
        var searchId = parseStringToObjectId(id);
        var searchObj = {
            instanceType: 'owner'
        };
        if (sourceSearch) {
            searchObj['_id'] = searchId;
        } else {
            searchObj['oid'] = searchId;
        }
        var result = db.getCollection('dashboards').find(searchObj).toArray();

        db.getCollection('dashboards').find(searchObj).forEach(function (dash) {
            var text = 'Dashboard info';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('********************* ' + text + ' ********************************');
            logger('Dashboard: ' + dash._id + ' | ' + secureOutput(dash.title) + ' | ' + dash.oid + ' | ' +
                dash.instanceType + ' | ' + dash.owner + ' | ' + dash.source + ' | ' +
                dash.lastUpdated);
            if (dash.source) {
                getDashboardInfo(dash.source, true);
            }
            logger('*********************************************************************');
        });

        if (result.length === 0) {
            var msg = 'dashboard not found';
            if (sourceSearch) {
                msg = 'Parent ' + msg;
            }
            logger('************************* ' + msg + '*******************************');
        }
    }
}

function fixInstance(result) {
    var data = {};
    var isOwner = result._id.instanceType === 'owner';

    if (isOwner) {
        var owner = {};

        db.getCollection('users').find({ _id: result._id.userId }).forEach(function (user) {
            logger('User: ' + user.userName + ' | ' + user._id);
            Object.keys(owners).forEach(function (item) {
                var userObj = owners[item];
                if (userObj.name === user.userName) {
                    owner = owners[user.userName];
                }
            });

            data.user = user.userName;
            owner.name = user.userName;

            db.getCollection('dashboards').find({
                oid: result._id.dashboardid,
                instanceType: result._id.instanceType
            }).forEach(function (dash) {
                var dashboard = {};
                logger('Dashboard: ' + secureOutput(dash.title) + ' | ' + dash.oid + ' | ' + dash.instanceType +
                    ' | ' + dash.owner + ' | ' + dash.created + ' | ' + dash.lastUpdated + ' | ' +
                    dash.source);
                data.dashoid = dash.oid;
                data.dashboardtitle = secureOutput(dash.title);
                dashboard.dashboardId = dash.oid;
                dashboard.dashboardtitle = secureOutput(dash.title);

                if (!owner.dashboards) {
                    owner.dashboards = {};
                }
                if (!owner.dashboards[dashboard.dashboardId.valueOf()]) {
                    owner.dashboards[dashboard.dashboardId.valueOf()] = dashboard;
                }
                if (dash.source !== 'undefined') {
                    getDashboardInfo(dash.source, true);
                }

            });
            owners[owner.name] = owner;
        });
        var dashboardCount = db.getCollection('dashboards').count({
            oid: result._id.dashboardid,
            instanceType: result._id.instanceType
        });
    } else if (useUserAndProxy || deleteUserInstances) {

        if (useUserAndProxy) {
            logger('Result is ' + result._id.instanceType +
                ' instance. Fixing owner instances solves it.');//+ ' | ' + result._id.owner + ' | ' + result._id.userId
            //logger('Widget: ' + result._id.title + ' | ' + result._id.oid + ' | ' + result._id._id + ' | ' + result._id.source  +' | ')
        }

        db.getCollection('widgets').find({
            oid: result._id.oid,
            userId: result._id.userId,
            instanceType: result._id.instanceType
        }).sort({ lastUpdated: -1 }).toArray().forEach(function (widget, index) {
            if (useUserAndProxy) {
                logger(
                    secureOutput(widget.title) + ' | ' + index + ' | ' + widget.oid + ' | ' + widget._id + ' | ' +
                    widget.source + ' | ' + widget.instanceType + ' | ' + widget.owner + ' | ' +
                    widget.userId + ' | ' + widget.dashboardid + ' | ' + widget.lastUpdated +
                    ' | ' + widget.created + ' | ' + widget.lastUsed);
            }
            getWidgetInfo(widget.source, true);
            if (deleteUserInstances && index > 0) {
                //var res = db.widgets.deleteOne({"_id": widget._id});
                //logger(secureOutput(widget.title) + ' added to bulk delete' );
                bulk.find({ '_id': widget._id }).remove();
                //logger(secureOutput(widget.title) + ' deleted: ' );//+ res.deletedCount
            }
        });
        //logger('******************************************************************');

    }

    if (dashboardCount > 0 && isOwner) {
        logger('You have multiple owner widgets with the same oid:');
        logger(
            ' title |  oid  |  _id  | source  | instanceType | owner | user | dashboardid |  lastUpdated  | created  | lastUsed ');
        var widgetsArr = db.getCollection('widgets')
            .find({
                oid: result._id.oid,
                userId: result._id.userId,
                instanceType: result._id.instanceType
            })
            .sort({ lastUpdated: -1 })
            .toArray();
        db.getCollection('widgets').find({
            oid: result._id.oid,
            userId: result._id.userId,
            instanceType: result._id.instanceType
        }).sort({ lastUpdated: -1 }).toArray().forEach(function (widget, index) {
            logger('==================== Widget ========================');
            logger(secureOutput(widget.title) + ' | ' + index + ' | ' + widget.oid + ' | ' + widget._id + ' | ' +
                widget.source + ' | ' + widget.created + ' | ' + widget.dashboardid + ' | ' +
                widget.owner + ' | ' + widget.instanceType + ' | ' + widget.userId + ' | ' +
                widget.lastUpdated + ' | ' + widget.lastUsed);
            if (widget.source) {
                getWidgetInfo(widget.source, true);
            }
            logger('====================================================');
        });

        if (doCleanup) {
            for (var ii = 1; ii < widgetsArr.length; ii++) {
                var widgetItem = widgetsArr[ii];

                //var res = db.widgets.deleteOne({"_id": widget._id});
                bulk.find({ '_id': widgetItem._id }).remove();
                //logger(secureOutput(widgetItem.title) + ' deleted: ' + res.deletedCount);
                deleteIdsArr.push(widgetItem._id);
            }
            //logger('----------------------------------------------------');
            logger(
                'Now dashboard owner ' + data.user + ' needs to republish ' + data.dashboardtitle +
                ' with id ' + data.dashoid);
        }

        logger('    ');
    } else if (dashboardCount === 0) {
        logger('no related dashboard found, you need to delete ' + result.docs.length +
            ' redundant widgets');
        for (var k = 0, l = result.docs.length; k < l; k++) {
            var res = result.docs[k];

            db.getCollection('widgets')
                .find({ _id: res })
                .sort({ lastUpdated: -1 })
                .toArray()
                .forEach(function (widget) {
                    logger(secureOutput(widget.title) + ' | ' + widget.oid + //' | ' + widget._id.getTimestamp().getTime() +
                        ' | ' + widget._id + ' | ' + widget.instanceType + ' | ' +
                        widget.lastUpdated + ' | ' + widget.created + ' | ' + widget.lastUsed);
                    var deletedResult = db.widgets.deleteOne({ '_id': widget._id });
                    logger(secureOutput(widget.title) + ' deleted: ' + deletedResult.deletedCount);
                });

        }
        logger(
            '==================================================================================================================================================================================================================');
    }
}

var widgetAggResults = db.getCollection('widgets').aggregate([
    {
        $group: {
            _id: {
                //_id: "$_id",
                //title: "$title",
                oid: '$oid',
                userId: '$userId',
                instanceType: '$instanceType'
                //dashboardid: "$dashboardid",
                //source: '$source'
            },
            count: { $sum: 1 },
            docs: { $push: '$_id' }
        }
    },
    {
        $match: {
            count: { $gt: 1 }
        }
    }
]).toArray();

function cleanDB() {
    var owners = {};
    widgetAggResults = db.getCollection('widgets').aggregate([
        {
            $group: {
                _id: {
                    //_id: "$_id",
                    //title: "$title",
                    oid: '$oid',
                    userId: '$userId',
                    instanceType: '$instanceType'
                    //dashboardid: "$dashboardid",
                    //source: '$source'
                },
                count: { $sum: 1 },
                docs: { $push: '$_id' }
            }
        },
        {
            $match: {
                count: { $gt: 1 }
            }
        }
    ]).toArray();

    if (widgetAggResults.length > 0) {
        printInfo(widgetAggResults);
        for (var i = 0, l = widgetAggResults.length; i < l; i++) {
            var result = widgetAggResults[i];

            if (result) {
                fixInstance(result);
            }
        }

        printActions(owners);

        if (doCleanup || deleteUserInstances) {
            print('Bulk delete');
            bulk.execute();
            // var deleteResult = db.getCollection('widgets').deleteMany(
            //        { "_id" : { $in: deleteIdsArr } }
            //    );
            // print('Deleted: ' + deleteResult.deletedCount);
        }
    } else {
        print('Your mongo is free from widget duplicates');
    }

}

cleanDB();

