#!/usr/bin/env bash
mongo social --port 28000 -u user -p password --authenticationDatabase admin <<EOF
db.createRole({
  role: "readWriteMinusDropRole",
  privileges: [
  {
    resource: { db: "social", collection: ""},
    actions: [ "collStats", "dbHash", "dbStats", "find", "killCursors", "listIndexes", "listCollections", "convertToCapped", "createCollection", "createIndex", "dropIndex", "insert", "remove", "renameCollectionSameDB", "update"]} ],
    roles: []
  }
);
use admin;
db.createUser({user: 'human_user', pwd: 'password', roles: [{role: 'readWriteMinusDropRole', db: 'social'}]})
EOF

# The output of above command
# MongoDB shell version v3.6.2
# connecting to: mongodb://127.0.0.1:28000/social
# MongoDB server version: 3.6.2
# {
# 	"role" : "readWriteMinusDropRole",
# 	"privileges" : [
# 		{
# 			"resource" : {
# 				"db" : "social",
# 				"collection" : ""
# 			},
# 			"actions" : [
# 				"collStats",
# 				"dbHash",
# 				"dbStats",
# 				"find",
# 				"killCursors",
# 				"listIndexes",
# 				"listCollections",
# 				"convertToCapped",
# 				"createCollection",
# 				"createIndex",
# 				"dropIndex",
# 				"insert",
# 				"remove",
# 				"renameCollectionSameDB",
# 				"update"
# 			]
# 		}
# 	],
# 	"roles" : [ ]
# }
# switched to db admin
# Successfully added user: {
# 	"user" : "human_user",
# 	"roles" : [
# 		{
# 			"role" : "readWriteMinusDropRole",
# 			"db" : "social"
# 		}
# 	]
# }
# bye
