// Globals
var version = '3.1.3';
if(!utilsLoaded){
    print('Loaded utils');
}
var utilsLoaded = true;
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');
var scriptsFolder = './scripts';
var left = '====================================';
var right = '====================================';
var secureOutputEnabled = true;

// Functions
function loadScript(script) {
    if (scriptsFolder) {
        var path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}

// Base functions
function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}
function secureOutput(text){
    if (secureOutputEnabled) {
        return '< secure output >';
    }
    else {
        return text;
    }
}
logger('Loaded scripts utils');

function deferredLogger(str, messages) {

    if (defferedLogs && messages) {
        messages.push(str);
    }

}

function printResult(res) {
    logger(JSON.stringify(res, null, 2));
}

function timestamp(msg) {
    print(new Date().toISOString() + ' ' + msg);
}

function getPercent(val, total) {
    return ((val / total) * 100).toFixed(2);
}

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

function divider() {
    var str = left + '==' + right;
    logger(str);
    return str;
}
function dividerSmall() {
    var str = '-------------------------';
    logger(str);
    return str;
}
function dividerHeader(msg) {
    var str = left + ' '+ msg +' ' + right;
    logger(str);
    return str;
}
function dividerFooter(msg) {
    var re = /([a-zA-Z]| *)/gmi;
    var right_msg = msg.replace(re, '=');
    var text = left + '='+ right_msg +'=' + right;
    logger(text);
}

function increaseSort(){
    prismWebDB.adminCommand(
        { 'setParameter': 1, 'internalQueryExecMaxBlockingSortBytes': 134217728 }); // old sort = 33554432
}
function decreaseSort(){
    prismWebDB.adminCommand(
        { 'setParameter': 1, 'internalQueryExecMaxBlockingSortBytes': 33554432 }); // old sort = 134217728
}

function isEmptyObject(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            return false;
        }
    }
    return true;
}

function parseObjectIdToString(id) {
    if (!id) {
        return null;
    }

    if (typeof id === 'string') {
        return id;
    } else {
        return id.str;
    }
}

function parseStringToObjectId(id) {
    if (id == null) {
        return;
    }
    if (typeof id === 'string') {
        return ObjectId(id);
    } else {
        return id;
    }
}

function validateObjectId(id) {
    if (!id) {
        return false;
    }
    var stringId = parseObjectIdToString(id);
    return checkForHexRegExp.test(stringId);
}

function onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
}

function printConfig(config) {
    dividerHeader('Configuration');
    logger(JSON.stringify(config, undefined, 2));
    dividerFooter('Configuration');
}

function printHeader() {
    var logsStatus = getStatus(showLogs);
    var cleanupStatus = getStatus(doCleanup);
    divider();
    print(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    print(new Date());
    divider();
}

// example of usage - collectStats('no_owner_dashboard', 1);
function collectStats(key, value) {
    if (typeof collectedStats !== 'undefined') {
        if (collectedStats[key]) {
            collectedStats[key] += value;
        } else {
            collectedStats[key] = value;
        }
    } else {
        let collectedStats = {};
        collectedStats[key] = value;
    }
}
function mappingStats(key, value) {
    if (typeof mappedStats !== 'undefined') {
        if (mappedStats[key]) {
            mappedStats[key] += value;
        } else {
            mappedStats[key] = value;
        }
    } else {
        let mappedStats = {};
        mappedStats[key] = value;
    }
}

function printStats() {
    if (typeof globalRun == 'undefined') {
        divider();
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ');
        if (typeof collectedStats != 'undefined') {
            print(JSON.stringify(collectedStats, undefined, 2));
        }
        divider();
    }
}

// *** Basic Functions ***
function timeDiff(d1, d2) {
    var dateDiff = d2.getTime() - d1.getTime();
    var secDiff = dateDiff / (1000);
    var minDiff = dateDiff / (1000 * 60);
    var hourDiff = dateDiff / (1000 * 60 * 60);
    var milliseconds = dateDiff;
    var hh = Math.floor(milliseconds / 1000 / 60 / 60);
    milliseconds -= hh * 1000 * 60 * 60;
    var mm = Math.floor(milliseconds / 1000 / 60);
    milliseconds -= mm * 1000 * 60;
    var ss = Math.floor(milliseconds / 1000);
    milliseconds -= ss * 1000;
    if(hh<10){
        hh = '0'+hh;
    }
    if(mm<10){
        mm = '0'+mm;
    }
    if(ss<10){
        ss = '0'+ss;
    }

    return {
        text: hh+':'+mm+':'+ss,
        milliseconds: milliseconds,
        seconds: secDiff > 0 ? secDiff : 0,
        minutes: minDiff > 0 ? minDiff : 0,
        hours: hourDiff > 0 ? hourDiff : 0
    };
}

function getAggQuery(aggObject) {
    var query = [];
    if (queryLimit > 0) {
        query.push({ $limit: queryLimit });
    }
    if (skip > 0) {
        query.push({ $skip: skip });
    }
    query.push({
        $group: {
            _id: aggObject,
            count: { $sum: 1 },
            docs: { $push: documentKeys }
        }
    });
    query.push({
        $match: {
            count: { $gt: 1 }
        }
    });
    return query;
}

///// Globals
var groupsMap = {};

function createGroupsMap() {
    var groupAgg = prismWebDB.getCollection('groups').aggregate([
        { $sort: { _id: 1 } },
        { $group: { '_id': 'groups', 'groups': { $push: '$_id' } } }
    ]);

    groupAgg.forEach(function (agg) {
        agg.groups.forEach(function (group) {
            var groupId = parseObjectIdToString(group);
            groupsMap[groupId] = true;
        });
    });
}

function getGroupsMap() {
    return groupsMap;
}

function updateGroupsMap() {
    var groupAgg = prismWebDB.getCollection('groups').aggregate([
        { $sort: { _id: 1 } },
        { $group: { '_id': 'groups', 'groups': { $push: '$_id' } } }
    ]);
    groupsMap = {};
    groupAgg.forEach(function (agg) {
        agg.groups.forEach(function (group) {
            var groupId = parseObjectIdToString(group);
            groupsMap[groupId] = true;
        });
    });
}

createGroupsMap();
