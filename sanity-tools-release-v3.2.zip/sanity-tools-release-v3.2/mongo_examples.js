// Mongo scripts:
// https://drive.google.com/open?id=1lilfLBH7s3OqzYua0JJueCf_N3wqOVrw
// Robomongo Install - https://robomongo.org/download

db.getCollection('users').find({ activeDirectory: { $exists: true } });
db.getCollection('dashboards').find({ userId: { $exists: false } });
db.getCollection('dashboards').find({ userId: ObjectId('') });
db.getCollection('dashboards').find({parentFolder: ObjectId('5d63eef6832e26002b9e6c14'),  userId: ObjectId('') });
// noinspection SpellCheckingInspection
db.getCollection('dashboards').find({ oid: ObjectId('5e501e616ffde5002dadff03') });
db.getCollection('users').find({ ldapDomainId: { $type: 'string' } });
db.getCollection('users').find({ uSNChanged: { $gte: '4819219' } });
db.getCollection('users').find({ email: '' });

db.users.createIndex({ userName: 'text' });
db.getCollection('users').find({ $text: { $search: 'test -972' } });
db.users.find({ $text: { $search: 'test', $caseSensitive: true } });
// show current connections
db.currentOp(true).inprog.forEach(function(x) { print(x.client + ' ' + x.desc) });
// show queries profiling info
db.system.profile.find({}).sort({ns: 1}).forEach(function(p){
    print(p.ns + ' ' + p.planSummary + ' cheked - indexes:' + p.keysExamined + ' docs:'+ p.docsExamined + ' returned docs:'+ p.nreturned + ' - query: ' +JSON.stringify(p.query))
});

db.users.find({
    $where: function () {
        // pure js code here
        return (new Date(this.lastUpdated) > new Date(this.lastLogin));
    }
});

db.getCollection('users').find({
    $and:[
        {
            $where: function () {
                // pure js code here
                return (new Date(this.created).getTime() === new Date(this.lastLogin).getTime());
            }
        },
        {email:/sisense.com/}
    ]
});

db.users.find({ groups: { $size: 2 } });
db.users.find({ groups: { $exists: true }, $where: 'this.groups.length > 10' });

db.getCollection('dashboards')
    .find({ 'filters.levels.dim': '[SM_Process.WeekStartDate (Calendar)]' });
db.getCollection('dashboards').find({ 'datasource.title': 'Sample ECommerce' });
db.getCollection('dashboards')
    .find({ 'datasource.title': { $in: ['Sample ECommerce', 'Sample Healthcare'] } });
db.getCollection('dashboards')
    .find({ 'filters.jaql.datasource.title': { $in: ['Sample ECommerce', 'Sample Healthcare'] } });

db.elasticubes.find(
    {
        shares: {
            $elemMatch: {
                partyId: {
                    $in: [
                        ObjectId('580dd3aa80f95edd1738a3d6'),
                        ObjectId('5891a013050e179047000016')]
                }, permission: 'w'
            }
        }
    }
);

db.dashboards.find(
    {
        shares: {
            $elemMatch: {
                type: 'user',
                partyId: { $in: [ObjectId('580dd3aa80f95edd1738a3d6')] }
            }
        },
        instanceType: 'owner'
    }
);

db.elasticubes.find(
    { shares: { $elemMatch: { type: 'group', permission: 'r' } } }
);

db.users.update(
    {
        $where: function () {
            // pure js code here
            return (new Date(this.lastUpdated) > new Date(this.lastLogin));
        }
    },
    { $max: { lastActivity: new Date('2019-06-06 14:34:22.538Z') } }
);

db.users.update(
    { email: 'yako@ciklum.com' },
    { $unset: { lastActivity: '' } }
);

db.getCollection('users').find({
    $and: [
        { lastActivity: { $gte: new Date('2019-01-06 14:34:22.538Z') } },
        { activeDirectory: { $exists: false } }
    ]
});

// noinspection SpellCheckingInspection
db.users.update(
    { _id: ObjectId('587e3614e0d8bf405600001d') },
    { $push: { groups: { $each: ['5cdec8f1e73a1341c4e4c0f6', '5cb48dbf994c48cd9c954029'] } } }
);
// noinspection SpellCheckingInspection
db.users.update({ _id: ObjectId('587e3614e0d8bf405600001d') },
    { $pullAll: { groups: ['5cdec8f1e73a1341c4e4c0f6'] } }
);

db.users.update({ _id: ObjectId('587e3614e0d8bf405600001d') }, { $rename: { 'email': 'mail' } });

db.users.update(
    {
        $where: function () {
            // pure js code here
            return (new Date(this.lastUpdated) > new Date(this.lastLogin));
        }
    },
    { $max: { lastActivity: new Date('2019-06-06 14:34:22.538Z') } }
);

db.getCollection('users').find({}).forEach(function (user) {
    print(JSON.stringify(user, null, 2));
});

db.getCollection('users').find({ ldapDomainId: { $type: 'string' } }).forEach(function (user) {
    db.getCollection('users').updateOne(
        { _id: user._id },
        { $set: { ldapDomainId: ObjectId(user.ldapDomainId) } },
        { upsert: true }
    );
});

db.getCollection('users').find({
    ldapDomainId: {
        $nin: [
            ObjectId('5bae49f5e08c135428f38d82'),
            ObjectId('5947e81af5d594283b0000f5'),
            ObjectId('5947e1b5f5d594283b0000f2'),
            ObjectId('5bae4a26e08c135428f38d83'),
            ObjectId('5bbc62c6d74b632c88e64e8e')
        ]
    }
});
db.getCollection('users').update({
        ldapDomainId: {
            $nin: [
                ObjectId('5bae49f5e08c135428f38d82'),
                ObjectId('5947e81af5d594283b0000f5'),
                ObjectId('5947e1b5f5d594283b0000f2'),
                ObjectId('5bae4a26e08c135428f38d83'),
                ObjectId('5bbc62c6d74b632c88e64e8e')
            ]
        }
    },
    { $set: { ldapDomainId: ObjectId('5bae49f5e08c135428f38d82') } },
    { multi: true }
);

db.getCollection('dashboards').find({}).forEach(function (dash) {
    print(dash.datasource.address);

    if (typeof dash.datasource.address !== 'string') {
        print(secureOutput(dash.title) + ' ' + dash._id);
    }
});

db.getCollection('users').find({ 'preferences.language': { $type: 'null' } }).forEach(function(user){
    user.groups = [];
    user.email = 'test@test.com';
    user.preferences.localeId = '';
    user.preferences.language = '';
    var result = db.getCollection('users').save(user);
    print(result)
})
