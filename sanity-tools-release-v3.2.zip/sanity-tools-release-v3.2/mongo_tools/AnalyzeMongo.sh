#!/usr/bin/env bash
echo "Doing some Bash script work first"
mongo  ./scripts/scripts_loader.js
echo "Doing some more Bash script work afterwards"
