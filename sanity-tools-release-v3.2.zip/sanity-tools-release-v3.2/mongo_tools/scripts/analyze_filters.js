var version = '3.1.3';
var doCleanup = false;
var scriptName = 'Analyze filters';
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var cleanupStatus = doCleanup ? 'enabled' : 'disabled';
var showLogs = true;
var defferedLogs = true;

var showAllFilters = false;
var showDrill = false;
var userCheck = true;
var logsStatus = showLogs ? 'enabled' : 'disabled';

var config = {
    showDashMessages: false,
    emailPattern: [],
    drillPrefix: '_drill'
};
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';

function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    } else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}

loadScript('utils.js', utilsFolder);

//endregion

function printHeader() {
    logger('Filter analyzer ' + version + ' © Sisense');
    divider();
}

function printStats() {
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total items ' + getIssuesStatus(doCleanup) + ': ');
        logger(JSON.stringify(collectedStats, undefined, 2));
        divider();
    }
}

function collectFilterStats(jaql, type, shouldCheck) {
    var statsByType = filterStats[type];
    if (!statsByType) {
        filterStats[type] = {
            datatype: {},
            collapsed: {},
            check: {
                yes: 0,
                no: 0
            },
            total: 0
        };
        statsByType = filterStats[type];
    }
    var statByData;
    if (jaql.datatype) {
        statByData = statsByType['datatype'];
        if (statByData) {
            if (statByData[jaql.datatype]) {
                statByData[jaql.datatype] += 1;
            } else {
                statByData[jaql.datatype] = 1;
            }
        }
    }
    if (jaql.hasOwnProperty('collapsed')) {
        statByData = statsByType['collapsed'];
        if (statByData) {
            if (statByData[jaql.collapsed]) {
                statByData[jaql.collapsed] += 1;
            } else {
                statByData[jaql.collapsed] = 1;
            }
        }
    }
    if (shouldCheck) {
        statsByType.check.yes += 1;
    } else {
        statsByType.check.no += 1;
    }
    statsByType.total += 1;
}

function printFilterStats() {
    var value = getPercent(filtersToCheck, filterCount);
    var checkPercentage = value * 100;
    var dashValue = getPercent(dashboardsToCheck, totalDashboards);
    var dashPercentage = dashValue * 100;
    logger('Filter statistics ' + ' © Sisense');
    logger('Total filters: ' + filterCount);
    logger('To check filters: ' + filtersToCheck);
    logger('Percentage of filters to verify: ' + checkPercentage + '%');
    dividerSmall();
    logger('Total analyzed dashboards: ' + totalDashboards);
    logger('To check dashboards: ' + dashboardsToCheck);
    logger('Drill dashboards: ' + drillDashboards);
    logger('Skipped ( Not relevant ) dashboards: ' + dashboardsSkipped);
    logger('Percentage of dashboards to verify: ' + dashPercentage + '%');
    dividerSmall();
    logger('Average filters per dashboard: ' + (filterCount / totalDashboards).toFixed(3));
    logger('Average filters to check per dashboard to check: ' +
        (filtersToCheck / dashboardsToCheck).toFixed(3));
    dividerSmall();
    logger('User dashboard stats per domain');
    logger(JSON.stringify(domains, undefined, 2));
    Object.keys(filterStats).forEach(function (item) {
        var statsByType = filterStats[item];
        logger('Filter type: ' + item);
        Object.keys(statsByType).forEach(function (typeItem) {
            var statsItem = statsByType[typeItem];

            if (typeof statsItem == 'object') {
                logger(' ' + typeItem);
                Object.keys(statsItem).forEach(function (key) {
                    var statsElem = statsItem[key];
                    logger('  ' + key + ': ' + statsElem);
                });
            } else {
                logger(' ' + typeItem + ': ' + statsItem);
            }
            if (typeItem === 'total') {
                var totalPercentage = getPercent(statsByType['check'].yes, statsItem);
                logger(' percentage of filters to verify: ' + totalPercentage + '%');
            }
            dividerSmall()
        });
        dividerSmall()
    });
    divider();
}

var domains = {};
var filterStats = {};
var filterCount = 0;
var filtersToCheck = 0;
var dashboardsToCheck = 0;
var drillDashboards = 0;
var dashboardsSkipped = 0;
var totalDashboards = 0;
var blankFilter = {};
// var notProxy = { 'instanceType': { '$nin': ['proxy'] } };
// var onlyUser = { 'instanceType': { '$nin': ['proxy', 'owner'] } };
printHeader();

function processJaql(jaql, type, messages, showFilter, showFilters, values, hasExcludes, exValues, shouldCheck) {
    if (showFilters) {
        showFilter = showFilters;
    }

    if (showFilter) {
        deferredLogger(
            '  filter ' + type + ': ' + jaql.title + ' | data type: ' + jaql.datatype +
            ' | collapsed: ' + jaql.collapsed, messages);
        var valuesMsg = '';
        if (values) {
            valuesMsg += '    values: ' + JSON.stringify(values);
        }
        if (hasExcludes) {
            valuesMsg += '    exclude values: ' + JSON.stringify(exValues);
        }
        deferredLogger(valuesMsg, messages);
    }

    if (shouldCheck) {
        filtersToCheck += 1;
        config.showDashMessages = true;
    }
}

function analyzeJaql(jaql, type, messages) {
    var showFilter = true;
    var shouldCheck = true;

    if (jaql) {
        if (jaql.filter) {
            filterCount += 1;
            var values = jaql.filter.members;
            if (jaql.filter.exclude) {
                var hasExcludes = true;
                var exValues = jaql.filter.exclude.members;
            }
            if (jaql.datatype === 'datetime') {
                showFilter = false;
                shouldCheck = false;
            }
            if (!values && jaql.filter.all) {
                values = 'Include All';
                showFilter = false;
                shouldCheck = false;
            }
            if (!jaql.collapsed) {
                showFilter = false;
                shouldCheck = false;
            }

            processJaql(jaql, type, messages, showFilter, showAllFilters, values, hasExcludes, exValues, shouldCheck);

            collectFilterStats(jaql, type, shouldCheck);
        }
        //logger('show messages ' + config.showDashMessages);
    }

}

function analyzeFilter(filter, type, messages) {
    if (filter.jaql) {
        var jaql = filter.jaql;
        analyzeJaql(jaql, type, messages);
    }
    if (filter.isCascading) {
        deferredLogger(' cascading filter levels: ', messages);
        filter.levels.forEach(function (filterLevel) {
            analyzeJaql(filterLevel, 'cascading', messages);
        });
    }
}

function checkUserInfo(user) {
    if (user) {
        if (user.indexOf) {
            var userDomain = user.split('@')[1];

            var userFilter = config.emailPattern.indexOf(userDomain) !== -1;
        }
    }
    if (userCheck) {
        if (!userFilter) {
            if (domains[userDomain]) {
                domains[userDomain] += 1;
            } else {
                domains[userDomain] = 1;
            }

        }
    }
}

function analyzeFilters() {

    prismWebDB.getCollection('dashboards').find(blankFilter).forEach(function (dash) {
        var messages = [];
        config.showDashMessages = false;
        var hasFilters = dash.filters && dash.filters.length > 0;
        var hasDefaultFilters = dash.defaultFilters && dash.defaultFilters.length > 0;
        var isDrill = dash.title.indexOf(config.drillPrefix) !== -1;

        var showDashInfo = hasFilters || hasDefaultFilters;
        var userInfo = {};

        if (isDrill) {
            drillDashboards += 1;
            if (!showDrill) {
                return;
            }
        }

        prismWebDB.getCollection('users').find({_id: dash.userId}).forEach(function (userObj) {
            userInfo = userObj;
        });

        var user = userInfo.email || userInfo.userName || dash.userId;
        checkUserInfo(user);

        if (showDashInfo) {
            deferredLogger('dashboard: ' + secureOutput(dash.title) + ' | oid: ' + dash.oid + ' | instance: ' +
                dash.instanceType + ' | user: ' + user, messages);
        }
        if (dash.filters) {
            dash.filters.forEach(function (filter) {
                analyzeFilter(filter, 'dashboard', messages);
            });
        }
        if (dash.defaultFilters) {
            dash.defaultFilters.forEach(function (filter) {
                analyzeFilter(filter, 'default', messages);
            });
        }
        //logger('');
        prismWebDB.getCollection('widgets')
            .find({userId: dash.userId, dashboardid: dash.oid})
            .forEach(function (widget) {

                if (widget.metadata.panels) {
                    widget.metadata.panels.forEach(function (panel) {
                        if (panel.name === 'filters' && panel.items.length > 0) {

                            deferredLogger(
                                ' widget: ' + secureOutput(widget.title) + ' | _id: ' + widget._id + ' | oid: ' +
                                widget.oid + ' has widget filters ', messages);

                            panel.items.forEach(function (filter) {
                                analyzeFilter(filter, 'widget', messages);
                            });
                        }
                    });
                }

            });
        if (showDashInfo) {
            deferredLogger('----------------------------------------------------', messages);
        }
        if (config.showDashMessages) {
            messages.forEach(function (message) {
                logger(message);
            });
            dashboardsToCheck += 1;
        } else {
            //logger('Skipped ' +messages.length + ' messages on dashboard ' + secureOutput(widget.title));
            dashboardsSkipped += 1;
        }
        totalDashboards += 1;

    });

    logger('');
    divider()
}

analyzeFilters();
printFilterStats();
