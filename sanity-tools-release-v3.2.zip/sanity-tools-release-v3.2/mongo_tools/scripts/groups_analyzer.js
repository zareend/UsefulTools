/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Groups analyzer';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup,
        removeGroups: false
    },
    systemGroups: ['Admins', 'Everyone'],
    logging: {
        showLogs: showLogs
    }
};

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion
printHeader();
printConfig(config);

// Global variables
var groupsAgg = {};
var groupsWithNoUsers = [];
var groupsToRemove = [];
var groupsTotal = prismWebDB.groups.count();
// Functions
function getGroupUsers(groupId){
    return prismWebDB.getCollection('users').find({ groups: { $in: [groupId] } }).toArray();
}

// Main script
prismWebDB.getCollection('groups').find({}).forEach(function (group) {

    var groupSplit = group.name.split(':');
    var users = getGroupUsers(parseObjectIdToString(group._id));
    //logger(JSON.stringify(users));

    var aggGroup = groupSplit[0];
    var subGroup = groupSplit[1];
    if (groupsAgg[aggGroup]) {
        groupsAgg[aggGroup].count += 1;
        groupsAgg[aggGroup].subgroups.push(subGroup);
    } else {
        groupsAgg[aggGroup] = group;
        groupsAgg[aggGroup].count = 1;
        groupsAgg[aggGroup].users = [];
        groupsAgg[aggGroup].subgroups = [];
        groupsAgg[aggGroup].subgroups.push(subGroup);

    }
    logger(group.name + ' users: ' + users.length);
    if (users.length === 0 && config.systemGroups.indexOf(group.name) === -1) {
        groupsWithNoUsers.push(group.name);
        groupsToRemove.push(group._id);
        mappingStats('group_has_no_users', 1);
    }
    users.forEach(function (item) {
        if (groupsAgg[aggGroup].users.indexOf(item.email) === -1){
            groupsAgg[aggGroup].users.push(item.email);
        }

    });
    if (aggGroup && !subGroup) {
        groupsAgg[aggGroup].hasParent = true;
    }
});
logger(' ');
logger('Aggregated groups: ' +  Object.keys(groupsAgg).length);

Object.keys(groupsAgg).forEach(function (item) {
    var group = groupsAgg[item];
    dividerHeader('Group');
    var msg = 'Agg for: ' + item + ' : ' + group.subgroups.length + ' groups | ';
    if (!group.hasParent) {
        msg += 'has parent group: ' + group.hasParent + ' | '
    }
    msg +=  'users: ' + group.users.length;
    logger(msg);
    if (group.subgroups && group.subgroups[0] !== null){
        //logger(JSON.stringify(group.subgroups));
    }
    //logger(JSON.stringify(group.users, null, 2));
    dividerFooter('Group');
});
if (config.cleanup.doCleanup && config.cleanup.removeGroups) {
    var result = prismWebDB.getCollection('groups').remove({ _id: { '$in': groupsToRemove }});
    logger(JSON.stringify(result));
}
logger(' ');
divider();
logger('Groups with no users:');
logger(JSON.stringify(groupsWithNoUsers, null, 2));

var notUsedPercentage = getPercent(groupsWithNoUsers.length, groupsTotal);
logger(' ');
logger('Total groups ' + groupsTotal + ', with no users: ' + groupsWithNoUsers.length + ' | '+ notUsedPercentage + '% redundant');
updateGroupsMap();
printStats();
logger('Script has finished execution successfully ' + ' © Sisense');

