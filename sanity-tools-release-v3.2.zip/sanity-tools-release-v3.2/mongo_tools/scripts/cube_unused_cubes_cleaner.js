﻿/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Unused cubes cleaner';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

printHeader();
printConfig(config);

// Global variables

var datasourcesObj = {};
// Functions

// Main script
prismWebDB.getCollection('dashboards').aggregate([
    { '$project': { 'datasource': '$datasource' } },
    { $group: { _id: '$datasource', count: { $sum: 1 } } },
    { $sort: { count: -1 } }
]);
prismWebDB.getCollection('widgets').aggregate([
    { '$project': { 'datasource': '$datasource' } },
    { $group: { _id: '$datasource', count: { $sum: 1 } } },
    { $sort: { count: -1 } }
]);
logger('Total widgets' + ' | ' + prismWebDB.getCollection('widgets').count({}));
prismWebDB.getCollection('widgets').find({}).forEach(function (widget) {
    //logger('widget: ' + widget.datasource.title + ' | ' + widget.datasource.address);
    if (widget.datasource) {
        if (datasourcesObj[widget.datasource.title]) {
            datasourcesObj[widget.datasource.title] += 1;
        } else {
            datasourcesObj[widget.datasource.title] = 1;
        }
    }

});
logger('Total dashboards' + ' | ' + prismWebDB.getCollection('dashboards').count({}));
divider();
prismWebDB.getCollection('dashboards').find({}).forEach(function (dash) {
    //logger('widget: ' + widget.datasource.title + ' | ' + widget.datasource.address);
    if (dash.datasource) {
        if (datasourcesObj[dash.datasource.title]) {
            datasourcesObj[dash.datasource.title] += 1;
        } else {
            datasourcesObj[dash.datasource.title] = 1;
        }
    }

});
dividerSmall();
logger('Used cubes: ' + Object.keys(datasourcesObj).length);
prismWebDB.getCollection('elasticubes')
    .find({ title: { $in: Object.keys(datasourcesObj) } })
    .forEach(function (elasticube) {
        var count = datasourcesObj[elasticube.title];
        logger(
            'elasticube: ' + elasticube.title + ' | ' + elasticube.server + ' | ' + elasticube._id +
            ' | ' + count);
    });
dividerSmall();
var unusedCubesCount = prismWebDB.getCollection('elasticubes')
    .count({ title: { $nin: Object.keys(datasourcesObj) } });
logger('Unused cubes: ' + unusedCubesCount);
mappingStats('cubes_unused', unusedCubesCount);
prismWebDB.getCollection('elasticubes')
    .find({ title: { $nin: Object.keys(datasourcesObj) } })
    .forEach(function (elasticube) {
        logger(
            'elasticube: ' + elasticube.title + ' | ' + elasticube.server + ' | ' + elasticube._id);
    });

if (doCleanup) {
    // todo decide if you need to remove cubes
    // var operation = prismWebDB.getCollection('elasticubes')
    //     .deleteMany({ title: { $nin: Object.keys(datasourcesObj) } });
    // logger('deleted: ' + operation.acknowledged + ' | removed cubes: ' + operation.deletedCount);
}
