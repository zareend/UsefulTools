// General Info
var version = '3.1.3';
var monitor = db.getSiblingDB('monitor');

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';

function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    } else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}

loadScript('utils.js', utilsFolder);
//endregion
var filter_time = {
    timestamp: {
        $gte: ISODate('2019-04-04 00:00:00.745Z'),
        $lt: ISODate('2019-04-04 12:00:00.745Z')
    }
};
var filter_request = {
    'meta.method': 'POST'
};
var filter_blank = {};

function logElement(logObject) {
    logger(logObject.timestamp + ' ' + logObject.level + ' ' + logObject.message);
    dividerSmall();
    var logStr = '';
    var logKeys = '';
    Object.keys(logObject.meta).forEach(function (key) {
        var item = logObject.meta[key];
        logKeys += key + ' ';
        logStr += item + ' ';
    });
    logger(logKeys);
    logger(logStr);
    divider();
}

var filter = 1;
switch (filter) {
    case 1:
        monitor.getCollection('trace').find(filter_request).forEach(function (logObject) {
            logElement(logObject)
        });
        break;
    case 2:
        monitor.getCollection('trace').find(filter_time).forEach(function (logObject) {
            logElement(logObject)
        });
        break;
    default:
        monitor.getCollection('trace').find(filter_blank).forEach(function (logObject) {
            logElement(logObject)
        });
        break;
}

