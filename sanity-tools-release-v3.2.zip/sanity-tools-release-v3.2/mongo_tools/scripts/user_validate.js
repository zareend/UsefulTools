/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Users validate';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var cleanGroups = doCleanup;
var config = {
    cleanup: {
        doCleanup: doCleanup,
        cleanGroups: cleanGroups
    },
    targetDate: new Date('2019-12-30T16:45:00'),
    logging: {
        showLogs: showLogs
    }
};

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

printHeader();
printConfig(config);

// Global variables
var allRoles = {}; // Hashmap of all roles
var today = new Date();
// Functions
// *** Group Validation Functions ***
function isGroupIdExists(id) {
    var groupId = parseStringToObjectId(id);
    // If we found a group with the given id
    return prismWebDB.groups.find({ _id: groupId }).limit(1).hasNext();
}

function validateGroupId(id) {
    return (validateObjectId(id) && isGroupIdExists(id));
}

function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (email) {
        return re.test(email.toLowerCase());
    }
    else {
        return false;
    }
}

function validateActivation(user) {
    if (!user.active) {
        logger('User ' + user.email + ' created: ' + user.created + ' is not activated')
    }
    return user.active;
}

function validateUserLastTime(user) {
    var isValid = true;
    var userYear, todayYear;
    if (user.lastActivity) {
        userYear = user.lastActivity.getFullYear();
        todayYear = today.getFullYear();
        if (userYear < todayYear) {
            logger('! user was not active this year');
        }
        if(config.targetDate > user.lastActivity) {
            logger('! user was not active after ' + config.targetDate);
        }
    } else if (user.lastLogin) {
        if (user.lastLogin.getFullYear) {
            userYear = user.lastLogin.getFullYear();
        }
        else {
            logger('lastLogin: ' + user.lastLogin + ' ' + typeof(user.lastLogin));
            isValid = false;
            mappingStats('user_last_login_string', 1);
        }

        todayYear = today.getFullYear();
        if (userYear < todayYear) {
            logger('! user was not logged in this year');
        }
        if(config.targetDate > user.lastLogin) {
            logger('! user was not logged in after ' + config.targetDate);
        }
    }
    return isValid;
}

// *** Main Functions ***
function validateAllUsers() {
    var userCount = prismWebDB.users.count({});
    logger('Validating ' + userCount + ' users');
    prismWebDB.getCollection('users').createIndex({ lastActivity: 1}, {});
    prismWebDB.users.find({}).sort({lastActivity: -1}).forEach(function (user) {
        var isValid = true;
        var hasChanges = false;
        logger('User (_id): ' + user._id);
        if (!validateUserLastTime(user)){
            isValid = false;
            //logger('User (_id): ' + user._id +' | activity: ' + user.lastActivity +' | login: ' + user.lastLogin);
            mappingStats('User (_id): ' + user._id +' invalid activity date');
        }

        if (!validateObjectId(user._id)) {
            isValid = false;
            logger('User (_id): ' + user._id + ' has invalid user id');
            mappingStats('user_invalid_id', 1);
        }
        if (!validateEmail(user.email)) {
            isValid = false;
            logger('User (_id): ' + user._id + ' has invalid email - ' + secureOutput(user.email));
            mappingStats('user_invalid_email', 1);
        }

        if (!validateActivation(user)) {
            isValid = false;
            logger('User (_id): ' + user._id + ' is not activated - ' + secureOutput(user.email));
            mappingStats('user_not_activated', 1);
        }

        if (user.groups) {
            user.groups.forEach(function (groupIdString, index) {
                if (!validateGroupId(groupIdString)) {
                    isValid = false;
                    collectStats('user_invalid_group_id', 1);
                    logger('User (_id): ' + user._id + ' has invalid group id: ' + groupIdString);
                    if (doCleanup && cleanGroups) {
                        logger('Removing group from user');
                        hasChanges = true;
                        user.groups.splice(index, 1);
                    }
                }
            });

        }

        if (!validateRoleId(user.roleId)) {
            isValid = false;
            mappingStats('user_invalid_role_id', 1);
            logger('User (_id): ' + user._id + ' has invalid role id: ' + user.roleId);
        }

        if (doCleanup && cleanGroups && hasChanges) {
            logger('Update user groups');
            prismWebDB.getCollection('users').update(
                { _id: user._id },
                { $set: { 'groups': user.groups } },
                { multi: false }
            );
        }

        if (!isValid) {
            // logger('db.getSiblingDB(\'prismWebDB\').users.find({_id: ObjectId(\'' + user._id +
            //     '\')});');
        }
        dividerSmall();
    });
    logger('Validating all users has ended.');
}

// *** Roles Validation Functions ***
function initAllRoles() {
    prismConfig.roles.find({}, { _id: 1 }).forEach(function (role) {
        var roleIdString = parseObjectIdToString(role._id);
        allRoles[roleIdString] = roleIdString;
    });
}

function isRoleIdExists(id) {

    var roleIdString = parseObjectIdToString(id);
    // Initializing the roles hashmap
    if (isEmptyObject(allRoles)) {
        initAllRoles();
    }

    return allRoles.hasOwnProperty(roleIdString);
}

function validateRoleId(userRole) {
    if (!userRole) {
        mappingStats('user_has_no_role', 1);
        logger('User has no role');
        return;
    }
    return isRoleIdExists(userRole);
}

function showDuplicatedUsers(usersDuplicates) {
    usersDuplicates.forEach(function (userObj) {
        logger('Username ' + userObj._id.userName + ' has ' + userObj.count + ' users');
        mappingStats('user_duplicated_username', 1);
    });
}

// Main script
var usersDuplicatesAgg = prismWebDB.getCollection('users').aggregate([
    {
        $group: {
            _id: {
                userName: '$userName'
            },
            count: { $sum: 1 },
            docs: { $push: {
                    email: '$email',
                    userName: '$userName',
                    _id: '$_id'
                } }
        }
    },
    {
        $match: {
            count: { $gt: 1 }
        }
    }
]).toArray();


showDuplicatedUsers(usersDuplicatesAgg);
validateAllUsers();
printStats();
