/**
 * Created by yaroslav.korzh
 * Updated 03/06/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Mongo stats';

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs,
        showFullDBInfo: false,
        showProfiling: false,
        showConnections: false,
        showIndexInfo: false
    }
};

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

printHeader();
printConfig(config);

// Global variables

var statsArrDB = [];
var statsArrConfig = [];
var statsArrMonitor = [];
var indexUsed = [];
var indexUnused = [];
var collectionsDB = prismWebDB.getCollectionNames();
var collectionsConfig = prismConfig.getCollectionNames();
var collectionsMonitor = prismMonitor.getCollectionNames();

// Functions

function dbStats(db, target) {
    var dataSizeInGB = db.stats().dataSize / 1000000000;
    var indexSizeInMB = db.stats().indexSize / 1000000;
    var dbStatistics = db.stats(1024);
    var dbGlobalLock = db.serverStatus().globalLock;
    var dbLocks = db.serverStatus().locks;
    var dbTcmalloc = db.serverStatus().tcmalloc;
    logger('MongoDB stats for ' + target + ': ');

    if (config.logging.showFullDBInfo) {

        logger(' Stats: ');
        printResult(dbStatistics);
        logger(' Global lock: ');
        printResult(dbGlobalLock);
        logger(' Locks: ');
        printResult(dbLocks);

        if (dbTcmalloc) {
            logger(' tcmalloc: ');
            logger(dbTcmalloc.tcmalloc.formattedString);
        }

        //logger(JSON.stringify(dbTcmalloc, undefined, 2));
        logger('  ');
        //logger(JSON.stringify(dbStatistics, undefined, 2));
        logger('maxBsonObjectSize ' + db.isMaster().maxBsonObjectSize);
    }
    logger('Data Size (GB) = ' + dataSizeInGB + '\nIndex Size (MB) = ' + indexSizeInMB);
    logger('  ');
}

function showIndexStats(db, collection) {
    logger(' ');
    logger(collection + ' indexes ');
    if (collection !== 'system.profile') {
        db.getCollection(collection)
            .aggregate([{ $indexStats: {} }], { cursor: {} })
            .forEach(function (index) {
                logger(' ' + index.name);
                var indexTitle = collection + '.' + index.name;
                if (index.accesses.ops > 0) {
                    logger('  ' + index.accesses.ops + ' times ' + 'used ');// + index.accesses.since
                    indexUsed.push(indexTitle);
                } else {
                    logger('  !' + ' index was not used');// since  + index.accesses.since
                    indexUnused.push(indexTitle);
                }

            });
    }
}

function checkCollection(db, collection, statsArray) {
    var collectionTotal = db.getCollection(collection).count();

    // var info = db.getCollectionInfos({ name: collection});
    // logger('Info '+ collection);
    // printResult(info);
    var stats = db.getCollection(collection).stats();
    var obj = {};

    obj.Name = collection;
    obj.TotalSizeInMB = stats.size / 1000000;
    obj.NumberOfDocuments = stats.count;
    obj.StorageSizeInMB = stats.storageSize / 1000000;
    obj.totalIndexSizeInMB = stats.totalIndexSize / 1000000;
    obj.currentCacheInMB = stats.wiredTiger.cache['bytes currently in the cache'] / 1000000;
    obj.fileSizeInMB = stats.wiredTiger['block-manager']['file size in bytes'] / 1000000;
    logger(' ' + collection + ' : ' + collectionTotal + ' items' + ' | ' + obj.TotalSizeInMB +
        ' Mb Size' + ' / ' + obj.StorageSizeInMB + ' Mb Storage size' + ' / ' +
        obj.totalIndexSizeInMB + ' Mb Index size');
    statsArray.push(obj);
}

function printCollectionsInfo() {
    logger('  ');
    logger('prismWebDB collections items count: ');
    collectionsDB.forEach(function (collection) {
        checkCollection(prismWebDB, collection, statsArrDB);
    });
    logger('  ');
    logger('prismConfig collections items count: ');
    collectionsConfig.forEach(function (collection) {
        checkCollection(prismConfig, collection, statsArrConfig);
    });
    logger('  ');
    logger('monitor collections items count: ');
    collectionsMonitor.forEach(function (collection) {
        checkCollection(prismMonitor, collection, statsArrMonitor);
    });
}

function printAdvancedInfo(db) {

    divider();
    logger('                  Advanced MongoDB info ');
    divider();

    // for all dbs
    var serverStatus = db.serverStatus();
    db.stats();
    var profilingLevel = db.getProfilingLevel();
    var profilingStatus = db.getProfilingStatus();
    var profilingQeries = db.system.profile.find({ 'nreturned': { $gt: 1 } }).count();
    var slowest = db.system.profile.find({ 'op': { $eq: 'query' } }, {
            'query': NumberInt(1),
            'millis': NumberInt(1)
        }
    ).sort({ millis: -1 }).limit(10).pretty();
    if (serverStatus.metrics) {
        logger('Cursor info');
        logger(JSON.stringify(serverStatus.metrics.cursor, null, 2));
    }
    logger('Any query or command doing range or full scans');
    logger(JSON.stringify(profilingQeries, null, 2));
    logger('Any query or command doing range or full scans');
    logger(JSON.stringify(slowest, null, 2));
    logger('Connections info');
    logger(JSON.stringify(serverStatus.connections, null, 2));
    if (serverStatus.locks) {
        logger('Locks info ( r - read, w - write operations');
        logger(JSON.stringify(serverStatus.locks.Global, null, 2));
    }
    logger('Current locks info');
    logger(JSON.stringify(serverStatus.globalLock, null, 2));
    logger('Asserts exceptions');
    logger(JSON.stringify(serverStatus.asserts, null, 2));

    if (config.logging.showProfiling){
        logger('Profiling level: ' + profilingLevel + ' ( 0 is ok, 1 corresponds to slow operations )');
        logger('Profiling status: ' + JSON.stringify(profilingStatus));
        db.system.profile.find({}).sort({ ns: 1 }).forEach(function (p) {
            print(p.ns + ' ' + p.planSummary + ' checked - indexes:' + p.keysExamined + ' docs:' +
                p.docsExamined + ' returned docs:' + p.nreturned + ' - query: ' +
                JSON.stringify(p.query));
        });
    }
    if (config.logging.showConnections){
        logger('Open connections');
        var res = db.currentOp(true).inprog.reduce(
            (accumulator, connection) => {
                var ipaddress = connection.client ? connection.client.split(':')[0] : 'unknown';
                accumulator[ipaddress] = (accumulator[ipaddress] || 0) + 1;
                accumulator['TOTAL_CONNECTION_COUNT']++;
                return accumulator;
            },
            { TOTAL_CONNECTION_COUNT: 0 }
        );
        logger(JSON.stringify(res));
        db.currentOp(true).inprog.forEach(function (x) {
            //print(x.client + ' ' + x.desc)
            logger(JSON.stringify(x));
        });
    }


    divider();
    logger('                   Index stats ');
    divider();
    // for all collections
    collectionsDB.forEach(function (collection) {
        if (config.logging.showIndexInfo) {
            showIndexStats(prismWebDB, collection);
        }
    });
    logger('  ');
    logger('Index used');
    logger(JSON.stringify(indexUsed, null, 2));
    logger('Index unused');
    logger(JSON.stringify(indexUnused, null, 2));
    logger('  ');
}

function printMemStats(array, target) {
    logger('  ');
    var sortable = [];
    var targetKey = 'currentCacheInMB';
    var targetCount = 'NumberOfDocuments';
    var targetName = 'Name';
    for (var key in array) {
        var item = array[key];
        sortable.push([item[targetName], item[targetKey], item]);
    }
    sortable.sort(function (a, b) {
        return b[1] - a[1];
    });
    if (sortable.length === 0) {
        logger('No data for ' + target);
    } else {
        logger('Memory cache usage stats in ' + target);
        sortable.forEach(function (elem) {
            logger(
                '  - ' + elem[0] + ': ' + elem[1] + ' Mb / ' + elem[2][targetCount] + ' documents');
            if (config.logging.showFullDBInfo) {
                //logger(JSON.stringify(elem[2], null, 2));
            }

        });
    }

}

// Main script

//printBasicInfo();

dbStats(prismWebDB, 'Prism Web DB');
dbStats(prismConfig, 'Prism Config');
dbStats(prismMonitor, 'Prism Monitor');

printCollectionsInfo();
printMemStats(statsArrDB, 'Prism Web DB');
printMemStats(statsArrConfig, 'Prism Config');
printMemStats(statsArrMonitor, 'Prism Monitor');

printAdvancedInfo(prismWebDB);
logger('  ');
logger('Script has finished execution successfully ' + ' © Sisense');

