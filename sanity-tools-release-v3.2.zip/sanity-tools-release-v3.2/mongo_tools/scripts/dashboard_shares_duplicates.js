﻿//region General Info
/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
var version = '3.1.3';
var scriptName = 'Dash shares duplicates';
//endregion

//region Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var showShareDuplicates = false;
var fixOwners = doCleanup;
var config = {
    cleanup: {
        doCleanup: doCleanup,
        fixOwners: fixOwners
    },
    logging: {
        showLogs: showLogs,
        showShareDuplicates: showShareDuplicates
    }
};
//endregion

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

//region Common utils
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function logger(msg) {
    if (showLogs) {
        logger(msg);
    }
}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}
let collectedStats;
function collectStats(key, value) {
    if (typeof collectedStats !== 'undefined') {
        if (collectedStats[key]) {
            collectedStats[key] += value;
        } else {
            collectedStats[key] = value;
        }
    } else {
        collectedStats = {};
        collectedStats[key] = value;
    }
}

function printDashSharesStats() {
    if (maxDuplicates > 0) {
        logger('Max duplicates in shares ' + maxDuplicates + ' copies');
    } else {
        logger('No duplicates in collection');
    }
    logger('Max shares array ' + maxShares + ' items');

    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ');
        logger(JSON.stringify(collectedStats, undefined, 2));

        divider()
    }
}

//endregion

//region Basic functions
function isEmptyObject(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            return false;
        }
    }
    return true;
}

function parseObjectIdToString(id) {
    if (typeof id === 'string') {
        return id;
    } else {
        return id.str;
    }
}

function parseStringToObjectId(id) {
    if (typeof id === 'string') {
        return ObjectId(id);
    } else {
        return id;
    }
}

function validateObjectId(id) {
    var stringId = parseObjectIdToString(id);
    return checkForHexRegExp.test(stringId);
}

function printHeader() {
    var logsStatus = getStatus(showLogs);
    var cleanupStatus = getStatus(doCleanup);
    divider();
    logger(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    logger(new Date());
    divider();
}

function printConfig(configuration) {
    dividerHeader('Configuration');
    logger(JSON.stringify(configuration, undefined, 2));
    dividerFooter('Configuration');
}

//endregion

//region Global variables
var maxDuplicates = 0;
var maxShares = 0;
//endregion

//region Functions
var bulk = prismWebDB.getCollection('dashboards').initializeUnorderedBulkOp();

function validateUser(userId) {
    var objectOid = parseStringToObjectId(userId);

    return prismWebDB.users.find({ _id: objectOid }).limit(1).hasNext();
}

function validateGroup(groupId) {
    var objectOid = parseStringToObjectId(groupId);

    return prismWebDB.groups.find({ _id: objectOid }).limit(1).hasNext();
}

function validateShare(share) {
    var result;
    if (share.type === 'group') {
        result = validateGroup(share.shareId);
    } else if (share.type === 'user') {
        result = validateUser(share.shareId);
    } else {
        // dashboard owner
        result = validateUser(share.shareId);
    }
    return result;
}

function validateDashboardShares(dash) {
    dividerHeader('Dashboard');
    logger(secureOutput(dash.title) + '  _id: ' + dash._id + '  type: ' + dash.instanceType + ' dash shares: ' +
        dash.shares.length);

    var sharesObj = {};
    var sharesToKeep = [];
    var hasOwnerShare = false;
    var isOwner = dash.instanceType === 'owner';
    if (dash.shares) {
        if (dash.shares.length > maxShares) {
            maxShares = dash.shares.length;
        }
        dash.shares.forEach(function (share) {
            var validShare = validateShare(share);
            if (share.shareId) {
                if (sharesObj[share.shareId]) {
                    sharesObj[share.shareId].count += 1;
                    sharesObj[share.shareId].agg.push(share);
                } else {
                    sharesObj[share.shareId] = share;
                    sharesObj[share.shareId].count = 1;
                    sharesObj[share.shareId].agg = [];
                    sharesObj[share.shareId].agg.push(share);
                    if (validShare) {
                        sharesToKeep.push({
                            shareId: share.shareId,
                            type: share.type,
                            rule: share.rule,
                            subscribe: share.subscribe
                        });
                    } else {
                        logger(' - Non-existing Share: ' + share.shareId + ' ' + share.type);
                        collectStats('dashboard_non_existing_share', 1);
                    }
                }

                if (share.shareId.valueOf() === dash.owner.valueOf() && share.type === 'user') {
                    hasOwnerShare = true;
                }
            } else {
                dividerHeader('Broken Share');
                logger(JSON.stringify(share, null, 2));
                dividerFooter('Broken Share');
            }
        });

        if (!hasOwnerShare) {
            logger('Owner is not in shares');
            collectStats('dashboard_owner_not_in_shares', 1);
            if (fixOwners) {
                sharesToKeep.push({ shareId: dash.owner, type: 'user' });
            }
        }
        Object.keys(sharesObj).forEach(function (item) {

            var share = sharesObj[item];
            if (share.count > 1) {
                if (share.count > maxDuplicates) {
                    maxDuplicates = share.count;
                }
                collectStats('dashboard_shares_duplicates', 1);
                logger('You have duplicates in shares collection for dash');
                logger('Duplicate: ' + item + ' | ' + share.type + ' | ' + share.rule + ' | ' +
                    share.subscribe + ' - count: ' + share.count);

                if (showShareDuplicates) {
                    share.agg.forEach(function (shareItem, index) {
                        logger(shareItem.shareId + ' | ' + index + ' | ' + shareItem.type + ' | ' +
                            shareItem.rule + ' | ' + shareItem.subscribe);
                    });
                }

                dividerSmall()
            }

        });
        if (sharesToKeep.length === 0) {
            logger('! Dashboard has no valid shares - should be removed');
            collectStats('dashboard_has_no_valid_shares', 1);
        }
        if (dash.shares.length === sharesToKeep.length && hasOwnerShare) {
            //logger('Shares normalized ');
        } else if (doCleanup || !hasOwnerShare) {
            logger('Keep shares: ' + sharesToKeep.length);
            prismWebDB.getCollection('dashboards').update(
                { '_id': dash._id },
                { $set: { 'shares': sharesToKeep } }
            );
        }
    } else {
        logger('Dashboard ' + dash._id + ' with  oid: ' + dash.oid + ' user: ' + dash.userId +
            '  has no shares');
        if (doCleanup) {
            if (isOwner) {
                logger('Create shares ');
                prismWebDB.getCollection('dashboards').update(
                    { '_id': dash._id },
                    { $set: { 'shares': [{ shareId: dash.owner, type: 'user' }] } }
                );
            }

        }
    }
    dividerFooter('Dashboard');
}

function validateDashboard(dash) {
    validateDashboardShares(dash);
}

//endregion

//region Main script
printHeader();
printConfig(config);
prismWebDB.getCollection('dashboards').find({}).forEach(function (dash) {
    validateDashboard(dash);
});
printDashSharesStats();
//endregion
