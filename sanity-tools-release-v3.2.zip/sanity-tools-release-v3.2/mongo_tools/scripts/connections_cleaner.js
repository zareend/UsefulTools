/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Connections cleaner';

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs,
        showConnections: false
    }
};
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

function printConnectionStats() {
    logger('');
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ');
        logger(JSON.stringify(collectedStats, undefined, 2));

    }

    var notUsedPercentage = getPercent(collectedStats.connections_connection_not_used,
        connectionsTotal
    );
    logger('Total connections ' + connectionsTotal + ', not used: ' +
        collectedStats.connections_connection_not_used + ' / ' + notUsedPercentage + ' %');
    divider();
}

printHeader();
printConfig(config);

// Global variables
var connectionsTotal = prismWebDB.getCollection('connections').count();
// Functions

// Main script
logger('Total connections: ' + connectionsTotal);
logger('');
prismWebDB.connections.aggregate([
    {
        $lookup:
            {
                from: 'datasets',
                localField: '_id',
                foreignField: 'connection',
                as: 'matched_docs'
            }
    },
    {
        $match: { 'matched_docs': { $eq: [] } }
    }
]).forEach(function (connectionDoc) {
    //logger(connectionDoc);
    var isConnectionBeingUsed = prismWebDB.datasets.findOne({ connection: connectionDoc._id });
    if (!isConnectionBeingUsed) {
        if (config.logging.showConnections) {
            logger('Connection ' + connectionDoc._id + ' not used, last updated: ' +
                connectionDoc.lastUpdated + ' schema: ' + connectionDoc.schema + '  ');
        }

        collectStats('connections_connection_not_used', 1);
        if (doCleanup) {
            var result = prismWebDB.connections.deleteOne({ _id: connectionDoc._id });
            if (result.deletedCount !== 1) {
                logger('did not manage to delete connection _id:' + connectionDoc._id.str);
            }
        }

    } else {
        logger('Connection ' + connectionDoc._id + ' is used, last updated: ' +
            connectionDoc.lastUpdated + ' schema: ' + connectionDoc.schema + '  ');
    }
});
printConnectionStats();
logger('Script has finished execution successfully ' + ' © Sisense');


