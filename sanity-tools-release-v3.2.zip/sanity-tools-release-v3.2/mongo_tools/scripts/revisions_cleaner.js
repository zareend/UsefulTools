// General Info
var version = '3.1.3';
var scriptName = 'Revisions cleaner';

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

function printRevisionsStats() {
    logger('');
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ');
        logger(JSON.stringify(collectedStats, undefined, 2));

    }
    var oldRevisionsPercentage = getPercent(collectedStats.elasticube_revision_outdated, revisionsTotal);
    logger(
        'Total revisions ' + revisionsTotal + ', not used: ' + collectedStats.elasticube_revision_outdated +
        ' / ' + oldRevisionsPercentage + ' %');
    divider()
}

printHeader();
printConfig(config);

// Global variables
var revisionsTotal = prismWebDB.getCollection('elasticubeRevisions').count();
// Functions

// Main script
logger('Total revisions: ' + revisionsTotal);
logger('');

var revisionsCollection = prismWebDB.getCollection('elasticubeRevisions');

revisionsCollection.aggregate([
    { $sort: { _id: 1 } },
    {
        $group: {
            _id: '$elasticube.oid',
            title: { $last: '$elasticube.title' },
            lastRevision: { $last: '$oid' }
        }
    }
]).forEach(function (revisionToKeep) {
    if (!revisionToKeep) {
        logger('there were no revisions');
        return;
    }

    logger('');

    logger('checking revisions for ' + revisionToKeep.title + ' (' + revisionToKeep._id + ')');
    var foundToDelete = revisionsCollection.count(
        { 'elasticube.oid': revisionToKeep._id, oid: { $ne: revisionToKeep.lastRevision } });
    collectStats('elasticube_revision_outdated', foundToDelete);
    if (foundToDelete > 0) {
        if (doCleanup) {
            logger('keeping last revision: ' + revisionToKeep.lastRevision);
            logger('deleting ' + foundToDelete + ' revisions for ' + revisionToKeep.title + ' (' +
                revisionToKeep._id + ')');
            var result = revisionsCollection.deleteMany(
                { 'elasticube.oid': revisionToKeep._id, oid: { $ne: revisionToKeep.lastRevision } });

            if (result.deletedCount === 0) {
                logger('nothing to delete for this elasticube');

                return;
            }

            logger('deleted ' + result.deletedCount + ' revisions for ' + revisionToKeep.title);
        } else {
            logger(' - should remove ' + foundToDelete + ' revisions for cube ' + revisionToKeep.title + ', last relevant revision: ' + revisionToKeep.lastRevision);
        }
    }


});
printRevisionsStats();
logger('Script has finished execution successfully ' + ' © Sisense');


