/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
var version = '3.1.3';
var scriptName = 'Users group duplicates';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup,
        cleanGroups: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

// Base functions
printHeader();
printConfig(config);

prismWebDB.getCollection('users').find({}).forEach(function (user) {

    var results = prismWebDB.getCollection('users').aggregate([
        { '$match': { '_id': user._id } },
        { '$project': { 'groups': 1, '_id': 0 } },
        { '$unwind': '$groups' },
        { '$group': { '_id': '$groups', 'count': { '$sum': 1 } } },
        { '$match': { 'count': { '$gt': 1 } } }
    ]).toArray();
    if (results.length > 0) {
        logger('User: ' + user.userName + ' | ' + user._id + ' | ' + user.roleId);
        prismConfig.getCollection('roles').find({ _id: user.roleId }).forEach(function (role) {
            logger('role id: ' + role._id + ' role name: ' + role.displayName);
        });

        results.forEach(function (result) {
            collectStats('duplicated_user_group_items', 1);
            prismWebDB.getCollection('groups')
                .find({ '_id': ObjectId(result._id) })
                .forEach(function (group) {
                    logger('group name: ' + group.name);
                });
            logger('group id: ' + result._id + ' count: ' + result.count);
            if (doCleanup) {
                var groups = user.groups.filter(onlyUnique);
                logger(' keep groups: ' + groups.length);
                prismWebDB.getCollection('users').update(
                    { _id: user._id },
                    { $set: { groups: groups } }
                );
            }

        });
        divider()
    }

});
