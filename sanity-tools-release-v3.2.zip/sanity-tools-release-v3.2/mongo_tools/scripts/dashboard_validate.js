﻿//region General Info
/**
 * Created by yaroslav.korzh
 * Updated 16/12/2019
 */

// General Info
var version = '3.1.3';
var scriptName = 'Dashboards validate';
//endregion

//region Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup,
        restoreFromProxy: false,
        restoreFromWidgets: false,
        fixDashboardWidgets: false,
        fixOwners: doCleanup
    },
    validation: {
        layout: false
    },
    logging: {
        showLogs: showLogs,
        showWidgetInfo: false,
        showOnlyInvalid: true,
        showShareDuplicates: false
    },
    collection: 'dashboards_copy_SET',
    drillPrefix: '_drill'
};

//endregion

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';

function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    } else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}

loadScript('utils.js', utilsFolder);
//endregion

//region Basic functions

//endregion

//region Global variables
var dashCount;
new Date();

var invalidUserCount = 0;
var ghostWidgetCount = 0;

var limit = 10000;
var queryLimit = 0;

var skip = 0;


var documentKeys = {
    title: '$title',
    oid: '$oid',
    instanceType: '$instanceType',
    userId: '$userId',
    owner: '$owner',
    lastUpdated: '$lastUpdated',
    _id: '$_id'
};
var dashAgg = {
    oid: '$oid',
    userId: '$userId'
    //instanceType: '$instanceType'
};
var aggregationOptions = {
    allowDiskUse: true
};
var maxDuplicates = 0;
var maxShares = 0;
var sortByUsed = {lastUsed: -1};
var blankFilter = {};

var bulk = prismWebDB.dashboards.initializeUnorderedBulkOp();
var groupsMap = getGroupsMap();
//endregion

//region Functions
function parseStringToObjectId(id) {
    if (id === null) {
        return;
    }
    if (typeof id === 'string') {
        return ObjectId(id);
    } else {
        return id;
    }
}
function printDashboardsInfo(results) {
    var action = doCleanup ? 'Start cleaning' : 'set "doCleanup = true;" to start cleaning';

    var duplicatesTotal = 0;
    var dashboardsTotal = prismWebDB.getCollection('dashboards').count();

    for (var k = 0, l = results.length; k < l; k++) {
        var dash = results[k];
        duplicatesTotal += dash.docs.length;
    }

    var duplicatesPercentage = getPercent(duplicatesTotal, dashboardsTotal);
    logger('   ');
    dividerHeader('Duplicated dashboards');
    logger('Found ' + results.length + ' duplication dashboard cases and ' + duplicatesTotal +
        ' duplicated dashboard instances');
    collectStats('dashboard_duplicates_cases', results.length);
    collectStats('dashboard_duplicates_items', duplicatesTotal);
    logger('Total dashboards ' + dashboardsTotal + ' duplication: ' + duplicatesPercentage + ' %');
    if (duplicatesPercentage > 0 || results.length > 0) {
        logger(action);
    }

}

function analyzeJaql(jaql, type, dimensions, result, dash) {
    var datetime = 'datetime';
    var isValid = true;
    var dim;
    if (jaql) {
        if (jaql.table && jaql.column) {
            dim = '[';
            dim += jaql.table + '.' + jaql.column;
            if (jaql.datatype === datetime) {
                dim += '.' + jaql.level;
            }
            dim += ']';
        } else {
            dim = jaql.dim;
        }

        if (dimensions.indexOf(dim) !== -1) {
            if (jaql.datatype !== datetime) {
                logger(' dimension already used: ' + dim + ' filter type: ' + type);
                logger('  dashboard _id: ' + dash._id + ' title: ' + secureOutput(dash.title) + ' datasource: ' +
                    dash.datasource.fullname + ' user: ' + dash.userId);
                if (jaql.filter) {
                    logger('   filter members: ' + JSON.stringify(jaql.filter.members));
                }
                logger('   jaql: ');
                logger(JSON.stringify(jaql, undefined, 2));

                collectStats('invalid_dashboard_filters_dimension_already_used', 1);
                result.valid = false;
                result.count += 1;
                isValid = false;
            }

        } else {
            dimensions.push(dim);
        }
    }
    return isValid;
}

function analyzeFilter(filter, type, dimensions, result, dash) {
    var isValid = true;
    if (filter.jaql) {
        var jaql = filter.jaql;
        isValid = analyzeJaql(jaql, type, dimensions, result, dash);
        if (!isValid) {
            logger(' ! should remove filter');
            //logger(JSON.stringify(jaql, undefined, 2));
        }
    }
    if (filter.isCascading) {
        //logger(' cascading filter levels: ', dimensions);
        var validLevels = [];
        filter.levels.forEach(function (filterLevel, index) {
            isValid = analyzeJaql(filterLevel, type + '-cascading', dimensions, result, dash);
            if (isValid) {
                validLevels.push(filterLevel);
            } else {
                logger(' !! should remove filterLevel ' + index);
                //logger(JSON.stringify(filterLevel, undefined, 2));
            }
        });
        if (filter.levels.length !== validLevels.length) {
            logger('Levels: ' + filter.levels.length + ' Valid:' + validLevels.length);
        }

        if (config.cleanup.doCleanup) {
            filter.levels = validLevels;
        }
    }
    return isValid;
}

function isFolderIdExists(id) {
    var folderOid = parseStringToObjectId(id);
    // If we found a group with the given id
    return prismWebDB.tags.find({oid: folderOid}).limit(1).hasNext();
}

function clearLayoutFromGhostWidget(dash, ghostWidget) {
    // removing element
    ghostWidget.subcell.elements.splice(ghostWidget.elementidx, 1);
    if (ghostWidget.subcell.elements.length === 0) {
        // removing subcell
        ghostWidget.cell.subcells.splice(ghostWidget.subcellidx, 1);
        if (ghostWidget.cell.subcells.length === 0) {
            // removing cell
            ghostWidget.col.cells.splice(ghostWidget.cellidx, 1);
            /* decided to leave the column empty when there are no cells */
            //if (ghostWidget.col.cells.length == 0) {
            // remove column
            //ghostWidget.columns.splice(ghostWidget.colidx, 1);
            //}
        }
    }

    if (config.cleanup.doCleanup) {
        logger('Cleaning ghost widget from ' + secureOutput(dash.title) + ' (_id): ' + dash._id +
            ' (oid): ' + dash.oid + ' (userId): ' + dash.userId + ' ');
        prismWebDB.dashboards.update(
            {
                oid: dash.oid, userId: dash.userId
            },
            {
                $set: {
                    layout: dash.layout
                }
            }
        );
    }
}

function listWidgets(widgets) {
    if (config.logging.showWidgetInfo) {
        widgets.forEach(function (widget) {
            logger(
                '    widget: ' + secureOutput(secureOutput(widget.title)) + ' | ' + widget.oid + ' | ' + widget.type + ' | ' +
                widget.instanceType);
        });
    }
}

function onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
}

function restoreWidgetsFromProxy(dash) {
    if (config.cleanup.doCleanup) {
        collectStats('restore_from_proxy', 1);
        logger('No widgets in collection, take from proxy instance');
    }
    var proxyWidgets = prismWebDB.getCollection('widgets')
        .find({dashboardid: dash.oid, instanceType: 'proxy'})
        .toArray();
    listWidgets(proxyWidgets);
    if (config.cleanup.doCleanup) {
        createUserWidgets(proxyWidgets, dash);
    }
}

function createUserWidgets(widgets, dash) {

    widgets.forEach(function (widget) {
        delete widget._id;
        widget.instanceType = dash.instanceType;
        widget.owner = dash.owner;
        widget.userId = dash.userId;
        prismWebDB.getCollection('widgets').insertOne(widget);
    });
    if (dash.widgets.length !== widgets.length) {
        logger('Number of widgets on dashboard and in proxy widgets does not match');
        var widgetsArr = prismWebDB.getCollection('widgets')
            .find({dashboardid: dash.oid, userId: dash.userId, instanceType: dash.instanceType})
            .toArray();
        cleanDashboardWidgets(dash, widgetsArr);
    }
}

function restoreWidgetsFromCollection(dash) {
    collectStats('restore_from_widgets_collection', 1);
    logger('Dashboard ' + dash._id + ' has no widgets to keep, take from widgets collection');
}

function findWidgetsDiff(dashWidgets, widgets) {
    var result = {
        diff: [],
        dash: dashWidgets,
        widgets: widgets
    };
    var targetArr = dashWidgets.length > widgets.length ? dashWidgets : widgets;
    var checkArr = dashWidgets.length > widgets.length ? widgets : dashWidgets;
    var oids = targetArr.map(function (w) {
        return parseObjectIdToString(w.oid);
    });
    var cOids = checkArr.map(function (w) {
        return parseObjectIdToString(w.oid);
    });
    //logger(JSON.stringify(oids));
    //logger(JSON.stringify(cOids));
    for (var i = 0; i < targetArr.length; i++) {
        var el = targetArr[i];
        var oid = oids[i];
        var index = cOids.indexOf(oid);
        if (index === -1) {
            result.diff.push(el);
        }
    }

    return result;
}

function cleanDashboardWidgets(dash, widgets) {
    listWidgets(widgets);
    if (config.cleanup.doCleanup) {
        updateDashboard(dash, widgets);
    }
}

function updateDashboard(dash, widgets) {
    findWidgetsDiff(dash.widgets, widgets);
    prismWebDB.getCollection('dashboards').updateOne(
        {_id: dash._id},
        {$set: {widgets: []}},//{ $addToSet: { widgets: result.diff } },
        {upsert: true}
    );
    /*prismWebDB.getCollection('dashboards').updateOne(
        { _id: dash._id },
        { $set: { widgets: widgets } },//{ $addToSet: { widgets: result.diff } },
        { upsert: true }
    );*/
    widgets.forEach(function (widget) {
        prismWebDB.getCollection('dashboards').update(
            {_id: dash._id},
            {$addToSet: {widgets: widget}},
            {upsert: true}
        );
        //logger(JSON.stringify(res));
    });
}

function fixDashboardWidgets(dash) {
    var widgetsMap = {};

    if (dash.widgets) {
        dash.widgets.forEach(function (widget) {
            //logger('widget: ' +secureOutput(widget.title) + ' | ' + widget.oid + ' | ' + widget.type  )
            if (widgetsMap[widget.oid]) {
                widgetsMap[widget.oid].push(widget);
            } else {
                widgetsMap[widget.oid] = [];
                widgetsMap[widget.oid].push(widget);
            }
        });
        var isDrill = dash.title.indexOf(config.drillPrefix) !== -1;
        var widgetsArr = prismWebDB.getCollection('widgets')
            .find({dashboardid: dash.oid, userId: dash.userId})
            .toArray();

        if (widgetsArr.length !== dash.widgets.length && !isDrill) {
            if (widgetsArr.length > 0) {
                logger(
                    'dashboard: ' + secureOutput(dash.title) + ' | ' + dash.oid + ' | ' + dash.instanceType +
                    ' | ' + dash.userId + ' | dash widgets ' + dash.widgets.length +
                    ' | widgets collection count ' + widgetsArr.length);
                //logger('Number of widgets does not match');
                //logger('dashbboard widgets: ' + dash.widgets.length);
                listWidgets(dash.widgets);
                //logger('widgets from collection: ' + widgetsArr.length);
                listWidgets(widgetsArr);
            } else {
                logger(' - dashboard: ' + secureOutput(dash.title) + ' | ' + dash.oid + ' | ' +
                    dash.instanceType +
                    ' | ' + dash.userId + ' | dash widgets ' + dash.widgets.length +
                    ' | was not opened yet ');
                //logger('Number of widgets does not match');
                //collectStats('widget_count_not_match', 1);
                //logger('dashbboard widgets: ' + dash.widgets.length);
                listWidgets(dash.widgets);
                //logger('widgets from collection: ' + widgetsArr.length);
                //listWidgets(widgetsArr);
            }

            var widgetsToKeep = [];
            widgetsArr.forEach(function (widget) {
                if (widgetsMap[widget.oid] && widgetsMap[widget.oid].length >= 1) {
                    var lastDate;
                    widgetsMap[widget.oid].forEach(function (widgetInner) {
                        if (!lastDate || (lastDate <= widgetInner.lastUpdated)) {
                            lastDate = widgetInner.lastUpdated;
                        }
                    });

                    widgetsMap[widget.oid].forEach(function (widgetInner) {
                        if (lastDate === widgetInner.lastUpdated) {
                            widgetsToKeep.push(widget);
                        }
                    });
                } else {
                    widgetsToKeep.push(widget);
                }
            });

            if (widgetsToKeep.length === 0) {
                // TODO temp not create widgets in collection
                if (config.cleanup.restoreFromProxy && widgetsArr.length === 0) {
                    restoreWidgetsFromProxy(dash);
                } else if (config.cleanup.restoreFromWidgets) {
                    restoreWidgetsFromCollection(dash);
                }
            } else {
                if (config.cleanup.doCleanup) {
                    logger('Keep widgets: ' + widgetsToKeep.length);
                    cleanDashboardWidgets(dash, widgetsToKeep);
                }
            }
            //dividerSmall()
        } else {
            //logger('Widget count is equal ' + secureOutput(dash.title) + ' | ' + dash.oid + ' | ' + dash.instanceType);
        }

    }
}

function reviewDuplicatedItems(agg) {
    if (agg.length > 0) {
        logger('Dashboards have multiple documents with same oid and different instanceType');
        logger(' ');

        agg.forEach(function (elem) {
            collectStats('dashboard_same_oid_for_different_instancetypes', 1);
            logger(' duplicated case:');
            elem.docs.forEach(function (item) {
                var msg = '  - ';
                if ((parseObjectIdToString(item['userId']) !==
                    parseObjectIdToString(item['owner'])) && item['instanceType'] === 'owner') {
                    msg += ' ! remove owner instance: ';
                    bulk.find({'_id': item._id}).remove();
                }
                if ((parseObjectIdToString(item['userId']) ===
                    parseObjectIdToString(item['owner'])) && item['instanceType'] !== 'owner') {
                    msg += ' ! remove not owner instance: ';
                    bulk.find({'_id': item._id}).remove();
                }
                if ((parseObjectIdToString(item['userId']) === null) && item['instanceType'] !==
                    'proxy') {
                    msg += ' ! remove not proxy instance: ';
                    bulk.find({'_id': item._id}).remove();
                }
                Object.keys(documentKeys).forEach(function (key) {
                    if (key === 'title') {
                        msg += key + ': ' + secureOutput(item[key]) + ' | ';
                    } else {
                        msg += key + ': ' + item[key] + ' | ';
                    }
                });
                logger(msg);
            });
        });
        logger(' ');
    }

}

function validateFolderId(id) {
    return (validateObjectId(id) && isFolderIdExists(id));
}

function validateSharedDashboard(dash) {
    var objectOid = parseStringToObjectId(dash.oid);
    return prismWebDB.dashboards.find({oid: objectOid, instanceType: 'owner'}).limit(1).hasNext();
}

function validateParentFolder(dash) {
    if (dash.parentFolder && !!dash.parentFolder) {
        return validateFolderId(dash.parentFolder);
    } else {
        return true;
    }
}

function validateUser(dash) {
    var objectOid = parseStringToObjectId(dash.userId);
    if (dash.instanceType === 'proxy') {
        return true;
    }
    if (typeof dash.userId === 'string') {
        logger('User Id for ' + secureOutput(dash.title) + ' (_id): ' + dash._id + ' is a string ');
        if (config.cleanup.doCleanup) {
            logger(
                'Casting UserId to ObjectId ' + secureOutput(dash.title) + ' (_id): ' + dash._id + ' ');
            prismWebDB.dashboards.update(
                {
                    oid: dash.oid, userId: dash.userId
                },
                {
                    $set: {
                        userId: objectOid
                    }
                }
            );
        }
    }
    var result;
    if (objectOid) {
        result = prismWebDB.users.find({_id: objectOid}).limit(1).hasNext();
    }
    else if(!objectOid) {
        result = false;
    }


    return result;
}

function validateOwner(dash) {
    var objectOid = parseStringToObjectId(dash.owner);

    return prismWebDB.users.find({_id: objectOid}).limit(1).hasNext();
}

function validateFilters(dash) {
    var result = {valid: true, count: 0};

    if (dash.filters) {
        var dimensions = [];

        var validFilters = [];
        dash.filters.forEach(function (filter) {
            var isValid = analyzeFilter(filter, 'dash', dimensions, result, dash);
            if (isValid) {
                validFilters.push(filter);
            }
        });

        if (dash.filters.length !== validFilters.length) {
            logger('Filters: ' + dash.filters.length + ' Valid:' + validFilters.length);
        }

        if (config.cleanup.doCleanup) {
            dash.filters = validFilters;
        }
    }
    if (dash.defaultFilters) {
        var dimensionsDefault = [];

        var validDefaultFilters = [];
        dash.defaultFilters.forEach(function (filter) {
            var isValid = analyzeFilter(filter, 'default', dimensionsDefault, result, dash);
            if (isValid) {
                validDefaultFilters.push(filter);
            }
        });
        if (dash.defaultFilters.length !== validDefaultFilters.length) {
            logger('Default Filters: ' + dash.defaultFilters.length + ' Valid:' +
                validDefaultFilters.length);
        }

        if (config.cleanup.doCleanup) {
            dash.defaultFilters = validDefaultFilters;
        }
    }
    if (!result.valid) {
        logger('broken filters: ' + result.count);
    }

    return result.valid;
}

function iterateLayout(dash, isLayoutValid, dashboardWidgets, ownerWidgets, notOpened) {
    for (var colidx = 0; colidx < dash.layout.columns.length; colidx++) {
        var col = dash.layout.columns[colidx];
        if (col.cells && col.cells.length > 0) {
            for (var cellidx = 0; cellidx < col.cells.length; cellidx++) {
                var cell = col.cells[cellidx];
                if (cell.subcells && cell.subcells.length > 0) {
                    for (var subcellidx = 0; subcellidx < cell.subcells.length; subcellidx++) {
                        var subcell = cell.subcells[subcellidx];
                        if (subcell.elements && subcell.elements.length > 0) {
                            for (var elementidx = 0; elementidx <
                            subcell.elements.length; elementidx++
                            ) {
                                var element = subcell.elements[elementidx];
                                if (dashboardWidgets.indexOf(element.widgetid) === -1 &&
                                    ownerWidgets.indexOf(element.widgetid) !== -1) {
                                    notOpened = true;
                                }

                                // If the widget exists on the layout but not for real
                                if (dashboardWidgets.indexOf(element.widgetid) === -1 &&
                                    ownerWidgets.indexOf(element.widgetid) === -1) {
                                    isLayoutValid = false;

                                    var ghostWidget = {
                                        col: col,
                                        colidx: colidx,
                                        cell: cell,
                                        cellidx: cellidx,
                                        subcell: subcell,
                                        subcellidx: subcellidx,
                                        element: element,
                                        elementidx: elementidx
                                    };
                                    logger('Ghost widget ' + element.widgetid + '  at: col ' +
                                        colidx + ' cell ' + cellidx + ' subcell ' + subcellidx +
                                        ' elem ' + elementidx + ' ');
                                    clearLayoutFromGhostWidget(dash, ghostWidget);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return {
        isLayoutValid: isLayoutValid,
        notOpened: notOpened
    };
}

function validateDashboardLayout(dash) {

    var isLayoutValid = true;
    var isDrill = dash.title.indexOf(config.drillPrefix) !== -1;

    if (dash.layout && !isDrill) {
        // The layout is validate if there are no columns
        if (!dash.layout.columns) {
            return true;
        }

        var dashboardWidgets = [];
        var ownerWidgets = [];

        prismWebDB.widgets.find({dashboardid: dash.oid, userId: dash.userId})
            .forEach(function (widget) {
                dashboardWidgets.push(parseObjectIdToString(widget.oid));
            });
        prismWebDB.widgets.find({dashboardid: dash.oid, instanceType: 'owner'})
            .forEach(function (widget) {
                ownerWidgets.push(parseObjectIdToString(widget.oid));
            });
        var notOpened = false;
        iterateLayout(dash, isLayoutValid, dashboardWidgets, ownerWidgets, notOpened);

        if (notOpened) {
            //logger('Dashboard ' + dash.oid + ' was not opened by ' + dash.userId + ' yet, widgets not created');
        }
    } else if (!isDrill) {
        isLayoutValid = false;
        logger('Dashboard ' + secureOutput(dash.title) + ' (_id): ' + dash._id + ' has no layout');

        if (config.cleanup.doCleanup) {
            logger('Add layout to ' + secureOutput(dash.title) + ' (_id): ' + dash._id + ' Dashboard ');
            prismWebDB.dashboards.update(
                {_id: dash._id},
                {$set: {'layout': {}}},
                {multi: true}
            );
        }
    }

    return (isLayoutValid);
}

function validateLastPublishTypeIsString(lastPublish) {
    return typeof lastPublish === 'string';
}

function validateLastPublishValue(lastPublish) {
    return !isNaN(Date.parse(lastPublish));
}

function validateInstance(dash) {
    var isValid = true;
    // If it's a shared dashboard (shared to the owner and to another one)
    if (dash.instanceType === 'proxy' || dash.instanceType === 'user') {
        if (!validateSharedDashboard(dash)) {
            isValid = false;
            logger(
                'Dashboard (oid): ' + dash.oid + ' is shared and does not have an owner instance');
            collectStats('no_owner_dashboard', 1);
            var newDash = {};
            Object.keys(dash).forEach(function (item) {
                newDash[item] = dash[item];
            });

            if (config.cleanup.doCleanup) {
                delete newDash._id;
                newDash.instanceType = 'owner';
                newDash.userId = dash.owner;
                prismWebDB.getCollection('dashboards').insert(newDash);
            }

        }
    }
    return isValid;
}

function validateLastPublish(dash, index) {
    var result = true;
    if (validateLastPublishTypeIsString(dash.lastPublish)) {
        result = false;
        logger(index + ' / ' + dashCount + ' ' + 'dash (_id): ' + dash._id + ' (title): ' +
            secureOutput(dash.title) +
            ' has invalid lastPublish field: ' + dash.lastPublish);
        collectStats('dashboard_invalid_last_update_field', 1);
        if (validateLastPublishValue(dash.lastPublish)) {
            if (config.cleanup.doCleanup) {
                logger(
                    'Dashboard (_id): ' + dash._id + ' changing lastPublish field type to Date: ' +
                    dash.lastPublish);
                prismWebDB.dashboards.update({_id: dash._id},
                    {$set: {lastPublish: new Date(dash.lastPublish)}}
                );
            }
        } else {
            logger(index + ' / ' + dashCount + ' ' + 'Dashboard (_id): ' + dash._id + ' (title): ' +
                secureOutput(dash.title) +
                ' lastPublish field it is not Date: ' + dash.lastPublish);
        }
    }
    return result;
}

function validateLayout(dash, index) {
    var isValid = true;
    if (dash.instanceType !== 'proxy' && !validateDashboardLayout(dash)) {
        isValid = false;
        ghostWidgetCount += 1;
        collectStats('dashboard_ghost_widgets', 1);
        logger(index + ' / ' + dashCount + ' ' + 'Dashboard (_id): ' + dash._id + ' (oid): ' +
            dash.oid + ' (title): ' +
            secureOutput(dash.title) + ' of user ' + dash.userId + ' has a GHOST widget');
    }
    return isValid;
}

function validateUserExists(userId) {
    if (!userId) {
        return false;
    }
    var objectOid = parseStringToObjectId(userId);

    return prismWebDB.users.find({_id: objectOid}).limit(1).hasNext();
}

function validateGroup(groupId) {
    var result = true;
    if (!groupId) {
        return false;
    }
    var objectOid = parseStringToObjectId(groupId);
    if (!groupsMap[objectOid]) {
        result = prismWebDB.groups.find({_id: objectOid}).limit(1).hasNext();
    }

    return result;
}

function validateShare(share) {
    var result;
    if (share.type === 'group') {
        result = validateGroup(share.shareId);
    } else if (share.type === 'user') {
        result = validateUserExists(share.shareId);
    } else {
        // dashboard owner
        result = validateUserExists(share.shareId);
    }
    return result;
}

function normalizeShare(dash, share, validShare, isValid, sharesObj, sharesToKeep, brokenShares, hasOwnerShare, showShareCheck) {
    if (share.shareId) {
        if (sharesObj[share.shareId]) {
            sharesObj[share.shareId].count += 1;
            sharesObj[share.shareId].agg.push(share);
        } else {
            var shareObj = {
                shareId: share.shareId,
                type: share.type,
            };
            if(typeof share.rule !== 'undefined') {
                shareObj.rule = share.rule;
            }
            else {
                mappingStats('dashboard_share_rule_undefined', 1);
            }
            if(typeof share.subscribe !== 'undefined') {
                shareObj.subscribe = share.subscribe;
            }
            else {
                mappingStats('dashboard_share_subscribe_undefined', 1);
            }

            if (validShare) {
                sharesToKeep.push(shareObj);
            } else {
                isValid = false;
                if (showShareCheck) {
                    logger(' - Non-existing Share: ' + share.shareId + ' ' + share.type);
                } else {
                    brokenShares.push(share);
                }
                collectStats('dashboard_non_existing_share', 1);
            }

            sharesObj[share.shareId] = share;
            sharesObj[share.shareId].count = 1;
            sharesObj[share.shareId].agg = [];
            sharesObj[share.shareId].agg.push(share);
        }

        if (share.shareId.valueOf() === dash.owner.valueOf() && share.type === 'user') {
            hasOwnerShare = true;
        }
    } else {
        dividerHeader('Broken Share');
        logger(JSON.stringify(share, null, 2));
        dividerFooter('Broken Share');
    }
    return {
        sharesToKeep: sharesToKeep,
        isValid: isValid,
        hasOwnerShare: hasOwnerShare
    }
}

function fixShares(dash, sharesObj, isValid, sharesToKeep, hasOwnerShare) {
    Object.keys(sharesObj).forEach(function (item) {

        var share = sharesObj[item];
        if (share.count > 1) {
            if (share.count > maxDuplicates) {
                maxDuplicates = share.count;
            }
            collectStats('dashboard_shares_duplicates', 1);
            isValid = false;
            logger('You have duplicates in shares collection for dashboard');
            logger('Duplicate: ' + item + ' | ' + share.type + ' | ' + share.rule + ' | ' +
                share.subscribe + ' - count: ' + share.count);

            if (config.logging.showShareDuplicates) {
                share.agg.forEach(function (shareItem, index) {
                    logger(shareItem.shareId + ' | ' + index + ' | ' + shareItem.type + ' | ' +
                        shareItem.rule + ' | ' + shareItem.subscribe);
                });
            }

            dividerSmall()
        }

    });

    if (sharesToKeep.length === 0) {
        logger('! Dashboard has no valid shares - should be removed');
        collectStats('dashboard_has_no_valid_shares', 1);
        if (config.cleanup.doCleanup) {
            logger('Dashboard (_id): ' + dash._id + ' is removed due to invalid shares: ' +
                dash.userId);
            var result = prismWebDB.getCollection('dashboards')
                .remove({_id: dash._id, userId: dash.userId});
            logger('Removed dashboards: ' + result.nRemoved); // JSON.stringify(result, undefined, 2)
            var resultWidgets = prismWebDB.getCollection('widgets')
                .remove({dashboardid: dash.oid, userId: dash.userId});
            logger('Removed widgets: ' + resultWidgets.nRemoved); // JSON.stringify(result, undefined, 2)
        }
    }
    if (config.cleanup.doCleanup || !hasOwnerShare) {
        logger('Keep shares: ' + sharesToKeep.length);
        prismWebDB.getCollection('dashboards').update(
            {'_id': dash._id},
            {$set: {'shares': sharesToKeep}}
        );
    }
    return isValid;
}

function validateDashboardShares(dash) {
    var isValid = true;

    var showShareCheck = true;
    if (dash.shares) {
        if (dash.shares.length > 1000) {
            showShareCheck = false;
        }
    }


    var sharesObj = {};
    var sharesToKeep = [];
    var brokenShares = [];
    var hasOwnerShare = false;
    var isOwner = dash.instanceType === 'owner';
    if (dash.shares) {
        if (dash.shares.length > maxShares) {
            maxShares = dash.shares.length;
        }
        dash.shares.forEach(function (share) {
            var validShare = validateShare(share);
            var res = normalizeShare(dash, share, validShare, isValid, sharesObj, sharesToKeep, brokenShares, hasOwnerShare, showShareCheck);
            sharesToKeep = res.sharesToKeep;
            hasOwnerShare = res.hasOwnerShare;
        });
        if (!showShareCheck) {
            logger(' ! Broken shares: ' + brokenShares.length);
        }

        if (!hasOwnerShare) {
            logger('Owner is not in shares');
            collectStats('dashboard_owner_not_in_shares', 1);
            if (config.cleanup.fixOwners) {
                sharesToKeep.push({shareId: dash.owner, type: 'user'});
            }
        }
        fixShares(dash, sharesObj, isValid, sharesToKeep, hasOwnerShare);

    } else {
        logger('Dashboard ' + dash._id + ' with  oid: ' + dash.oid + ' user: ' + dash.userId +
            '  has no shares');
        if (config.cleanup.doCleanup) {
            if (isOwner) {
                logger('Create shares ');
                prismWebDB.getCollection('dashboards').update(
                    {'_id': dash._id},
                    {$set: {'shares': [{shareId: dash.owner, type: 'user'}]}}
                );
            }

        }
    }
    return isValid;
}

function validateLastUsed() {
    return true;
}

function checkId(dash, index, isValid, resultWidgets) {
    if (!validateObjectId(dash._id)) {
        isValid = false;
        collectStats('dashboard_invalid_id', 1);
        logger(index + ' / ' + dashCount + ' ' + 'Dashboard (_id): ' + dash._id +
            ' has invalid dashboard id');
        if (config.cleanup.doCleanup) {
            // remove dashboard
            logger('Dashboard (_id): ' + dash._id + ' is removed due to invalid _id: ' +
                dash.userId);
            removeDashboard(dash._id);
            resultWidgets = prismWebDB.getCollection('widgets')
                .remove({dashboardid: dash.oid, userId: dash.userId});
            logger('Removed widgets: ' + resultWidgets.nRemoved); // JSON.stringify(result, undefined, 2)
        }
    }
    return isValid;
}

function checkOid(dash, index, isValid) {
    if (!validateObjectId(dash.oid)) {
        isValid = false;
        collectStats('dashboard_invalid_oid', 1);
        logger(index + ' / ' + dashCount + ' ' + 'Dashboard (_id): ' + dash._id +
            ' has invalid dashboard oid: ' + dash.oid);
        if (config.cleanup.doCleanup) {
            // remove dashboard
            logger('Dashboard (_id): ' + dash._id + ' is removed due to invalid oid: ' +
                dash.userId);
            removeDashboard(dash._id);
        }
    }
    return isValid;
}

function checkUser(dash, index, isValid, resultWidgets) {
    if (!validateUser(dash)) {
        isValid = false;
        logger(
            index + ' / ' + dashCount + ' ' + 'Dashboard (_id): ' + dash._id + ' (title): ' +
            secureOutput(dash.title) +
            ' has invalid user: ' + dash.userId);
        collectStats('dashboard_invalid_user', 1);
        invalidUserCount += 1;
        if (config.cleanup.doCleanup) {
            // remove dashboard
            logger('Dashboard (_id): ' + dash._id + ' is removed due to invalid user: ' +
                dash.userId);
            var result = prismWebDB.getCollection('dashboards')
                .remove({_id: dash._id, userId: dash.userId});
            logger('Removed dashboards: ' + result.nRemoved); // JSON.stringify(result, undefined, 2)
            resultWidgets = prismWebDB.getCollection('widgets')
                .remove({dashboardid: dash.oid, userId: dash.userId});
            logger('Removed widgets: ' + resultWidgets.nRemoved); // JSON.stringify(result, undefined, 2)
        }
    }
    return isValid;
}

function checkOwner(dash, index, isValid, resultWidgets) {
    if (!validateOwner(dash)) {
        isValid = false;
        logger(
            index + ' / ' + dashCount + ' ' + 'Dashboard (_id): ' + dash._id + ' (title): ' +
            secureOutput(dash.title) +
            ' has invalid owner: ' + dash.userId);
        collectStats('dashboard_invalid_owner', 1);
        invalidUserCount += 1;
        if (config.cleanup.doCleanup) {
            // remove dash
            logger('Dashboard (oid): ' + dash.oid + ' is removed due to invalid owner: ' +
                dash.owner);
            var result = prismWebDB.getCollection('dashboards')
                .remove({_id: dash._id, owner: dash.owner});
            logger('Removed dashboards: ' + result.nRemoved); // JSON.stringify(result, undefined, 2)
            resultWidgets = prismWebDB.getCollection('widgets')
                .remove({dashboardid: dash.oid});
            logger('Removed widgets: ' + resultWidgets.nRemoved); // JSON.stringify(result, undefined, 2)
        }
    }
    return isValid;
}

function checkLastUsed(dash, index, isValid) {
    if (!validateLastUsed()) {
        logger('Dashboard was not used ');
    }
    return isValid;
}

function checkFolder(dash, index, isValid) {
    if (!validateParentFolder(dash)) {
        isValid = false;
        logger(index + ' / ' + dashCount + ' ' + 'Dashboard (_id): ' + dash._id +
            ' has invalid parent folder: ' +
            dash.parentFolder);
        collectStats('dashboard_invalid_parent_folder', 1);
        if (config.cleanup.doCleanup) {
            logger('Dashboard (_id): ' + dash._id + ' removing parent folder: ' +
                dash.parentFolder);
            prismWebDB.dashboards.update(
                {_id: dash._id},
                {$unset: {'parentFolder': ''}},
                {multi: true}
            );
        }
    }
    return isValid;
}

function checkSource(dash, index, isValid) {
    if (dash.source && !validateObjectId(dash.source)) {
        isValid = false;
        collectStats('dashboard_source_string', 1);
        logger(index + ' / ' + dashCount + ' ' + 'Dashboard (_id): ' + dash._id +
            ' has source string oid: ' + dash.oid);
        if (config.cleanup.doCleanup) {
            // remove dashboard
            logger('Dashboard (_id): ' + dash._id + ' is removed due to invalid oid: ' +
                dash.userId);
            prismWebDB.dashboards.update(
                {_id: dash._id},
                {$set: {'source': parseStringToObjectId(dash.source)}},
                {multi: true}
            );
        }
    }
    return isValid;
}

function checkFilters(dash, index, isValid) {
    if (!validateFilters(dash)) {
        isValid = false;
        if (config.cleanup.doCleanup) {
            logger(
                index + ' / ' + dashCount + ' ' + 'Dashboard (_id): ' + dash._id +
                ' (title): ' +
                secureOutput(dash.title) +
                ' fixing filters ');
            prismWebDB.dashboards.update(
                {
                    oid: dash.oid, userId: dash.userId
                },
                {
                    $set: {
                        filters: dash.filters
                    }
                }
            );
            prismWebDB.dashboards.update(
                {
                    oid: dash.oid, userId: dash.userId
                },
                {
                    $set: {
                        defaultFilters: dash.defaultFilters
                    }
                }
            );
        } else {
            logger(
                index + ' / ' + dashCount + ' ' + 'Dashboard (_id): ' + dash._id +
                ' (title): ' +
                secureOutput(dash.title) +
                ' has invalid filters ');
        }
        collectStats('invalid_dashboard_filters', 1);
    }
    return isValid;
}

function checkPublish(dash, index, isValid) {
    if (!validateLastPublish(dash, index)) {
        isValid = false;
    }
    return isValid;
}

function checkInstance(dash, index, isValid) {
    if (!validateInstance(dash)) {
        isValid = false;
    }
    return isValid;
}

function checkShares(dash, index, isValid) {
    //timestamp('Validate shares');
    var startTime = new Date();
    if (!validateDashboardShares(dash)) {
        isValid = false;
    }
    var endTime = new Date();
    timeDiff(startTime, endTime);
    //logger(' Validate shares: ' + execTime.seconds + ' seconds');

    return isValid;
}

function checkWidgets(dash, index, isValid) {
    //timestamp('Validate widgets');
    if (config.cleanup.fixDashboardWidgets) {
        fixDashboardWidgets(dash);
    }
    return isValid;
}

function checkLayout(dash, index, isValid) {
    if (config.validation.layout && isValid) {
        //timestamp('Validate layout');
        if (!validateLayout(dash, index)) {
            isValid = false;
        }
    }
    return isValid;
}

function check(dash, index, isValid) {

    return isValid;
}

function validateDashboard(dash, index) {
    var isValid = true;
    var resultWidgets = [];
    checkId(dash, index, isValid, resultWidgets);
    checkOid(dash, index, isValid);
    checkUser(dash, index, isValid, resultWidgets);
    checkOwner(dash, index, isValid, resultWidgets);
    if (!isValid) {
        logger('No need to validate other properties, dashboard can be removed');
        if (config.cleanup.doCleanup) {
            return;
        }
    }
    checkLastUsed(dash, index, isValid);
    checkFolder(dash, index, isValid);
    checkSource(dash, index, isValid);
    checkFilters(dash, index, isValid);
    checkPublish(dash, index, isValid);
    checkInstance(dash, index, isValid);
    checkShares(dash, index, isValid);
    checkWidgets(dash, index, isValid);
    checkLayout(dash, index, isValid);
    //timestamp('Finished validate');
    if (!isValid) {
        //logger("db.getSiblingDB('prismWebDB').dashboards.find({_id: ObjectId('" + dash._id + "')});");
        mappingStats('dashboard_invalid_object', 1);
    }

    return isValid;
}

function validateAllDashboards(dashboardAgg) {
    //logger(JSON.stringify(dashboardAgg, null, 2))

    reviewDuplicatedItems(dashboardAgg);
    dashCount = prismWebDB.dashboards.count();

    logger('Total dashboards: ' + dashCount);
    prismWebDB.getCollection('dashboards').createIndex({lastUsed: 1}, {});
    var index = 0;
    prismWebDB.getCollection('dashboards').find(blankFilter).sort(sortByUsed).forEach(function (dash) {
        var startTime = new Date();
        index += 1;

        dividerHeader('Dashboard');
        var result = validateDashboard(dash, index);
        var endTime = new Date();
        var execTime = timeDiff(startTime, endTime);
        var growthPercent = getPercent(index, dashCount);
        if (!result) {
            logger('Dashboard is invalid.')
        }
        logger(growthPercent + '% ' + index + '/' + dashCount + ' ' + ' Dashboard (_id): ' +
            dash._id +
            ' Execution time ' + execTime.seconds + ' seconds');

        dividerFooter('Dashboard');
    });
    if (invalidUserCount > 0) {
        logger('Dashboards with broken users: ' + invalidUserCount + ' copies');
    }
    if (ghostWidgetCount > 0) {
        logger('Dashboards with ghost widgets: ' + ghostWidgetCount + ' copies');
    }
    if (config.cleanup.doCleanup) {
        logger('Bulk delete execute');
        var bulkResult = bulk.execute();
        logger(bulkResult);

    }
    logger('Validating all dashboards has ended.');
}

function removeDashboard(id) {
    var result = prismWebDB.getCollection('dashboards')
        .remove({_id: id});
    logger('Removed dashboards: ' + result.nRemoved); // JSON.stringify(result, undefined, 2)
}

//endregion

//region Main script
printHeader();
printConfig(config);

logger('Validating all dashboards');
var dashAggQuery = getAggQuery(dashAgg);
logger('Checking dashboards duplicates');
var resultsGlobal = prismWebDB.getCollection('dashboards')
    .aggregate(dashAggQuery, aggregationOptions)
    .toArray();

printDashboardsInfo(resultsGlobal);
validateAllDashboards(resultsGlobal);

printStats();
//endregion








