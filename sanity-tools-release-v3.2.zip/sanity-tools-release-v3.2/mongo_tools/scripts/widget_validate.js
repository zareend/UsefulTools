﻿/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
//TODO why widget has shares?

// General Info
var version = '3.1.3';
var scriptName = 'Widget validate';

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showWidgetDuplicates: true,
        showLogs: showLogs
    }
};

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';

function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    } else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}

loadScript('utils.js', utilsFolder);
//endregion
// Common utils
var startDate = new Date();
var endDate;

function getAggQuery(aggObject) {
    var query = [];
    if (queryLimit > 0) {
        query.push({$limit: queryLimit});
    }
    if (skip > 0) {
        query.push({$skip: skip});
    }
    query.push({
        $group: {
            _id: aggObject,
            count: {$sum: 1},
            docs: {$push: documentKeys}
        }
    });
    query.push({
        $match: {
            count: {$gt: 1}
        }
    });
    return query;
}

function printWidgetStats() {
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + version + ' © Sisense');

        endDate = new Date();
        var execTime = timeDiff(startDate, endDate);
        var total = 0;
        logger('Execution time ' + execTime.seconds + ' seconds ');
        if (typeof collectedStats !== 'undefined') {
            Object.keys(collectedStats).forEach(function (key) {
                var value = collectedStats[key];
                logger(' - ' + key + ': ' + value + ' items');
                total += value;
            });
        }
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + total);

        divider();
    }
}

printHeader();
printConfig(config);

// Global variables
var NUMBER_OF_DOCUMENTS_IN_BATCH = 50;

var limit = 10000;
var queryLimit = 200000;

var skip = 0;


var documentKeys = {
    title: '$title',
    oid: '$oid',
    instanceType: '$instanceType',
    dashboardid: '$dashboardid',
    userId: '$userId',
    owner: '$owner',
    created: '$created',
    _id: '$_id'
};
var widgetAgg = {
    oid: '$oid',
    userId: '$userId'
};
var aggregationOptions = {
    allowDiskUse: true
};
var bulk = prismWebDB.getCollection('widgets').initializeUnorderedBulkOp();

// Functions
function checkAggCases(agg) {
    if (agg.length > 0) {
        logger('Widgets have multiple documents with same oid and different instanceType');
        logger(' ');
        agg.forEach(function (elem) {
            collectStats('widget_same_oid_for_different_instance_types', 1);
            var dashboards = [];
            var message = ' duplicated case: ' + secureOutput(elem.docs[0].title) +
                ' oid ' + elem.docs[0].oid +
                ' dashboardid ' + elem.docs[0].dashboardid +
                ' instanceType ' + elem.docs[0].instanceType +
                ' userId ' + elem.docs[0].userId +
                ' created ' + elem.docs[0].created +
                ' has ' + elem.docs.length +
                ' items';
            logger(message);
            elem.docs.forEach(function (doc) {
                var msg = '  - ';
                var shouldRemove = false;
                if ((parseObjectIdToString(doc['userId']) !==
                    parseObjectIdToString(doc['owner'])) && doc['instanceType'] === 'owner') {
                    shouldRemove = true;
                    msg += ' ! remove owner instance: ';
                    bulk.find({'_id': doc._id}).remove();
                }
                if ((parseObjectIdToString(doc['userId']) ===
                    parseObjectIdToString(doc['owner'])) && doc['instanceType'] !== 'owner') {
                    shouldRemove = true;
                    msg += ' ! remove not owner instance: ';
                    bulk.find({'_id': doc._id}).remove();
                }
                if ((parseObjectIdToString(doc['userId']) === null) && doc['instanceType'] !==
                    'proxy') {
                    shouldRemove = true;
                    msg += ' ! remove not proxy instance: ';
                    bulk.find({'_id': doc._id}).remove();
                }
                if(!shouldRemove) {
                    msg += ' !!! logically valid: ';
                    collectStats('widget_same_oid_for_valid_instance', 1);
                }
                Object.keys(documentKeys).forEach(function (key) {
                    if (key === 'title') {
                        msg += key + ': ' + secureOutput(doc[key]) + ' | ';
                    } else if (key === 'oid' || key === '_id' || key === 'dashboardid') {
                        msg += '';
                    } else {
                        msg += key + ': ' + doc[key] + ' | ';
                    }

                });
                var dash = parseObjectIdToString(doc.dashboardid);
                if (dashboards.indexOf(dash) === -1) {
                    dashboards.push(dash);
                }

                if (config.logging.showWidgetDuplicates) {
                    logger(msg);
                }
            });
            if (dashboards.length > 1) {
                logger('Dashboards: ' + JSON.stringify(dashboards));
                mappingStats('widget_same_oid_for_different_dashboards', dashboards.length);
            }
        });
        logger(' ');
    }
}

function validateUsersForWidgets(widgetUsers, type) {
    widgetUsers.forEach(function (user) {
        if (user._id !== null) {
            var users = prismWebDB.getCollection('users').count({_id: user._id});
            if (users === 0) {
                logger(type + ' ' + user._id + ' does not exist for ' + user.widgetCount +
                    '  widgets');
                mappingStats('widget_'+type+'_does_not_exist', user.widgetCount);
            } else {
                logger(type + ' ' + user._id + ' has ' + user.widgetCount + '  widgets');
            }
        }
    });
}

function validateUsers(item, invalid) {
    if (item.userId) {
        var users = prismWebDB.getCollection('users').count({_id: item.userId});
    }
    if (item.owner) {
        var owners = prismWebDB.getCollection('users').count({_id: item.owner});
    }
    if (users === 0) {
        if (doCleanup) {
            invalid = true;
        }
    }

    if (owners === 0) {
        //logger('owner ' + item.userId + ' does not exist for widget ' + item._id);
        if (doCleanup) {
            invalid = true;
        }
    }
    return {
        users: users,
        owners: owners,
        invalid: invalid
    };
}

function validateWidget(item) {
    var invalid = false;
    var userInfo = validateUsers(item, invalid);
    var filterObj = {oid: item.dashboardid, userId: item.userId};
    if (item.instanceType !== 'proxy' && userInfo.users === 0) {
        collectStats('widget_no_user_for_widget', 1);
        //logger('user ' + item.userId + ' does not exist for widget ' + item._id);
        if (doCleanup) {
            invalid = true;
        }
    } else if (item.instanceType !== 'proxy' && (item.dashboardid && item.userId)) {

        var dashboards = prismWebDB.getCollection('dashboards')
            .count(filterObj);
        if (dashboards === 0) {
            collectStats('widget_no_dashboard_for_widget', 1);
            logger(' dashboard ' + item.dashboardid + ' does not exist for widget ' + item._id);
            var dashboardsAll = prismWebDB.getCollection('dashboards')
                .count({oid: item.dashboardid});
            if (dashboardsAll === 0) {
                collectStats('widget_no_dashboard_by_oid_for_widget', 1);
                logger('  - dashboard ' + item.dashboardid + ' does not exist for any user ');
            }
            if (doCleanup) {
                invalid = true;
            }
        }

    }

    if(!((typeof item.dashboardid != 'undefined') || (typeof item.userId != 'undefined'))){
        logger('widgets - find dash filter: '+ JSON.stringify(filterObj));
        mappingStats('dashboard_search_missing_filter_prop', 1);
    }

    if (invalid) {
        bulk.find({'_id': item._id}).remove();
    }
    return invalid;
}

function validateWidgets(widgetAggResult) {
    checkAggCases(widgetAggResult);
    //logger(JSON.stringify(widgetAggResult, null, 2))
    var index = 0;
    prismWebDB.getCollection('widgets')
        .find({})
        .batchSize(NUMBER_OF_DOCUMENTS_IN_BATCH)
        .forEach(function (widget) {
            var startTime = new Date();
            index += 1;
            var result = validateWidget(widget);
            var endTime = new Date();
            var execTime = timeDiff(startTime, endTime);
            var growthPercent = getPercent(index, wCount);
            if (result) {
                logger(
                    growthPercent + '% ' + index + '/' + wCount + ' ' + ' Widget (_id): ' +
                    widget._id +
                    ' Execution time ' + execTime.seconds + ' seconds');
            }
        });

    if (config.cleanup.doCleanup) {
        logger('Bulk widgets delete execute');
        var bulkResult = bulk.execute();
        logger(bulkResult);
    }
    logger('Validating all widgets has ended.');
}

// Main script
var widgetAggQuery = getAggQuery(widgetAgg);
var resultsGlobal = prismWebDB.getCollection('widgets')
    .aggregate(widgetAggQuery, aggregationOptions)
    .toArray();
var wCount = prismWebDB.widgets.count();
var widgetUsersAgg = prismWebDB.getCollection('widgets').aggregate([
    {$group: {'_id': '$userId', widgetCount: {$sum: 1}}}
]);
var widgetOwnersAgg = prismWebDB.getCollection('widgets').aggregate([
    {$group: {'_id': '$owner', widgetCount: {$sum: 1}}}
]);
logger('Validating all ' + wCount + ' widgets ');
logger('Aggregated widgets by oid & userId where count > 1: ' + resultsGlobal.length);

logger(' ');
validateUsersForWidgets(widgetUsersAgg, 'user');
logger(' ');
validateUsersForWidgets(widgetOwnersAgg, 'owner');
logger(' ');
validateWidgets(resultsGlobal);
logger(' ');
printWidgetStats();
logger('Script has finished execution successfully ' + ' © Sisense');
