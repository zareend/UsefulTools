﻿/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Widget duplicates cleaner';

// Configuration
var showLogs = true;
var doCleanup = true;
var startDate = new Date();
var deleteUserInstances = doCleanup;
var showExtendedInfo = false;
var useUserAndProxy = false;
var showParentInfo = false;

var limit = 10000;
var queryLimit = 2000000;
var widgetLimit = 0;
var skip = 0;
var useChunks = false;
var chunkSize = 20000;
var documentKeys = {
    title: '$title',
    oid: '$oid',
    userId: '$userId',
    instanceType: '$instanceType',
    lastUpdated: '$lastUpdated',
    _id: '$_id'
};
var dashAgg = {
    oid: '$oid',
    userId: '$userId',
    instanceType: '$instanceType'
};
var widgetAgg = {
    oid: '$oid',
    userId: '$userId',
    instanceType: '$instanceType',
    dashboardid: '$dashboardid'
};
var aggregationOptions = {
    allowDiskUse: true
};

var config = {
    cleanup: {
        doCleanup: doCleanup,
        deleteUserInstances: deleteUserInstances
    },
    logging: {
        showLogs: showLogs,
        showExtendedInfo: showExtendedInfo,
        useUserAndProxy: useUserAndProxy,
        showParentInfo: showParentInfo
    },
    limits: {
        useChunks: useChunks,
        chunkSize: chunkSize,
        limit: limit,
        queryLimit: queryLimit,
        widgetLimit: widgetLimit,
        skip: skip
    },
    aggregations: {
        dashAgg: dashAgg,
        widgetAgg: widgetAgg,
        documentKeys: documentKeys,
        aggregationOptions: aggregationOptions
    }
};

// Common utils
var scriptsFolder = '../utils';

function loadScript(script) {
    if (scriptsFolder) {
        var path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}

loadScript('utils.js');

// Base functions
function printHeader() {
    var logsStatus = getStatus(showLogs);
    var cleanupStatus = getStatus(doCleanup);
    divider();
    logger(scriptName + ' ' + version + ' © Sisense | widget cleanup ' + cleanupStatus +
        ' | user instance widget cleanup ' + getStatus(deleteUserInstances) + ' | logs ' +
        logsStatus);
    logger(new Date());
    divider();
}

function printDuplicatesStats() {
    if (typeof globalRun == 'undefined') {
        logger(' ');
        divider();
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Top copied widget count: ' + topCopies);
        printWidgetInfo(topCopiedWidget);
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ');
        logger(JSON.stringify(collectedStats, undefined, 2));
        var endDate = new Date();
        var execTime = timeDiff(startDate, endDate);
        logger('Execution time ' + execTime.seconds + ' seconds ');
        divider();
    }
}

printHeader();
printConfig(config);

// Global variables
var widgetsTotal = prismWebDB.getCollection('widgets').count();
var owners = {};
var topCopies = 0;
var topCopiedWidget = {};
var deleteIdsArr = [];
var dashboardsDuplicates;

// Main script
function printDashInfo(result, step, total) {
    var growthPercent = getPercent(step, total);
    timestamp(growthPercent + '% ' + step + '/' + total + ' ' + 'Dashboard info: ' + secureOutput(result.docs[0].title) + ' | ' + result._id.oid + ' | ' +
        result._id.instanceType + ' | ' + result._id.userId + ' | ' + result.docs.length);
    if (showExtendedInfo) {
        result.docs.forEach(function (item) {
            var msg = '  Dashboard: ';
            Object.keys(item).forEach(function (key) {

                var value = item[key];

                msg += value + ' | ';
            });

            logger(msg);
        });

    }
}

function printWidgetInfo(result, step, total) {
    var growthPercent = getPercent(step, total);
    timestamp(growthPercent + '% ' + step + '/' + total + ' ' + 'Widget info: ' + secureOutput(result.docs[0].title) + ' | ' + result._id.oid + ' | ' +
        result._id.instanceType + ' | ' + result._id.userId + ' | ' + result.docs.length);

    if (showExtendedInfo) {
        result.docs.forEach(function (item) {
            var msg = '  Widget: ';
            Object.keys(item).forEach(function (key) {

                var value = item[key];

                msg += value + ' | ';
            });

            logger(msg);
        });

    }
    if (result.docs.length > topCopies) {
        topCopies = result.docs.length;
        topCopiedWidget = result;
        logger(' new top copied widget: ' + result.docs.length);
    }
}

function printWidgetsInfo(results) {
    var action = doCleanup ? 'start cleaning' : 'set "doCleanup = true;" to start cleaning';

    var duplicatesTotal = 0;

    for (var k = 0, l = results.length; k < l; k++) {
        var result = results[k];
        duplicatesTotal += result.docs.length;
    }
    var duplicatesPercentage;
    if (queryLimit !== 0){
        duplicatesPercentage = getPercent(duplicatesTotal, queryLimit);
    }
    else {
        duplicatesPercentage = getPercent(duplicatesTotal, widgetsTotal);
    }

    dividerHeader('Duplicated widgets');
    //logger('Found ' + dashboardsDuplicates.length + ' duplicated dashboard instances');
    logger('Found ' + results.length + ' duplication widget cases and ' + duplicatesTotal +
        ' duplicated widget instances');
    logger('Total widgets ' + widgetsTotal + ' duplication: ' + duplicatesPercentage + ' %');
    collectStats('widget_duplicates_cases', results.length);
    collectStats('widget_duplicates_items', duplicatesTotal);
    if (duplicatesPercentage > 0 || dashboardsDuplicates.length > 0) {
        logger(action);
    }

}
function printDashboardsInfo(results) {
    var action = doCleanup ? 'Start cleaning' : 'set "doCleanup = true;" to start cleaning';

    var duplicatesTotal = 0;
    var dashboardsTotal = prismWebDB.getCollection('dashboards').count();

    for (var k = 0, l = results.length; k < l; k++) {
        var dash = results[k];
        duplicatesTotal += dash.docs.length;
    }

    var duplicatesPercentage = getPercent(duplicatesTotal, dashboardsTotal);
    logger('   ');
    dividerHeader('Duplicated dashboards');
    logger('Found ' + results.length + ' duplication dashboard cases and ' + duplicatesTotal +
        ' duplicated dashboard instances');
    collectStats('dashboard_duplicates_cases', results.length);
    collectStats('dashboard_duplicates_items', duplicatesTotal);
    logger('Total dashboards ' + dashboardsTotal + ' duplication: ' + duplicatesPercentage + ' %');
    if (duplicatesPercentage > 0 || results.length > 0) {
        logger(action);
    }

}

function printActions(ownersObj) {
    dividerHeader('ACTIONS');
    logger(
        'to normalize these dashboards we remove all the junk widgets, most recently updated is kept, all others should be removed');
    logger('Top copied widget count: ' + topCopies);
    printWidgetInfo(topCopiedWidget);
    logger('to delete widgets set flag doCleanup = true');
    logger('After running this script for cleaning');
    logger('You may ask these users to republish their dashboards:');

    Object.keys(ownersObj).forEach(function (item) {

        var userObj = ownersObj[item];

        logger(userObj.name + ' may republish dashboards:');
        if (userObj.dashboards) {
            Object.keys(userObj.dashboards).forEach(function (key) {
                item = userObj.dashboards[key];
                logger(item.dashboardtitle + ' with oid ' + item.dashboardId);
            });
        }

        dividerSmall()
    });
    dividerFooter('ACTIONS');
}

function getAggQuery(aggObject) {
    var query = [];
    if (queryLimit > 0) {
        query.push({ $limit: queryLimit });
    }
    if (skip > 0) {
        query.push({ $skip: skip });
    }
    query.push({
        $group: {
            _id: aggObject,
            count: { $sum: 1 },
            docs: { $push: documentKeys }
        }
    });
    query.push({
        $match: {
            count: { $gt: 1 }
        }
    });
    return query;
}

function getWidgetInfo(id, sourceSearch) {
    var text;
    if (showParentInfo) {
        var searchId = parseStringToObjectId(id);
        var result = prismWebDB.getCollection('widgets').find({
            _id: searchId
        }).toArray();
        prismWebDB.getCollection('widgets').find({
            _id: searchId
        }).forEach(function (widget) {
            text = 'widget info';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('********************* ' + text + ' ********************************');
            logger(secureOutput(widget.title) + ' | ' + widget.oid + ' | ' + widget._id + ' | ' + widget.source +
                ' | ' + widget.created + ' | ' + widget.dashboardid + ' | ' + widget.owner + ' | ' +
                widget.instanceType + ' | ' + widget.userId + ' | ' + widget.lastUpdated + ' | ' +
                widget.lastUsed);
            //getDashboardInfo(widget.dashboardid)
            if (widget.source) {
                getWidgetInfo(widget.source, true);
            }
            logger('******************************************************************');
        });

        if (result.length === 0) {
            text = 'widget not found';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('************************* ' + text + ' *******************************');
        }
    }
}

function getDashboardInfo(id, sourceSearch) {
    var text;
    if (showParentInfo) {
        logger('Sourced from:');
        var searchId = parseStringToObjectId(id);
        var searchObj = {
            instanceType: 'owner'
        };
        if (sourceSearch) {
            searchObj['_id'] = searchId;
        } else {
            searchObj['oid'] = searchId;
        }
        var result = prismWebDB.getCollection('dashboards').find(searchObj).toArray();

        prismWebDB.getCollection('dashboards').find(searchObj).forEach(function (dash) {
            text = 'Dashboard info';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('********************* ' + text + ' ********************************');
            logger('Dashboard: ' + dash._id + ' | ' + secureOutput(dash.title) + ' | ' + dash.oid + ' | ' +
                dash.instanceType + ' | ' + dash.owner + ' | ' + dash.source + ' | ' +
                dash.lastUpdated);
            if (dash.source) {
                getDashboardInfo(dash.source, true);
            }
            logger('*********************************************************************');
        });

        if (result.length === 0) {
            text = 'dashboard not found';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('************************* ' + text + '*******************************');
        }
    }
}

function applyResult(result, dashboardCount, isOwner) {
    if (dashboardCount > 0 && isOwner) {

        // logger('You have multiple owner widgets with the same oid:');
        // logger(
        //     ' title |  oid  |  _id  | source  | instanceType | owner | user | dashboardid |  lastUpdated  | created  | lastUsed ');
        var widgetsArr = prismWebDB.getCollection('widgets').find({
            oid: result._id.oid,
            userId: result._id.userId,
            instanceType: result._id.instanceType
        }).limit(widgetLimit).sort({ lastUpdated: -1 }).toArray();
        var widgetCollection = prismWebDB.getCollection('widgets').find({
            oid: result._id.oid,
            userId: result._id.userId,
            instanceType: result._id.instanceType
        }).limit(widgetLimit).sort({ lastUpdated: -1 }).toArray();
        //printWidgetInfo(result, step, total);
        widgetCollection.forEach(function (widget, index) {
            //dividerHeader('Widget');
            var msg = secureOutput(widget.title)
                + ' | ' + index
                + ' | ' + widget.oid
                + ' | ' + widget._id
                + ' | ' + widget.source
                + ' | ' + widget.created
                + ' | ' + widget.dashboardid
                + ' | ' + widget.owner
                + ' | ' + widget.instanceType
                + ' | ' + widget.userId
                + ' | ' + widget.lastUpdated
                + ' | ' + widget.lastUsed;
            logger(msg);
            if (widget.source) {
                getWidgetInfo(widget.source, true);
            }
            //dividerFooter('Widget');
        });

        if (doCleanup) {
            for (var ii = 1; ii < widgetsArr.length; ii++) {
                var widgetToRemove = widgetsArr[ii];

                //var res = prismWebDB.widgets.deleteOne({"_id": widgetToRemove._id});
                bulk.find({ '_id': widgetToRemove._id }).remove();
                //logger(secureOutput(widgetToRemove.title) + ' deleted: ' + res.deletedCount);
                deleteIdsArr.push(widgetToRemove._id);
            }
            //dividerSmall()
            logger('Removed widgets: ' + deleteIdsArr.length);
        }

    } else if (dashboardCount === 0) {
        logger('no related dashboard found, you need to delete ' + result.docs.length +
            ' redundant widgets');
        for (var k = 0, l = result.docs.length; k < l; k++) {
            var res = result.docs[k];
            logger(JSON.stringify(res));
            prismWebDB.getCollection('widgets')
                .find({ _id: res })
                .limit(widgetLimit)
                .sort({ lastUpdated: -1 })
                .toArray()
                .forEach(function (widget) {
                    logger(secureOutput(widget.title) + ' | ' + widget.oid + //' | ' + widget._id.getTimestamp().getTime() +
                        ' | ' + widget._id + ' | ' + widget.instanceType + ' | ' +
                        widget.lastUpdated + ' | ' + widget.created + ' | ' + widget.lastUsed);
                    var deleteResult = prismWebDB.widgets.deleteOne({ '_id': widget._id });
                    logger(secureOutput(widget.title) + ' deleted: ' + deleteResult.deletedCount);
                });

        }
        divider()
    }
}

function fixInstance(result, bulk, step, total) {
    var data = {};
    var isOwner = result._id.instanceType === 'owner';
    var widgetCollection;
    if (result._id.instanceType === 'owner') {
        var owner = {};
        printWidgetInfo(result, step, total);
        prismWebDB.getCollection('users').find({ _id: result._id.userId }).forEach(function (user) {
            //logger('User: ' + user.userName + ' | ' + user._id);
            Object.keys(owners).forEach(function (item) {
                var userObj = owners[item];
                if (user.userName) {
                    if (userObj.name === user.userName) {
                        owner = owners[user.userName];
                    }
                }
            });

            data.user = user.userName;
            owner.name = user.userName;
            prismWebDB.getCollection('dashboards').find({
                oid: result._id.dashboardid,
                instanceType: result._id.instanceType
            }).forEach(function (dash) {
                var dashboard = {};
                logger('Dashboard: ' + secureOutput(widget.title) + ' | ' + dash.oid + ' | ' + dash.instanceType +
                    ' | ' + dash.owner + ' | ' + dash.created + ' | ' + dash.lastUpdated + ' | ' +
                    dash.source);
                data.dashoid = dash.oid;
                data.dashboardtitle = dash.title;
                dashboard.dashboardId = dash.oid;
                dashboard.dashboardtitle = dash.title;

                if (!owner.dashboards) {
                    owner.dashboards = {};
                }
                if (!owner.dashboards[dashboard.dashboardId.valueOf()]) {
                    owner.dashboards[dashboard.dashboardId.valueOf()] = dashboard;
                }

                if (dash.source !== 'undefined') {
                    getDashboardInfo(dash.source, true);
                }
            });

            owners[owner.name] = owner;
        });
        var dashboardCount = prismWebDB.getCollection('dashboards').count({
            oid: result._id.dashboardid,
            instanceType: result._id.instanceType
        });
    } else if (result._id.instanceType === 'proxy') {
        if (useUserAndProxy) {
            logger('Result is ' + result._id.instanceType +
                ' instance. Fixing owner instances solves it.');
        }
        widgetCollection = prismWebDB.getCollection('widgets').find({
            oid: result._id.oid,
            userId: result._id.userId,
            instanceType: result._id.instanceType
        }).limit(widgetLimit).sort({ lastUpdated: -1 }).toArray();
        printWidgetInfo(result, step, total);
        widgetCollection.forEach(function (widget, index) {
            if (useUserAndProxy) {
                logger(
                    secureOutput(widget.title) + ' | ' + index + ' | ' + widget.oid + ' | ' + widget._id + ' | ' +
                    widget.source + ' | ' + widget.instanceType + ' | ' + widget.owner + ' | ' +
                    widget.userId + ' | ' + widget.dashboardid + ' | ' + widget.lastUpdated +
                    ' | ' + widget.created + ' | ' + widget.lastUsed);
            }
            getWidgetInfo(widget.source, true);
            if (deleteUserInstances && index > 0) {
                //var res = prismWebDB.widgets.deleteOne({"_id": widget._id});
                //logger(secureOutput(widget.title) + ' added to bulk delete ');
                bulk.find({ '_id': widget._id }).remove();
                //logger(secureOutput(widget.title) + ' deleted: ' );//+ res.deletedCount
            }
        });
        //logger(widgetCollection.length + ' widgets processed ' );
        //logger('******************************************************************');
    } else if (result._id.instanceType === 'user') {

        if (useUserAndProxy) {
            logger('Result is ' + result._id.instanceType +
                ' instance. Fixing owner instances solves it.');
        }
        ////sleep(waitTime);
        widgetCollection = prismWebDB.getCollection('widgets').find({
            oid: result._id.oid,
            userId: result._id.userId,
            instanceType: result._id.instanceType
        }).limit(widgetLimit).toArray();
        printWidgetInfo(result, step, total);
        widgetCollection.forEach(function (widget, index) {
            if (useUserAndProxy) {
                logger(
                    secureOutput(widget.title) + ' | ' + index + ' | ' + widget.oid + ' | ' + widget._id + ' | ' +
                    widget.source + ' | ' + widget.instanceType + ' | ' + widget.owner + ' | ' +
                    widget.userId + ' | ' + widget.dashboardid + ' | ' + widget.lastUpdated +
                    ' | ' + widget.created + ' | ' + widget.lastUsed);
            }
            getWidgetInfo(widget.source, true);
            if (deleteUserInstances && index > 0) {
                //var res = prismWebDB.widgets.deleteOne({"_id": widget._id});
                //logger(secureOutput(widget.title) + ' added to bulk delete ');
                bulk.find({ '_id': widget._id }).remove();
                //logger(secureOutput(widget.title) + ' deleted: ' );//+ res.deletedCount
            }
        });
        //logger(widgetCollection.length + ' widgets processed ' );
        //logger('******************************************************************');

    }

    applyResult(result, dashboardCount, isOwner)
}

function fixDashboardInstance(result, bulk, step, total) {
    //dividerSmall()
    printDashInfo(result, step, total);
    var oid = result._id.oid ? result._id.oid : null;
    var userId = result._id.userId ? result._id.userId : null;
    var instanceType = result._id.instanceType ? result._id.instanceType : null;
    var dashboardCollection = prismWebDB.getCollection('dashboards').find({
        oid: oid,
        userId: userId,
        instanceType: instanceType
    }).limit(limit).sort({ lastUpdated: -1 }).toArray();

    dashboardCollection.forEach(function (dash, index) {
        var msg = 'Dashboard info: ' +
            secureOutput(dash.title) + ' | '
            //+ index + ' | '
            + dash.oid + ' | '
            + dash.userId + ' | '
            + dash.owner + ' | '
            + dash.source + ' | '
            + dash.instanceType + ' | '
            + dash._id + ' | '
            + dash.lastUpdated + ' | '
            + dash.created + ' | '
            + dash.lastUsed;
        logger(msg);

        if (doCleanup && index > 0) {
            //var res = prismWebDB.widgets.deleteOne({"_id": dash._id});
            //logger(secureOutput(widget.title) + ' added to bulk delete ');
            bulk.find({ '_id': dash._id }).remove();
            //logger(secureOutput(widget.title) + ' deleted: ' );//+ res.deletedCount
        }
    });
}
function cleanDashboards(dashboards) {
    var bulk = prismWebDB.getCollection('dashboards').initializeUnorderedBulkOp();
    dividerHeader('RESULTS');
    for (var i = 0, l = dashboards.length; i < l; i++) {
        var result = dashboards[i];

        if (result) {
            //sleep(waitTime);
            fixDashboardInstance(result, bulk, i, l);
        }
    }
    if (doCleanup) {
        logger('Bulk dashboards delete execute');
        var bulkResult = bulk.execute();
        logger(bulkResult);
    }
    dividerHeader('Finished dashboards processing');
    logger('   ');
}

function cleanWidgets(results) {
    var bulk = prismWebDB.getCollection('widgets').initializeUnorderedBulkOp();

    var reRun = false;
    if (!results) {
        logger('Updating results');
        results = prismWebDB.getCollection('widgets')
            .aggregate(widgetAggQuery, aggregationOptions)
            .toArray();

        printWidgetsInfo(results);
    }

    if (results.length > 0) {
        logger('Results total: ' + results.length);
        if (useChunks && results.length > chunkSize) {
            logger('Results is more than chunk size: ' + chunkSize + ', splitting operations');
            results = results.slice(0, chunkSize);
            reRun = true;
        }
        dividerHeader('RESULTS');
        for (var i = 0, l = results.length; i < l; i++) {
            var result = results[i];

            if (result) {
                //sleep(waitTime);
                fixInstance(result, bulk, i, l);
            }
        }

        if (doCleanup || deleteUserInstances) {
            logger('Bulk delete execute');
            var bulkResult = bulk.execute();
            logger(bulkResult);
            if (reRun) {
                logger('Starting new iteration');
                //sleep(waitTime);
                cleanWidgets();
            } else {
                printActions(owners);
            }
        }
    } else {
        logger('Your mongo is free from widget duplicates');
        divider();
    }

}

prismWebDB.getCollection('dashboards').createIndexes([{ 'lastUpdated': 1 }]);
prismWebDB.getCollection('widgets').createIndexes([{ 'lastUpdated': 1 }]);
var dashAggQuery = getAggQuery(dashAgg);
var widgetAggQuery = getAggQuery(widgetAgg);
timestamp('Start dashboards aggregation');
dashboardsDuplicates = prismWebDB.getCollection('dashboards')
    .aggregate(dashAggQuery, aggregationOptions)
    .toArray();
timestamp('Done dashboards aggregation');
timestamp('Start widgets aggregation');
var resultsGlobal = prismWebDB.getCollection('widgets')
    .aggregate(widgetAggQuery, aggregationOptions)
    .toArray();
timestamp('Done widgets aggregation');
logger('Aggregated dashboards ' + dashboardsDuplicates.length);
logger('Limit widget agg ' + queryLimit);
logger('Total widgets ' + widgetsTotal);
logger('Aggregated widgets ' + resultsGlobal.length);

printDashboardsInfo(dashboardsDuplicates);
printWidgetsInfo(resultsGlobal);

cleanDashboards(dashboardsDuplicates);
cleanWidgets(resultsGlobal);

printDuplicatesStats();
