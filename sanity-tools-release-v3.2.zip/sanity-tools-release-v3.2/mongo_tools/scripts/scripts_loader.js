/**
 * Created by yaroslav.korzh
 * Updated 16/12/2019
 */
//region General Info
var version = '3.1.3';
var scriptName = 'Scripts loader';
//endregion

//region Configuration
var showLogs = true;
var doCleanup = false;
var globalCleanup;
if (typeof cleanup !== 'undefined') {
    doCleanup = cleanup;
    globalCleanup = doCleanup;
}
var scriptsList = [
    'mongo_stats.js',
    'groups_analyzer.js',
    'widget_duplicates_cleaner.js',
    'cube_shares_duplicates.js',
    'revisions_cleaner.js',
    'connections_cleaner.js',
    'user_groups.js',
    'cube_unused_cubes_cleaner.js',
    'datasecurity_validate.js',
    'user_validate.js',
    'jobs_validate.js',
    'widget_validate.js',
    'dashboard_validate.js',
    'mongo_normalize.js',
    'mongo_stats.js'
];
var globalRun = true;
var collectedStats = {};
var mappedStats = {};
var timeStats = {};
var startDate = new Date();
var endDate;
var showDBStats = true;
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');
//endregion

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

//region Global variables
var logsStatus = getStatus(showLogs);
var cleanupStatus = getStatus(doCleanup);
//endregion

//region Functions
function preRun() {
    prismWebDB.adminCommand(
        { 'setParameter': 1, 'internalQueryExecMaxBlockingSortBytes': 134217728 });
}

function postRun() {
    prismWebDB.adminCommand(
        { 'setParameter': 1, 'internalQueryExecMaxBlockingSortBytes': 33554432 });
}

function printHeader() {
    divider();
    logger(scriptName + ' ' + version + ' © Sisense ');
    logger('Total scripts to apply: ' + scriptsList.length + ' ');
    logger('Cleanup ' + cleanupStatus + ' | Logs ' + logsStatus);
    logger(' ');
    logger(startDate);
}

function postProcessExecution() {
    divider();
    logger('Post-processing script changes');
    logger(' ');
}

function printSummary() {
    logger('   ');
    divider();
    logger('Scripts statistics ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    endDate = new Date();
    var execTime = timeDiff(startDate, endDate);
    var total = 0;
    var mappedTotal = 0;

    Object.keys(collectedStats).sort().forEach(function (key) {
        var value = collectedStats[key];
        if (value > 0) {
            logger(' - ' + key + ': ' + value + ' items');
        }
        total += value;
    });
    if (total > 0) {
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + total);
    }
    logger(' ');
    logger('Mapped statistics:');
    if(mappedStats){
        Object.keys(mappedStats).sort().forEach(function (key) {
            var value = mappedStats[key];
            if (value > 0) {
                logger(' - ' + key + ': ' + value + ' items');
            }
            mappedTotal += value;
        });
    }
    if (mappedTotal > 0) {
        logger('Potential glitches mapped: ' + mappedTotal);
    }
    logger(' ');
    logger('Execution time ' + execTime.text + ' total in: ');
    Object.keys(timeStats).sort().forEach(function (key) {
        var value = timeStats[key];
        logger(' - ' + key + ': ' + value + ' seconds');
    });
    divider();
}

function loadScripts() {
    scriptsList.forEach(function (script, index) {
        divider();
        var startTime = new Date();
        logger('Starting script  ' + index + ': ' + script + ' from ' + scriptsList.length +
            ' © Sisense');
        if (scriptsFolder) {
            var path = scriptsFolder + '/' + script;
            load(path);
        } else {
            load(script);
        }
        var endTime = new Date();
        var scriptTime = timeDiff(startTime, endTime);
        timeStats[script] = scriptTime.seconds;
        logger('Execution time of the script  ' + index + ': ' + script + ' from ' +
            scriptsList.length + ' © Sisense: ' + scriptTime.text + '  ');
        divider();
        //sleep(timeout);
    });
}

function completed() {
    logger('Scripts have finished execution successfully ' + ' © Sisense');
}
//endregion

//region Main script
printHeader();
preRun();
loadScripts();
postProcessExecution();
postRun();
printSummary();
completed();
//endregion
