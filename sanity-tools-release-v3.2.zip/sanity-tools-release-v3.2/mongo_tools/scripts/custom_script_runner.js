/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Custom Script Runner';

// Configuration
var showLogs = true;
var doCleanup = false;
var globalCleanup;
if (typeof cleanup !== 'undefined') {
    doCleanup = cleanup;
    globalCleanup = doCleanup;
}

var globalRun = true;
var collectedStats = {};

var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

var logsStatus = getStatus(showLogs);
var cleanupStatus = getStatus(doCleanup);

function printHeader() {
    divider();
    logger(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    divider();
    increaseSort();
}
function printSummary() {
    decreaseSort();
    logger('   ');
    divider();
    logger('Scripts statistics ' + ' © Sisense');
}

printHeader();
// var mainScriptsPath = '../mongo_tools/scripts/';
var miscScriptsPath = '../misc/scripts/';
// put here path to script you want to run
// load(mainScriptsPath + 'analyze_dim.js');
load(miscScriptsPath + 'domain_migration.js');
// load('../misc/domain_migration.js');
// load('../misc/test_size.js');

divider();

printSummary();
logger('Script has finished execution successfully ' + ' © Sisense');
