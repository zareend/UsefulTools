/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Mongo normalizer';

// Configuration
var showLogs = true;

var doCleanup = false;
var showDBInfo = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}
if (typeof showDBStats !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    showDBInfo = showDBStats;
}
// Global variables
var dbKeys = ['ns', 'size', 'count', 'avgObjSize', 'storageSize', 'nindexes', 'indexSizes'];
var dbKeysScaled = ['size', 'dataSize', 'storageSize', 'indexSize', 'indexSizes'];
var dbKeysNotScaled = ['ns', 'count', 'avgObjSize', 'nindexes'];
var scaleBytes = 1000000;
var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    db:{
        scaleBytes: scaleBytes,
        dbKeys: dbKeys,
        dbKeysScaled: dbKeysScaled,
        dbKeysNotScaled: dbKeysNotScaled
    },
    logging: {
        showLogs: showLogs,
        showCollStats: false,
        showDBStats: showDBInfo
    }
};

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

printHeader();
printConfig(config);

// Functions
function checkCollection(db, collection, statsArray) {
    var collectionTotal = db.getCollection(collection).count();
    logger(' ' + collection + ' : ' + collectionTotal + ' items');
    var stats = db.getCollection(collection).stats();
    var obj = {};

    obj.Name = collection;
    obj.TotalSizeInMB = stats.size / 1000000;
    obj.NumberOfDocuments = stats.count;
    obj.StorageSizeInMB = stats.storageSize / 1000000;
    obj.totalIndexSizeInMB = stats.totalIndexSize / 1000000;
    obj.currentCacheInMB = stats.wiredTiger.cache['bytes currently in the cache'] / 1000000;
    obj.fileSizeInMB = stats.wiredTiger['block-manager']['file size in bytes'] / 1000000;

    statsArray.push(obj);
}

function printCollectionsInfo() {
    logger('  ');
    logger('prismWebDB collections items count: ');
    collectionsDB.forEach(function (collection) {
        checkCollection(prismWebDB, collection, statsArrDB);
    });
    logger('  ');
    logger('prismConfig collections items count: ');
    collectionsConfig.forEach(function (collection) {
        checkCollection(prismConfig, collection, statsArrConfig);
    });
    logger('  ');
    logger('monitor collections items count: ');
    collectionsMonitor.forEach(function (collection) {
        checkCollection(prismMonitor, collection, statsArrMonitor);
    });
}

function dbStats(db, target) {
    logger('MongoDB stats for ' + target + ': ');
    logger(JSON.stringify(db.stats(scaleBytes), undefined, 2));
    logger('   ');
}

function normalizeDB(db, target) {
    logger('  ');
    logger('Normalize ' + target + ': ');
    var collection = db.getCollectionNames();
    if (config.cleanup.doCleanup) {
        if (config.logging.showDBStats) {
            var dbStatistics = db.stats(scaleBytes);
            logger(JSON.stringify(dbStatistics, undefined, 2));

        }
        logger(' ');
        logger('Free space from ' + target + 'MongoDB ');
        logger(' ');
        collection.forEach(function (result) {
            var r1 = db.runCommand({ collStats: result, scale: scaleBytes });
            if (config.logging.showDBStats) {
                //logger(' Before');
                dbKeys.forEach(function (key) {
                    var val = r1[key];
                    logger('  ' + key + ': ' + JSON.stringify(val));
                });
                logger('  ');
            }
            if (r1['count'] !== 0 && r1['size'] !== 0){
                db.runCommand({ compact: result });
                var r3 = db.runCommand({ collStats: result, scale: scaleBytes });
                if (config.logging.showDBStats) {
                    logger(' After compact');
                    dbKeys.forEach(function (key) {
                        var val = r3[key];
                        logger('  ' + key + ': ' + JSON.stringify(val));
                    });
                    logger('  ');
                }
            }
        });
        db.runCommand( { repairDatabase: 1 } );
    } else {
        if (config.logging.showDBStats) {

            collection.forEach(function (result) {
                var r1 = db.runCommand({ collStats: result, scale: scaleBytes });
                //logger(JSON.stringify(r1, undefined, 2));
                dbKeys.forEach(function (key) {
                    var val = r1[key];
                    var msg = '';
                    if (dbKeysScaled.indexOf(key) !== -1){
                        msg += '  ' + key + ': ' + JSON.stringify(val) + ' Mb'
                    }
                    else if (dbKeysNotScaled.indexOf(key) !== -1){
                        msg += '  ' + key + ': ' + JSON.stringify(val)
                    }
                    logger(msg);
                });
                logger('  ');

            });
        }
    }
}

// Main script
if(config.logging.showCollStats){
    printCollectionsInfo();
}
logger('Normalize mongo DB');
logger(JSON.stringify(dbKeysScaled) + ' in Mb');
logger(' ');
dbStats(prismWebDB, 'Prism Web DB');
dbStats(prismConfig, 'Prism Config');
dbStats(prismMonitor, 'Prism Monitor');

if (config.cleanup.doCleanup){
    normalizeDB(prismWebDB, 'Prism Web DB');
    normalizeDB(prismConfig, 'Prism Config');
    normalizeDB(prismMonitor, 'Prism Monitor');

    dbStats(prismWebDB, 'Prism Web DB');
    dbStats(prismConfig, 'Prism Config');
    dbStats(prismMonitor, 'Prism Monitor');
}



