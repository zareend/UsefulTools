/**
 * Created by yaroslav.korzh on 8/11/2017.
 * Updated 19/02/2019
 */

// TODO remove only user / group missing, not all rule. remove rule only if all shares broken / removed
var version = '3.1.3';
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var scriptName = 'Datasecurity validate';

var cleanupStatus = doCleanup ? 'enabled' : 'disabled';
var showLogs = true;
var logsStatus = showLogs ? 'enabled' : 'disabled';

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

var groupIDs = {};
var invalidRules = [];

function validateShares(rule) {
    var isValid = true;
    var validRuleShares = [];
    var invalidShares = 0;

    for (var item in rule.shares) {
        var share = rule.shares[item];
        if (share.type === 'group') {
            var groupCount = prismWebDB.getCollection('groups').count({ _id: share.partyId });
            if (groupCount === 0) {
                logger('Group ' + share.partyId + ' does not exist, rule id: ' + rule._id);
                collectStats('datasecurity_invalid_rule', 1);
                invalidRules.push(rule);
                invalidShares += 1;
            }
            else {
                validRuleShares.push(share);
            }
        }

        if (share.type === 'user') {
            if (share.partyId) {
                var userCount = prismWebDB.getCollection('users').count({ _id: share.partyId });
                if (userCount === 0) {
                    logger('User ' + share.partyId + ' does not exist, rule id: ' + rule._id);
                    collectStats('datasecurity_invalid_rule', 1);
                    invalidRules.push(rule);
                    invalidShares += 1;
                }
                else {
                    validRuleShares.push(share);
                }
            }
        }
        if (share.type === 'default') {
            validRuleShares.push(share);
        }
    }
    if (rule.shares && rule.shares.length === invalidShares) {
        isValid = false;
        logger(' ! No valid shares ');
    }

    if (config.cleanup.doCleanup) {
        logger('Keep shares: ' + validRuleShares.length);
        prismWebDB.getCollection('dataContext').update(
            { '_id': rule._id },
            { $set: { 'shares': validRuleShares } }
        );
    }

    return isValid;
}

prismWebDB.groups
    .find({})
    .forEach(function (group) {
        groupIDs[group._id] = true;
    });

function checkCubeSecurity(cube) {
    var cubeID = cube._id;

    prismWebDB.dataContext
        .find({ cubeId: cubeID })
        .forEach(function (rule) {
            checkRule(rule);
        });

    if (invalidRules.length > 0) {
        //logger(JSON.stringify(invalidRules, null, 2));
        logger('Invalid rules total: ' + invalidRules.length);
    }

}

var stats = {};

function checkRule(rule) {
    var isValid = true;
    var msg = ' ';
    msg += '_id: ' + rule._id + ' | ';
    //msg += 'server: ' + rule.server + ' | ';
    //msg += 'cube: ' + rule.cubeId + ' | ';
    msg += 'table: ' + rule.table + ' | ';
    msg += 'column: ' + rule.column + ' | ';
    msg += 'allMembers: ' + rule.allMembers + ' | ';
    msg += 'members: ' + JSON.stringify(rule.members) + ' | ';
    if (rule.shares) {
        msg += 'shares: ' + rule.shares.length + ' - ' + JSON.stringify(rule.shares) + ' | ';
    }

    if (!rule.table || !rule.column) {
        isValid = false;
        collectStats('datasecurity_missing_table_column', 1);
    }
    if (!rule.shares) {
        isValid = false;
        collectStats('datasecurity_missing_shares', 1);
    }
    if (!rule.members) {
        isValid = false;
        collectStats('datasecurity_missing_members', 1);
    }
    if (rule.shares && rule.shares.length === 0) {
        isValid = false;
        logger('Rule shares is empty: ' + rule._id);
        collectStats('datasecurity_empty_rule_shares', 1);
    }
    if (rule.members && rule.members.length === 0 && rule.allMembers === null) {
        isValid = false;
        logger('Rule members is empty: ' + rule._id);
        collectStats('datasecurity_empty_rule_members', 1);
    }

    //msg += rule.column + ' | ';
    logger(msg);
    if (!validateShares(rule)) {
        isValid = false;
        logger(' - ! Invalid rule ' + rule._id);
    }
    //logger(JSON.stringify(rule.shares, null, 2));
    //logger('******************************************************************');
    if (!isValid) {
        invalidRules.push(rule);
        collectStats('datasecurity_invalid_rule', 1);
    }
}

var cubesChecked = [];
logger('');
prismWebDB.getCollection('elasticubes').find({}).forEach(function (cube) {
    var msg = 'Cube: ';
    msg += '_id: ' + cube._id + ' | ';
    msg += cube.title + ' | ';
    msg += 'server: ' + cube.server + ' | ';

    var rulesCount = prismWebDB.getCollection('dataContext').find({ cubeId: cube._id }).count();
    msg += 'rules: ' + rulesCount + ' | ';
    cubesChecked.push(cube._id);
    logger(msg);
    checkCubeSecurity(cube);
    logger('******************************************************************');
});
logger(' ');
logger('! Rules on non-existing cubes: ');
prismWebDB.getCollection('dataContext')
    .find({ 'cubeId': { '$nin': cubesChecked } })
    .forEach(function (rule) {
        mappingStats('datasecurity_rule_on_non_existing_cube', 1);
        checkRule(rule);
    });
if (invalidRules.length > 0) {
    //logger(JSON.stringify(invalidRules, null, 2));
    logger('Invalid rules total: ' + invalidRules.length);
}
if (doCleanup) {
    for (var i in invalidRules) {
        var invalidRule = invalidRules[i];
        prismWebDB.dataContext.remove(invalidRule);
    }
}
printStats();
