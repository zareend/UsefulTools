﻿/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Cube shares duplicates';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var showShareDuplicates = false;

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs,
        showShareDuplicates: showShareDuplicates
    }
};
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

printHeader();
printConfig(config);

// Global variables
var maxDuplicates = 0;
var maxShares = 0;
var bulk = prismWebDB.getCollection('elasticubes').initializeUnorderedBulkOp();

// Functions
function validateUser(userId) {
    if (!userId) {
        return false;
    }
    var objectOid = parseStringToObjectId(userId);

    return prismWebDB.users.find({ _id: objectOid }).limit(1).hasNext();
}

function validateGroup(groupId) {
    if (!groupId) {
        return false;
    }
    var objectOid = parseStringToObjectId(groupId);

    return prismWebDB.groups.find({ _id: objectOid }).limit(1).hasNext();
}

function validateShare(share) {
    var result;
    if (share.type === 'group') {
        result = validateGroup(share.partyId);
    } else if (share.type === 'user') {
        result = validateUser(share.partyId);
    } else {
        // dashboard owner
        result = validateUser(share.partyId);
    }
    return result;
}

function checkCubesShares() {
    prismWebDB.getCollection('elasticubes').find({}).forEach(function (cube) {
        logger('cube ' + cube.title + ' shares: ' + cube.shares.length);
        if (cube.shares.length > maxShares) {
            maxShares = cube.shares.length;
        }
        var sharesObj = {};
        var sharesToKeep = [];
        if (cube.shares) {
            cube.shares.forEach(function (share) {
                //dividerHeader('Widget');
                //logger(share.partyId + ' | ' + index + ' | ' + share.type + ' | ' + share.permission );
                var validShare = validateShare(share);
                if (share.partyId) {
                    if (sharesObj[share.partyId]) {
                        sharesObj[share.partyId].count += 1;
                        sharesObj[share.partyId].agg.push(share);
                    } else {
                        sharesObj[share.partyId] = share;
                        sharesObj[share.partyId].count = 1;
                        sharesObj[share.partyId].agg = [];
                        sharesObj[share.partyId].agg.push(share);
                        if (validShare) {
                            sharesToKeep.push({
                                partyId: share.partyId,
                                type: share.type,
                                permission: share.permission
                            });
                        } else {
                            logger(' - Non-existing Share: ' + share.partyId + ' ' + share.type);
                            collectStats('cube_non_existing_share', 1);
                        }
                    }
                } else {
                    dividerHeader('Broken Share');
                    logger(JSON.stringify(share, null, 2));
                    dividerFooter('Broken Share');
                }
                //dividerFooter('Widget');
            });
            Object.keys(sharesObj).forEach(function (item) {

                var share = sharesObj[item];
                if (share.count > 1) {
                    if (share.count > maxDuplicates) {
                        maxDuplicates = share.count;
                    }
                    collectStats('cube_shares_duplicates', 1);
                    logger(' You have duplicates in shares collection for cube');
                    logger(' Duplicate: ' + item + ' | ' + share.type + ' | ' + share.permission +
                        ' - count: ' + share.count);
                    dividerSmall();
                    if (showShareDuplicates) {
                        share.agg.forEach(function (shareAgg, index) {
                            logger(shareAgg.partyId + ' | ' + index + ' | ' + shareAgg.type + ' | ' +
                                shareAgg.permission);
                        });
                    }

                }

            });
            if (cube.shares.length === sharesToKeep.length) {
                //logger('Shares normalized ');
            } else if (doCleanup) {
                logger('Keep shares: ' + sharesToKeep.length);
                prismWebDB.getCollection('elasticubes').update(
                    { '_id': cube._id },
                    { $set: { 'shares': sharesToKeep } }
                );
            }
        } else {
            logger('Cube ' + cube.title + ' has no shares');
        }
        divider();
    });

    if (maxDuplicates > 0) {
        logger('Max duplicates in shares ' + maxDuplicates + ' copies');
    } else {
        logger('No duplicates in collection');
    }

    logger('Max shares array ' + maxShares + ' items');
}

// Main script
checkCubesShares();
