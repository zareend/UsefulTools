/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Jobs validate';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion

printHeader();
printConfig(config);

// Global variables
var brokenJobs = 0;
var jobDashboards = [];
var bulk = prismWebDB.jobs.initializeUnorderedBulkOp();
// Functions
// *** Jobs Validation Functions ***
function validateSubscriptionJob(job) {
    var dashboardId, dashCount, widgetCount;
    var result = true;
    var dashReference = false;
    if (job.dashboardId) {
        dashReference = true;
        dashboardId = parseStringToObjectId(job.dashboardId);
        dashCount = prismWebDB.dashboards.count({ oid: dashboardId });
        widgetCount = prismWebDB.widgets.count({ dashboardid: dashboardId });
        // If there are no dashboards and no widgets (meaning that the dashboard was deleted)
        result = !(dashCount === 0 && widgetCount === 0);
    }
    else {
        logger('Job has no job.dashboardId ' + job._id);
        if (job.context) {
            job.dashboardId = job.context.dashboardid
        }
        if (config.cleanup.doCleanup) {
            var resJob = prismWebDB.jobs.update(
                { _id: job._id },
                job,
                { multi: true }
            );
            logger('Job dashboardId normalized: ' + JSON.stringify(resJob));
        }
    }

    if (job.context && job.context.dashboardid) {
        dashReference = true;
        dashboardId = parseStringToObjectId(job.context.dashboardid);
        dashCount = prismWebDB.dashboards.count({ oid: dashboardId });
        widgetCount = prismWebDB.widgets.count({ dashboardid: dashboardId });
        // If there are no dashboards and no widgets (meaning that the dashboard was deleted)
        result = !(dashCount === 0 && widgetCount === 0);
    }
    else {
        logger('Job has no job.context.dashboardid ' + job._id);
        if (job.dashboardId) {
            if (job.context) {
                job.context.dashboardid = job.dashboardId;
            }
            else {
                job.context = {};
                job.context.dashboardid = job.dashboardId;
            }
        }
        if (config.cleanup.doCleanup) {
            var res = prismWebDB.jobs.update(
                { _id: job._id },
                job,
                { multi: true }
            );
            logger('Job context.dashboardid normalized: ' + JSON.stringify(res));
        }
    }
    if (!dashReference) {
        mappingStats('job_no_dashboardid', 1);
    }

    if (!result) {
        logger('Job has no dashboard Id');
    }

    return result;
}

function validateSubscriptionActive(job) {
    var result = false;
    if (!job.active) {
        return result;
    }
    var dashboardidStr = job.dashboardId || job.context.dashboardid;
    var dashboardid = parseStringToObjectId(dashboardidStr);
    // var subsA = prismWebDB.getCollection('dashboards').find({ oid:  dashboardid, 'shares.subscribe': { $exists: true } }).toArray();
    // var subsB = prismWebDB.getCollection('dashboards').find({ oid:  dashboardid, 'subscription.active': { $exists: true } }).toArray();
    var subsA = prismWebDB.getCollection('dashboards')
        .find({ oid: dashboardid, 'shares.subscribe': { $exists: true } })
        .toArray();
    var subsB = prismWebDB.getCollection('dashboards')
        .find({ oid: dashboardid, 'subscription.active': { $exists: true } })
        .toArray();
    if (subsA.length === 0) {
        logger(' Dashboard (oid): ' + dashboardidStr + ' has invalid shares.subscribe');
    }
    else {
        //logger(' Dashboards: ' +subsA.length + ' oid: ' + dashboardidStr + ' subscriptions');
        subsA.forEach(function (dash) {
            //print(' Dashboard ' + dash._id);
            dash.shares.forEach(function (share) {
                //print('  share ' + JSON.stringify(share));
                //print('  subscribe: ' + share.subscribe);
                if (share.subscribe) {
                    result = true;
                }

            });
        });
    }


    if (subsB.length === 0) {
        logger(' Dashboard (oid): ' + dashboardidStr + ' has invalid subscription.active');
    }
    else {
        //logger(' Dashboards: ' +subsB.length + ' oid: ' + dashboardidStr + ' subscriptions');
        subsB.forEach(function (dash) {
            //print('  subscription ' + JSON.stringify(dash.subscription));
            if (dash.subscription.active) {
                result = true;
            }
        });
    }

    return result;
}

function validateJob(job) {
    var isValid = true,
        isJobToDelete = false;
    var info = 'Job (_id): ' + job._id + ' ' +
        ' active: ' + job.active +
        ' jobType: ' + job.jobType +
        ' created: ' + job.created +
        ' lastUpdated: ' + job.lastUpdated +
        ' lastUsed: ' + job.lastUsed +
        ' lastExecution: ' + job.lastExecution;
    if (job.active && job.jobType === 'dashboardSubscription') {
        logger(info);
    }

    if (!validateObjectId(job._id)) {
        isValid = false;
        mappingStats('job_invalid_id', 1);
        logger('Job (_id): ' + job._id + ' has invalid job id');
    }

    if (job.jobType === 'dashboardSubscription' && !validateSubscriptionJob(job)) {
        isJobToDelete = true;
        collectStats('job_on_invalid_dashboard', 1);
        logger('Job (_id): ' + job._id + ' is related to a dashboard which does not exist (oid): ' +
            job.dashboardId);
        //logger("db.getSiblingDB('prismWebDB').jobs.remove({_id: ObjectId('" + job._id + "')});");

        brokenJobs += 1;
        if (config.cleanup.doCleanup) {
            bulk.find({ _id: job._id }).remove();
        }
        //logger("db.dashboards.find({oid: ObjectId('" + job.dashboardId + "')})");
    }

    if (job.active && job.jobType === 'dashboardSubscription' && !validateSubscriptionActive(job)) {
        isJobToDelete = true;
        var dashboardidStr = job.dashboardId || job.context.dashboardid;
        collectStats('job_invalid_subscription', 1);
        logger('Job (_id): ' + job._id +
            ' is active, while dash subscription instance is not set or false: ' +
            dashboardidStr);
        //logger("db.getSiblingDB('prismWebDB').jobs.remove({_id: ObjectId('" + job._id + "')});");

        brokenJobs += 1;
        if (config.cleanup.doCleanup) {
            var res = prismWebDB.jobs.update(
                { _id: job._id },
                { $set: { 'active': false } },
                { multi: true }
            );
            logger('Job set inactive: ' + JSON.stringify(res));
        }
        //logger("db.dashboards.find({oid: ObjectId('" + job.dashboardId + "')})");
    }

    if (!isValid && !isJobToDelete) {
        logger('db.getSiblingDB(\'prismWebDB\').jobs.find({_id: ObjectId(\'' + job._id + '\')});');
    }
    if (job.active && job.jobType === 'dashboardSubscription') {
        dividerSmall();
    }

}

function validateAllJobs() {

    var index = 0;
    prismWebDB.getCollection('jobs')
        .find({})
        .sort({created: -1})
        .forEach(function (job) {
            var startTime = new Date();
            index += 1;
            validateJob(job);
            var endTime = new Date();
            timeDiff(startTime, endTime);
            getPercent(index, jobCount);
            // logger(growthPercent + '% ' + index + '/' + jobCount + ' ' + ' Job (_id): ' + job._id +
            //     ' Execution time ' + execTime.seconds + ' seconds');
        });

    if (config.cleanup.doCleanup) {
        logger('Bulk jobs delete execute');
        var bulkResult = bulk.execute();
        logger(bulkResult);
    }
    logger('Broken jobs ' + brokenJobs + ' copies');
    logger('Validating all jobs has ended.');
}

// Main script
var jobCount = prismWebDB.jobs.count();
logger('Validating all ' + jobCount + ' jobs ');
prismWebDB.getCollection('jobs')
    .find({ active: false, jobType: 'dashboardSubscription' })
    .forEach(function (job) {
        jobDashboards.push(job.dashboardId);
    });
var jobsActiveCount = prismWebDB.getCollection('jobs')
    .find({ active: true, jobType: 'dashboardSubscription' }).count();
logger('Job dashboards ' + jobDashboards.length + ' ');
logger('Job dashboards active ' + jobsActiveCount + ' ');

validateAllJobs();
printStats();
