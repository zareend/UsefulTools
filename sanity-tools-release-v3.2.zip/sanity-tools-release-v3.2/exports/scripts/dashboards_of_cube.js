/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Dashboards not used';

// Configuration
var showLogs = false;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    targetDate: new Date('2019-12-30T16:45:00'),
    export: {
        enabled: true,
        keys: ['_id', 'title', 'userId', 'lastUsed']
    },
    logging: {
        showLogs: showLogs
    }
};
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion
if (config.export.enabled) {
    exportHeader();
}
printHeader();
printConfig(config);

// Global variables
var cube = {
    title: 'Tutorial',
    server: 'LocalHost'
};
var cubeFilter = { 'datasource.title': cube.title, 'datasource.address': cube.server };
var bulk = prismWebDB.getCollection('elasticubes').initializeUnorderedBulkOp();

// Functions
function exportHeader() {
    var msg = '';
    config.export.keys.forEach(function (key) {
        msg += key + ',';
    });
    print(msg);
}

function exportRow(data) {
    var msg = '';
    config.export.keys.forEach(function (key) {
        var val = data[key];
        msg += val + ',';
    });
    print(msg);
}

function validateCubes() {
    prismWebDB.getCollection('dashboards').find(cubeFilter).forEach(function (dash) {
        exportRow(dash);
    });
}

// Main script
validateCubes();
//endregion

