/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Cube build time export';

// Configuration
var showLogs = false;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var showShareDuplicates = false;

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    targetDate: new Date('2019-12-30T16:45:00'),
    export: {
        enabled: true,
        keys: ['_id', 'title', 'lastBuildTime']
    },
    logging: {
        showLogs: showLogs,
        showShareDuplicates: showShareDuplicates
    }
};
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';
function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    }
    else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}
loadScript('utils.js', utilsFolder);
//endregion
if (config.export.enabled) {
    exportHeader();
}
printHeader();
printConfig(config);

// Global variables
var today = new Date();
var bulk = prismWebDB.getCollection('elasticubes').initializeUnorderedBulkOp();

// Functions
function exportHeader(){
    var msg = '';
    config.export.keys.forEach(function(key){
        msg += key + ','
    });
    print(msg);
}
function exportRow(data) {
    var msg = '';
    Object.keys(data).forEach(function(key){
        var val = data[key];
        if (config.export.keys.indexOf(key) !== -1){
            if (val.toECString){
                val = val.toECString();
            }
            msg += val + ','
        }
    });
    print(msg);
}
function validateBuildTime(cube) {
    var result = true;
    if (cube.lastBuildTime) {
        var cubeYear = cube.lastBuildTime.getFullYear();
        var todayYear = today.getFullYear();
        logger('year ' + cubeYear);
        if (cubeYear < todayYear) {
            logger('! cube was not built this year');
            result = false;
        }
        if(config.targetDate > cube.lastBuildTime) {
            logger('! cube was not built after ' + config.targetDate);
            result = false;
        }
    } else if (cube.type === 'live') {
        logger('Cube is live model');
    } else {
        logger('! cube was not built');
        result = false;
    }

    return result;
}


function validateCubes() {
    prismWebDB.getCollection('elasticubes').find({}).sort({ lastBuildTime: -1 }).forEach(function (cube) {
        if(!validateBuildTime(cube)) {
            exportRow(cube)
        }
    });

}

// Main script

validateCubes();

//endregion

