# Read Me
##Current version: 3.1.3
All relevant scripts are collected in mongo_scripts folder.<br>
Other developed useful items are in misc folder.
###To start development
1. Clone repository
1. Run `npm install` to get node modules
1. Create your branch
1. Enjoy

###Types of changes
######Start commit message with one of below
- **Added** for new features.
- **Changed** for changes in existing functionality.
- **Deprecated** for soon-to-be removed features.
- **Removed** for now removed features.
- **Fixed** for any bug fixes.
- **Security** in case of vulnerabilities.

###Release Process
1. Merge all the changes to the release branch (e.g. master)
1. Bump up version in package JSON and commit the changes with a new release version tag
    - `git commit --all -m "Bump version to X.Y.Z"`
    - `git tag -a vX.Y.Z -m "X.Y.Z"`
    - Run `npm run changelog` and `git commit --all -m "Changed changelog updated to X.Y.Z"` a new changelog
    - `git push origin --tags`
1. Run `npm publish` to push a new version of the package


## Preparations:
### To send scripts to customer:
1. Download zip from this repository
1. Add it to a shareable location & get the link
1. Send link to the customer

### To run the script on Windows:
#### Option 1
1. On the environment, open http://localhost:3030/system
1. Run GetAppUserCred.exe
1. Copy string between AppUser: up to @127.0.0.1 like '8fP2E2uVF0xwp8wh0qk+Tg=='
1. Paste it into program, press Enter
1. Copy encryption key like 'S2c0OEVmdDJQSmI5bTdYVw==' and paste it into program, press Enter
1. Now you can run any bat file
#### Option 2 - requires Root Credentials to set up
1. On the environment, open misc folder
1. Run createMongoUser.bat
   - Specify password that will be use for AppAdminUser
   - Specify password for Root User
   - If everything is done correctly you'll get app user with admin access
1. Now you can run any bat file

### To run the script on Linux:
#### Steps
1. Extract the .zip file to a folder named "sanity-tools-master"

1. Open the Sisense File Manager (Sisense Web App -> Admin -> System Management -> File Management) and upload the "sanity-tools-master" folder to the "data" folder (whose full path is actually /opt/sisense/storage/data)

1. Connect with SSH to Sisense (or to the Bastion machine) so that you could run si and kubectl commands

1. Backup the system (in case we would later want/need to restore)
   - `si system backup -include-farm no`
   - verify that the backup completed - run <br>`kubectl get pods -n sisense -w` <br>and verify that the sisense-backup-... pod has a Completed status

1. Use the following command to copy the folder to the sisense-mongod-0 pod and specifically to the mongod-container:<br>
`kubectl cp /opt/sisense/storage/data/sanity-tools-master sisense/sisense-mongod-0:/ -c mongod-container`
1. Open a shell on the sisense-mongod-0 pod and specifically on the mongod-container:<br>
`kubectl -n sisense exec sisense-mongod-0 -c mongod-container -it -- /bin/bash`

1. Run the utility:<br>
    - analyze
        - run `mongo /sanity-tools-master/mongo_tools/scripts/scripts_loader.js > result.txt`
        - review results
    - cleanup 
        - do a backup of db ( optional due to earlier backup in step 4, but ensure you have valid backup )
        - run `mongo --eval "var cleanup=true" /sanity-tools-master/mongo_tools/scripts/scripts_loader.js > result.txt`
        - review results
        - restart Repository service

1. After the utility finished running, inspect the result.txt file, check if it fixed any specific inconsistencies and if possible also send us this file

## Tools & options available:
### Mongo Backup:
1. Run **MongoBackup.bat**
1. Open C:\SisenseWebBackups\MongoBackup and see the dumped prismConfig & prismWebDB

### Mongo Restore:
1. Run **MongoRestore.bat**
1. Open Robomongo and verify backup restored

### To run general healthcheck:
1. Run **AnalyzeMongo.bat**
1. Open analyzer_results_%timestamp% and check output
1. Optional:
    * Run CleanMongo.bat for cleanup

### To run general cleanup:
1. Run one of two:
    * **BackupAndCleanMongo.bat** for backup mongo + cleanup
    * **CleanMongo.bat** for cleanup with no backup (**not recommended unless you are completely sure in what you're doing**)
1. Open clean_results_%timestamp% and check output
1. Run AnalyzeMongo.bat
1. Open analyzer_results_%timestamp% and check output

### To run Mongo memory analysis:
1. Run **AnalyzeDB.bat**
1. Open db_analyzer_%host%_%timestamp% and check output

### To run filter analysis:
1. Run **AnalyzeFilters.bat**
1. Open filter_analyzer_%timestamp% and check output

### To run dimensions analysis:
1. Run **AnalyzeDIMs.bat**
1. Open dimension_analyzer_%host%_%timestamp% and check output

### To create scheduled cleaner:
1. Use scheduled_duplicates_cleanup.bat
1. Create windows task to run it with some interval
1. Results will be stored in the folder with bat file named scheduled_cleaner_%host%_%timestamp%

### To run a separate script in cmd:
##### Option 1:
1. Change in custom_script runner: load('%path_to_script%/%script_name%.js') to point to the script you want to run
1. Run CustomScriptAnalyzer to run for analyze
1. Run CustomScriptCleaner to run for cleanup
##### Option 2:
1. Take this string and set script_name to desired script, and output_file_name to desired output file name
1. Run command in cmd: "C:\Program Files\Sisense\Infra\MongoDB\sisenseRepositoryShell.exe" --host mongodb://%MONGO_USR%:%MONGO_PWD%@localhost:%MONGO_PORT% %script_name%.js > %output_file_name%.json
1. You can also remove > %output_file_name%.json from this call to see output in cmd directly

## Scripts description:
* scripts_loader - util script to load other scripts, you can comment down any scripts you don't want for healthcheck
* custom_script_runner - util script to load another script & use bat files to run it (see manual above)
#### Healthcheck scripts
* widget_duplicates_cleaner - remove duplicates from dashboards & widgets collections of mongodb
* dashboard_widget_duplicates - remove duplicates from dashboard widgets array
* cube_shares_duplicates - remove shares from elasticcubes shares array
* dash_shares_duplicates - remove duplicates from dashboard shares array + fix owner that is not in shares
* user_groups - fixes duplicated user group items
* dashboard_validate - validate dashboard folder, user, ghost widgets on layout and e.t.c
* user_validate - validate user id, groups, role
* jobs_validate - validate scheduled jobs of different kind
* widget_validate - validate widgets if they should exist based on user / dashboard existence
* unused_cubes_cleaner - check elasticcubes collection to see if cube is used in any dashboards and / or widgets
* filter_analyzer - analyze all filters from widgets and dashboards for data security related questions
* dim_analyzer - analyze all dimensions usage in dashboard - filters, widgets for all cubes
#### Other scripts
* user_ldap_validate - for ldapDomainId that is a string make it back ObjectId
* widget_duplicates_cleaner_scheduled - copy of widget_duplicates_cleaner with doCleanup = true to run scheduled cleanup
#### Not finished scripts 
* ha_cleaner - template for cleaning on HA environment, not finished
* datasecurity_validate - template for validating data security rules to be on existing cube / dimension
#### Util scripts
* compare_objects - util script to compare two similar objects and show their difference
* log_tracer - util script to analyze entries in trace collection
### Optionally needed scripts & scenarios from misc folder
* createMongoUser.bat - scenario to create application admin user for specific mongo commands
* build_logs_cleaner.bat - scenario to clean elasticcube build logs for capped / non-capped collections
* size_check.bat - scenario to check size of objects in all collections
* ReleaseMemory.bat - scenario to clean known memory consuming cases 



