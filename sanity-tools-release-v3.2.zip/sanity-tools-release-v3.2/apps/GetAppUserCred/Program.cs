﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;

namespace GetAppUserCred
{
    class Program
    {
        const int AESEncryptionByteKeySize = 16;
        const string param_AuthKey = "-AuthKey=";
        const string param_AuthStr = "-AuthStr=";
        const string param_IV = "-IV=";
        const string param_saveEnvVar = "-SaveEnvVar";
        const string EnvVarName = "MONGO_PWD";


        public static string IV = "ePtH5UDflH6YvSR0ihwkcQ==";
        public static string MongoAppUserPwd;
        public static string MongoAuthKey;
        public static string MongoAuthStr;
        public static bool BatchExecution = false;
        public static bool SaveEnvVar = false;


        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                ParseParams(args);
            }
            if (string.IsNullOrWhiteSpace(MongoAuthStr))
            {
                Console.Write("Enter MongoAuthStr: ");
                MongoAuthStr = Console.ReadLine();
            }
            if (string.IsNullOrWhiteSpace(MongoAuthKey))
            {
                Console.Write("Enter MongoAuthKey: ");
                MongoAuthKey = Console.ReadLine();
            }

            MongoAppUserPwd = Decrypt(MongoAuthStr, MongoAuthKey, IV);

            Console.WriteLine(MongoAppUserPwd);

            if (!BatchExecution & !SaveEnvVar)
            {
                Console.Write("Save password to environment variable [y/n(default)]: ");
                string _answer = Console.ReadLine();
                SaveEnvVar = _answer.ToLower().StartsWith("y");
            }

            if (SaveEnvVar)
            {
                try
                {
                    System.Environment.SetEnvironmentVariable(EnvVarName, MongoAppUserPwd, EnvironmentVariableTarget.Machine);
                }
                catch
                {
                    Console.WriteLine(string.Format("Couldn't save '{1}' environment variable. Most likely you application wasn't ran as administrator.{0}You can set it manually with this command: SETX {1} {2} /M{0}", Environment.NewLine, EnvVarName, MongoAppUserPwd));
                }
            }

            Exit();
        }

        internal static string Decrypt(string data, string key, string iv)
        {
            // appending with first block of data
            var bytearr = Convert.FromBase64String(data);
            var keyBytes = Convert.FromBase64String(key);
            var ivector = Convert.FromBase64String(iv);

            // Declare the string used to hold
            // the decrypted text.
            string plaintext = null;

            // Create an Aes object
            // with the specified key and IV.
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = setAESKeySize(keyBytes, AESEncryptionByteKeySize);
                aesAlg.IV = ivector;

                // Create a decryptor to perform the stream transform.
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                // Create the streams used for decryption.
                using (MemoryStream msDecrypt = new MemoryStream(bytearr))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            // Read the decrypted bytes from the decrypting stream
                            // and place them in a string.
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }
            }

            return plaintext;
        }

        /// <summary>
        /// Gets a key bytes array and sets it as the given size
        /// </summary>
        /// <param name="key"></param>
        /// <param name="keySize"></param>
        /// <returns></returns>
        private static byte[] setAESKeySize(byte[] key, int keySize)
        {
            if (key.Length < keySize) // increasing key length
            {
                while (key.Length < keySize)
                {
                    key = key.Concat(key.Take(keySize - key.Length)).ToArray();
                }
            }
            else if (key.Length > keySize) // decreasing key length
            {
                key = key.Take(keySize).ToArray();
            }

            return key;
        }

        internal static void ParseParams(string[] args)
        {
            foreach (string arg in args)
            {
                if (arg.ToLower().Equals("-b") || arg.ToLower().Equals("-batch"))
                {
                    BatchExecution = true;
                }
                else if (arg.ToLower().Equals("-h") || arg.ToLower().Equals("-help"))
                {
                    ShowHelp();
                    Exit();
                }
                else if (arg.ToLower().StartsWith(param_saveEnvVar.ToLower()))
                {
                    SaveEnvVar = true;
                }
                else if (arg.ToLower().StartsWith(param_AuthKey.ToLower()))
                {
                    MongoAuthKey = arg.Remove(0, param_AuthKey.Length);
                }
                else if (arg.ToLower().StartsWith(param_AuthStr.ToLower()))
                {
                    MongoAuthStr = arg.Remove(0, param_AuthStr.Length);
                }
                else if (arg.ToLower().StartsWith(param_IV.ToLower()))
                {
                    IV = arg.Remove(0, param_IV.Length);
                }
                else
                {
                    Console.WriteLine(string.Format("Unrecognized parameter '{0}'", arg));
                    Exit(1);
                }
            }
        }

        public static void ShowHelp()
        {
            string usageMsg = string.Format("Usage: GetAppUserCred [-batch|-b] [{1}<value>] [{2}<value>] [{3}<value>]{0}",
                Environment.NewLine, param_AuthKey, param_AuthStr, param_IV);
            string optionsMsg = string.Format("options:" +
                "{0}    -batch|-b   Batch mode" +
                "{0}    {1,-11} provide value for AuthKey" +
                "{0}    {2,-11} provide value for AuthStr" +
                "{0}    {3,-11} override default value IV",
                "{0}    {4,-11} save password to environment variable {0}",
                Environment.NewLine, param_AuthKey, param_AuthStr, param_IV, param_saveEnvVar);

            Console.WriteLine(usageMsg);
            Console.WriteLine(optionsMsg);
        }

        public static void Exit(int exitCode = 0)
        {
            Console.WriteLine();
            if (!BatchExecution)
            {
                Console.WriteLine("Press any key to exit");
                Console.ReadKey();
            }
            Environment.Exit(exitCode);
        }
    }
}
