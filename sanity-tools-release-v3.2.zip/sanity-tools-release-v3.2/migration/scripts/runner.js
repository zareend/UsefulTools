/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Migration runner';

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};
var scriptsList = [
    'get_cubes_mapping.js',
    'cubes.js',
    'users.js',
    'kpi.js',
    'hierarchies.js',
    'datasecurity.js',
    'dashboards_and_widgets.js',
    'replace_datasource.js',
];

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';

function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    } else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}

loadScript('utils.js', utilsFolder);
loadScript('mapping.js');
//endregion

// Global variables
var logsStatus = getStatus(showLogs);
var cleanupStatus = getStatus(doCleanup);
var globalRun = true;
var collectedStats = {};
var timeStats = {};
var startDate = new Date();
var endDate;

// Functions
function printHeader() {
    divider();
    logger(scriptName + ' ' + version + ' © Sisense ');
    logger('Total scripts to apply: ' + scriptsList.length + ' ');
    logger('Cleanup ' + cleanupStatus + ' | Logs ' + logsStatus);
    logger(' ');
    logger(startDate);
}

function loadScripts() {
    scriptsList.forEach(function (script, index) {
        divider();
        var startTime = new Date();
        logger('Starting script  ' + index + ': ' + script + ' from ' + scriptsList.length +
            ' © Sisense');
        if (scriptsFolder) {
            var path = scriptsFolder + '/' + script;
            load(path);
        } else {
            load(script);
        }
        var endTime = new Date();
        var scriptTime = timeDiff(startTime, endTime);
        timeStats[script] = scriptTime.seconds;
        logger('Execution time of the script  ' + index + ': ' + script + ' from ' +
            scriptsList.length + ' © Sisense: ' + scriptTime.text + '  ');
        divider();
        //sleep(timeout);
    });
}

function printSummary() {
    logger('   ');
    divider();
    logger('Scripts statistics ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    endDate = new Date();
    var execTime = timeDiff(startDate, endDate);
    var total = 0;

    Object.keys(collectedStats).sort().forEach(function (key) {
        var value = collectedStats[key];
        if (value > 0) {
            logger(' - ' + key + ': ' + value + ' items');
        }
        total += value;
    });
    if (total > 0) {
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + total);
    }
    logger(' ');
    logger('Execution time ' + execTime.text + ' total in: ');
    Object.keys(timeStats).sort().forEach(function (key) {
        var value = timeStats[key];
        logger(' - ' + key + ': ' + value + ' seconds');
    });
    divider();
}

// Main script
printHeader();
printConfig(config);
loadScripts();
// Done
divider();
printSummary();
logger('Script has finished execution successfully ' + ' © Sisense');
