/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Migration runner';

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';

function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    } else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}

loadScript('utils.js', utilsFolder);
loadScript('mapping.js');
//endregion

printHeader();
printConfig(config);

// Global variables
var setCount = 0;

// Functions
function checkSet(cube) {
    return cube.title.indexOf(migrationConfig.setSuffix) || cube.server === migrationConfig.set;
}

// Main script
prismWebDB.getCollection('elasticubes').aggregate([
    {
        $group:
            {
                _id: '$title',
                cubes: { $push: { item: '$_id', server: '$server' } },
                count: { $sum: 1 }
            }
    },
    { $sort: { count: -1 } }
]);
prismWebDB.getCollection('elasticubes').find({}).sort({ title: 1 }).forEach(function (cube) {
    var msg = '';
    var isSet = checkSet(cube);
    if (isSet > 0) {
        setCount += 1;
        msg += ' - ! Set ';
        msg += 'cube ' + cube.title + ' | '
            + 'type: ' + cube.type + ' | '
            + 'server: ' + cube.server + ' | '
            + 'shares: ' + cube.shares.length + ' | '
            + 'buildTime: ' + cube.lastBuildTime;
        logger(msg);
        if (cube.fullNames) {
            cube.fullNames.forEach(function (cubeName) {
                var newSetName = cubeName.split('/')[1];
                var cubesCount = prismWebDB.getCollection('elasticubes')
                    .find({ title: newSetName })
                    .count();
                logger('   --- ' + cubeName + ' count: ' + cubesCount);
            });
        } else {
            logger('!!!! cube doesn\'t have fullnames');
        }

    } else {
        msg += ' - simple ';
        msg += 'cube ' + cube.title + ' | '
            + 'type: ' + cube.type + ' | '
            + 'server: ' + cube.server + ' | '
            + 'shares: ' + cube.shares.length + ' | '
            + 'buildTime: ' + cube.lastBuildTime;
        logger(msg);
    }

});

// Done
divider();
logger('Script has finished execution successfully ' + ' © Sisense');
