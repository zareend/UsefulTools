//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';

function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    } else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}

loadScript('utils.js', utilsFolder);
loadScript('mapping.js');
//endregion

// kpi

var change_JAQL = true;


/* Auxiliary functions */
function JAQLsanity(JAQL) {
    if (!change_JAQL) {
        return JAQL;
    }
    if (JAQL.table && JAQL.column && JAQL.dim) {
        if (JAQL.dim.indexOf('(Calendar)') === -1) {
            JAQL.dim = '[' + JAQL.table + '].[' + JAQL.column + ']';
        } else {
            JAQL.dim = '[' + JAQL.table + '].[' + JAQL.column + ' (Calendar)]';
        }
    }

    return JAQL;
}

function fullnameToTitle(fullname) {
    return fullname.substring(fullname.indexOf('/') + 1);
}

function titleToId(title) {
    return title.replace(/ /g, 'IAAa')
        .replace(/_/g, 'XwAa')
        .replace(/-/g, 'LQAa')
        .replace(/&/g, 'JgAa');
}

function processContext(object) {
    if (!Object.keys(object).includes('context')) {
        if (object.datasource) {
            object.datasource = replaceDatasource(object.datasource);
        }
        return object;
    } else {
        for (var context in object.context) {
            if (object.datasource) {
                object.datasource = replaceDatasource(object.datasource);
            }
            object.context[context] = JAQLsanity(object.context[context]);
            object.context[context] = processContext(object.context[context]);
        }
        return object;
    }
}

function replaceDatasource(datasource) {
    if (datasource.fullname && datasource.fullname.startsWith('LocalHost/')) {
        datasource.id = 'localhost_a' + titleToId(fullnameToTitle(datasource.fullname));
        return datasource;
    }

    if (datasource.fullname && datasource.fullname in nameMapping) {
        if (datasource.title) {
            datasource.title = fullnameToTitle(nameMapping[datasource.fullname]);
            datasource.id = 'localhost_a' +
                titleToId(fullnameToTitle(nameMapping[datasource.fullname]));
        }
        datasource.fullname = nameMapping[datasource.fullname];
    } else {
        print(datasource.title + ' was not found!');
        if (datasource.fullname && !datasource.fullname.startsWith('SET') &&
            !datasource.fullname.startsWith('live:')) {
            datasource.title = fullnameToTitle(datasource.fullname);
            datasource.id = 'localhost_a' + titleToId(fullnameToTitle(datasource.fullname));
            datasource.fullname = 'LocalHost/' + fullnameToTitle(datasource.fullname);
        }
    }
    return datasource;
}

db.getCollection('kpi').find({}).forEach(function (kpi) {
    if (kpi.datasource) {
        kpi.datasource = replaceDatasource(kpi.datasource);
    }
    if (kpi.metadata && kpi.metadata.filters && kpi.metadata.filters.length > 0) {
        kpi.metadata.filters.forEach(function (filter) {
            if (filter.jaql) {
                filter.jaql = JAQLsanity(filter.jaql);
                filter.jaql = processContext(filter.jaql);
            }
        });
    }
    if (kpi.metadata && kpi.metadata.measures && kpi.metadata.measures.length > 0) {
        kpi.metadata.measures.forEach(function (measure) {
            if (measure.jaql) {
                measure.jaql = JAQLsanity(measure.jaql);
                measure.jaql = processContext(measure.jaql);
            }
        });
    }
    if (config.cleanup.doCleanup) {
        db.getCollection('kpi').save(kpi);
    }
});
