/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Dashboards & widgets migration';

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';

function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    } else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}

loadScript('utils.js', utilsFolder);
loadScript('mapping.js');
//endregion

// dashboards & widgets
/* Limitation: does not replace nested favourite formulas in the context of the context of the jaql */

/* Parameters */
var global_should_save = true;
var change_JAQL = true;

/* remove filter mapping to dataasoruce of the old server */
var eraseFilterMapping = false;

/* loggers */
var log_changes = false;
var log_skips = false;
var should_save;

/* Auxiliary functions */
function JAQLsanity(JAQL) {
    if (!change_JAQL) {
        return JAQL;
    }
    if (JAQL.table && JAQL.column && JAQL.dim) {
        if (JAQL.dim.indexOf('(Calendar)') === -1) {
            JAQL.dim = '[' + JAQL.table + '].[' + JAQL.column + ']';
        } else {
            JAQL.dim = '[' + JAQL.table + '].[' + JAQL.column + ' (Calendar)]';
        }
    }

    return JAQL;
}

function titleToId(title) {
    return title.replace(/ /g, 'IAAa')
        .replace(/_/g, 'XwAa')
        .replace(/-/g, 'LQAa')
        .replace(/&/g, 'JgAa');
}

function fullnameToTitle(fullname) {
    return fullname.substring(fullname.indexOf('/') + 1);
}

function replaceDatasource(datasource) {
    if (datasource.fullname && datasource.fullname.startsWith('LocalHost/')) {
        datasource.id = 'localhost_a' + titleToId(fullnameToTitle(datasource.fullname));
        return datasource;
    }

    if (datasource.fullname && datasource.fullname in nameMapping) {
        if (datasource.title) {
            datasource.title = fullnameToTitle(nameMapping[datasource.fullname]);
            datasource.id = 'localhost_a' +
                titleToId(fullnameToTitle(nameMapping[datasource.fullname]));
        }
        datasource.fullname = nameMapping[datasource.fullname];
    } else {
        print(datasource.title + ' was not found!');
        if (datasource.fullname && !datasource.fullname.startsWith('SET') &&
            !datasource.fullname.startsWith('live:')) {
            datasource.title = fullnameToTitle(datasource.fullname);
            datasource.id = 'localhost_a' + titleToId(fullnameToTitle(datasource.fullname));
            datasource.fullname = 'LocalHost/' + fullnameToTitle(datasource.fullname);
        }
    }
    return datasource;
}

function shouldSave(datasource, should_save) {
    return (datasource) ? true : should_save;
}

/* Main execution */

/* Fix dashboard collection */
try {
    db.getCollection('dashboards').find({}).forEach(function (dash) {
        var should_save = false;

        /* remove filter mapping to datasoruce of the old server */
        if (eraseFilterMapping) {
            if (dash.filterToDatasourceMapping && typeof (dash.filterToDatasourceMapping) ===
                'object' && Object.keys(dash.filterToDatasourceMapping).length > 0) {
                for (var key in dash.filterToDatasourceMapping) {
                    if (key.indexOf(new_server.id) === -1) {
                        delete dash.filterToDatasourceMapping[key];
                        should_save = true;
                    }
                }
            }
        }
        /* Fix dashboard datasource */
        if (dash.datasource) {
            should_save = shouldSave(dash.datasource, should_save);
            dash.datasource = replaceDatasource(dash.datasource);
        }

        /* Fix widgets in dashboard */
        if (dash.widgets) {
            dash.widgets.forEach(function (widget) {
                /* Fix widget datasource */
                if (widget.datasource) {
                    should_save = shouldSave(widget.datasource, should_save);
                    widget.datasource = replaceDatasource(widget.datasource);
                }

                /* Fix widget panels datasource */
                if (widget.metadata && widget.metadata.panels) {
                    widget.metadata.panels.forEach(function (panel) {

                        if (panel.items) {
                            panel.items.forEach(function (item) {
                                /* Fix widget.panels.items datasource */
                                if (item.jaql && item.jaql.datasource) {
                                    should_save = shouldSave(item.jaql.datasource, should_save);
                                    item.jaql = JAQLsanity(item.jaql);
                                    item.jaql.datasource = replaceDatasource(item.jaql.datasource);
                                }
                                /* Fix widget.panels.items.context datasource */
                                if (item.jaql && item.jaql.context) {
                                    for (var context in item.jaql.context) {
                                        if (item.jaql.context[context].datasource) {
                                            should_save = shouldSave(
                                                item.jaql.context[context].datasource, should_save);
                                            item.jaql.context[context].datasource = replaceDatasource(
                                                item.jaql.context[context].datasource);
                                            item.jaql.context[context] = JAQLsanity(
                                                item.jaql.context[context]);
                                        }
                                    }
                                }
                            });
                        }
                    });
                }

            });
        }
        if (dash.filters) {
            dash.filters.forEach(function (filter) {
                /* Fix dashboard.filters datasource */
                if (filter.jaql && filter.jaql.datasource) {
                    should_save = shouldSave(dash.datasource, should_save);
                    filter.jaql.datasource = replaceDatasource(filter.jaql.datasource);
                    filter.jaql = JAQLsanity(filter.jaql);
                }
                /* Fix dashboard.filters.level datasource (cascading filters) */
                if (filter.levels) {
                    filter.levels.forEach(function (level) {
                        if (level.datasource) {
                            should_save = shouldSave(level.datasource, should_save);
                            level.datasource = replaceDatasource(level.datasource);
                            /* do not perform sanity check since dim in the cascading fitlers should be different (An item with the same key has already been added error)
							level = JAQLsanity(level); */
                        }
                    });
                }
            });
        }
        if (dash.defaultFilters) {
            dash.defaultFilters.forEach(function (d_filter) {
                /* Fix dashboard.defaultFilters datasource */
                if (d_filter.jaql && d_filter.jaql.datasource) {
                    should_save = shouldSave(d_filter.jaql.datasource, should_save);
                    d_filter.jaql.datasource = replaceDatasource(d_filter.jaql.datasource);
                    d_filter.jaql = JAQLsanity(d_filter.jaql);
                }
                /* Fix dashboard.defaultFilters.level datasource (cascading filters) */
                if (d_filter.levels) {
                    d_filter.levels.forEach(function (level) {
                        if (level.datasource) {
                            should_save = shouldSave(level.datasource, should_save);
                            level.datasource = replaceDatasource(level.datasource);
                            JAQLsanity(level);
                        }
                    });
                }

            });
        }
        if (global_should_save && should_save) {
            if (log_changes) {
                print('Saving dash: ' + dash.oid + ' ' + dash.title + ' ' + dash.instanceType);
            }
            db.getCollection('dashboards').save(dash);
        } else {
            if (log_skips) {
                print('Skipped dashboard: ' + dash.oid);
            }
        }
    });
} catch (e) {
    print(e);
}

/* Fix widget collection */
try {
    db.getCollection('widgets').find({}).forEach(function (widget) {
        should_save = false;
        /* Fix widget datasource */
        if (widget.datasource) {
            should_save = shouldSave(widget.datasource, should_save);
            widget.datasource = replaceDatasource(widget.datasource);

        }
        /* Fix widget panels datasource */
        if (widget.metadata && widget.metadata.panels) {
            widget.metadata.panels.forEach(function (panel) {
                if (panel.items) {
                    panel.items.forEach(function (item) {
                        /* Fix widget.panels.items datasource */
                        if (item.jaql && item.jaql.datasource) {
                            should_save = shouldSave(item.jaql.datasource, should_save);
                            item.jaql.datasource = replaceDatasource(item.jaql.datasource);
                            item.jaql = JAQLsanity(item.jaql);
                        }
                        /* Fix widget.panels.items.context datasource */
                        if (item.jaql && item.jaql.context) {
                            for (var context in item.jaql.context) {
                                if (item.jaql.context[context].datasource) {
                                    should_save = shouldSave(item.jaql.context[context].datasource,
                                        should_save
                                    );
                                    item.jaql.context[context].datasource = replaceDatasource(
                                        item.jaql.context[context].datasource);
                                    item.jaql.context[context] = JAQLsanity(
                                        item.jaql.context[context]);
                                }
                            }
                        }
                    });
                }
            });
        }

        if (global_should_save && should_save) {
            if (log_changes) {
                print('Saving widget: ' + widget.oid + ' ' + widget.title + ' ' +
                    widget.instanceType);
            }
            db.getCollection('widgets').save(widget);
        } else {
            if (log_skips) {
                print('Skipped widget: ' + widget.oid);
            }
        }
    });
} catch (error) {
    print(error);
}
