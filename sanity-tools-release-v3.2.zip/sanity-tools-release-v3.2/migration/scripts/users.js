/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.2';
var scriptName = 'User migration';

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};

//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';

function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    } else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}

loadScript('utils.js', utilsFolder);
loadScript('mapping.js');
//endregion

printHeader();
printConfig(config);

// Global variables

// Functions

// Main script
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');
var prismMonitor = db.getSiblingDB('monitor');
var usersAgg = prismWebDB.getCollection('users').aggregate([
    { $group: { _id: '$roleId', count: { $sum: 1 }, 'users': { $push: '$_id' } } }
]).toArray();

usersAgg.forEach(function (aggItem) {
    var roleName = '';
    prismConfig.getCollection('roles').find({ _id: aggItem._id }).forEach(function (role) {
        roleName = role.name;
    });
    print(roleName + ' ' + aggItem.count + ' users');
    var newRole = rolesMap[roleName].new;
    if (config.cleanup.doCleanup) {
        var res = prismWebDB.getCollection('users')
            .updateMany({ _id: { $in: aggItem.users } }, { $set: { roleId: newRole } });
        logger(JSON.stringify(res));
    }
});

prismWebDB.getCollection('users').find({}).forEach(function (user) {
    var should_save = false;
    if (user.uiSettings && user.uiSettings.ecmNext && user.uiSettings.ecmNext.schemas) {
        should_save = true;
    }
    if (should_save) {
        prismWebDB.getCollection('users')
            .update({ _id: user._id }, { $unset: { 'uiSettings.ecmNext.schemas': '' } });
    }
});

