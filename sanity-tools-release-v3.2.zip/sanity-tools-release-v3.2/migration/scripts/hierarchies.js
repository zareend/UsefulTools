/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Hierarchies migration';

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';

function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    } else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}

loadScript('utils.js', utilsFolder);
loadScript('mapping.js');
//endregion
prismWebDB.getCollection('hierarchies').find({}).forEach(function(hi){
    if (hi.cubeId.str in idMapping){
        hi.cubeId = ObjectId(idMapping[hi.cubeId.str]);
        if (config.cleanup.doCleanup){
            prismWebDB.getCollection('hierarchies').save(hi);
        }
    }
    else {
        if (!Object.keys(idMapping).map(key => idMapping[key]).includes(hi.cubeId.str))
        print('db.getCollection(\'hierarchies\').deleteOne({_id : ObjectId("' + hi._id.str + '")}); \n');
    }
})
