// Create SET <-> EC Mappings
//to cut server name when comparing old ECs in SETs with new ECs
function serverECtoEC(serverEC) {
    return serverEC.substring(serverEC.indexOf('/') + 1);
}
//remove old ECs that are part of the old SETs
var oldCubes = db.getCollection('elasticubes')
    .find({}, { title: 1, _id: 1, fullNames: 1, server: 1 })
    .toArray();
var new_cubes = db.getCollection('elasticubes').find({}, { title: 1, _id: 1 }).toArray();
var cubeNameMapping = {};
var idMapping = {};
oldCubes.forEach(function (cube) {
    if (cube.server && cube.server !== 'set') {
        if (new_cubes.filter(new_cube => (new_cube.title === cube.title)).length > 0) {
            cubeNameMapping[cube.server + '/' + cube.title] = 'LocalHost/' +
                new_cubes.filter(new_cube => (new_cube.title === cube.title))[0].title;
            idMapping[cube._id.str] = new_cubes.filter(
                new_cube => (new_cube.title === cube.title))[0]._id.str;
        } else {
            print('Could not find cube for ' + cube.server + '/' + cube.title);
        }
    } else {
        if (cube.fullNames && new_cubes.filter(
            new_cube => (new_cube.title === serverECtoEC(cube.fullNames[0]))).length > 0) {
            cubeNameMapping['SET/' + cube.title] = 'LocalHost/' + new_cubes.filter(
                new_cube => (new_cube.title === serverECtoEC(cube.fullNames[0])))[0].title;
            idMapping[cube._id.str] = new_cubes.filter(
                new_cube => (new_cube.title === serverECtoEC(cube.fullNames[0])))[0]._id.str;
        } else {
            print('Could not find cube for ' + 'SET/' + cube.title);
        }
    }
});
print(JSON.stringify(cubeNameMapping, null, 2));
print(JSON.stringify(idMapping, null, 2));
