/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Datasource replacer';

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';

function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    } else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}

loadScript('utils.js', utilsFolder);
loadScript('mapping.js');
//endregion

//var address = 'LocalHost/Corporate Travel';
//var newAddress = 'LocalHost';
//var newDatasource = {
//    "title": "Corporate Travel",
//    "fullname": "LocalHost/Corporate Travel",
//    "id": "localhost_aCorporateIAAaTravel"
//};


prismWebDB.dashboards.createIndex({ 'datasource.fullname': 1 });
prismWebDB.widgets.createIndex({ 'datasource.fullname': 1 });
prismWebDB.dashboards.update({}, { $unset: { filterToDatasourceMapping: 1 } }, { multi: true });

function replaceDatasource() {
    return newDatasource;
}

function replaceDIM(jaql) {
    if (jaql.table && jaql.column) {
        if (jaql.dim.includes('Calendar')) {
            jaql.dim = '[' + jaql.table + '.' + jaql.column + ' (Calendar)]';
        } else {
            jaql.dim = '[' + jaql.table + '.' + jaql.column + ']';
        }
    }
    return jaql;
}

for (var k = 0; k < arrays.length; k++) {
    var address = arrays[k]['address'];
    var newDatasource = {
        'title': arrays[k]['title'],
        'fullname': arrays[k]['fullname'],
        'id': arrays[k]['id']
    };
    try {
        var dCount = prismWebDB.getCollection('dashboards')
            .count({ 'datasource.fullname': address });
        logger(address + ' dashboards '+ dCount);
        prismWebDB.getCollection('dashboards')
            .find({ 'datasource.fullname': address })
            .forEach(function (e) {
                if (e.datasource) {
                    e.datasource = replaceDatasource();
                }
                if (e.widgets) {
                    e.widgets.forEach(function (r) {
                        if (r.datasource) {
                            r.datasource = replaceDatasource();
                        }

                        if (r.metadata && r.metadata.panels && r.metadata.panels.items) {
                            r.metadata.panels.items.forEach(function (h) {
                                if (h.jaql && h.jaql.datasource) {
                                    h.jaql.datasource = replaceDatasource();
                                }
                                if (h.jaql) {
                                    h.jaql = replaceDIM(h.jaql);
                                }
                            });
                        }

                    });
                }
                if (e.filters) {
                    e.filters.forEach(function (r) {
                        if (r.jaql) {
                            var datasource = r.jaql.datasource;
                            r.jaql = replaceDIM(r.jaql);
                        } else {
                            print('no r.jaql');
                        }

                        if (datasource) {
                            r.jaql.datasource = replaceDatasource();
                        }

                        if (r.levels) {
                            r.levels.forEach(function (level) {
                                var datasource = level.datasource;
                                if (datasource) {
                                    level.datasource = replaceDatasource();
                                }
                                replaceDIM(level);
                            });
                        }
                    });
                }
                if (e.defaultFilters) {
                    e.defaultFilters.forEach(function (r) {
                        if (r.jaql) {
                            var datasource = r.jaql.datasource;
                            r.jaql = replaceDIM(r.jaql);
                        } else {
                            print('no r.jaql');
                        }
                        if (datasource) {
                            r.jaql.datasource = replaceDatasource();
                        }
                        if (r.levels) {
                            r.levels.forEach(function (level) {
                                var datasource = level.datasource;
                                if (datasource) {
                                    level.datasource = replaceDatasource();
                                }
                                replaceDIM(level);
                            });
                        }

                    });
                }
                if (config.cleanup.doCleanup) {
                    prismWebDB.getCollection('dashboards').save(e);
                }
            });
    } catch (e) {
        print(e);
    }

    try {
        var wCount = prismWebDB.getCollection('widgets')
            .count({ 'datasource.fullname': address });
        logger(address + ' widgets '+ wCount);
        prismWebDB.getCollection('widgets')
            .find({ 'datasource.fullname': address })
            .forEach(function (e) {
                if (e.datasource) {
                    e.datasource = replaceDatasource();
                }
                if (e.metadata && e.metadata.panels) {
                    e.metadata.panels.forEach(function (panel) {
                        panel.items.forEach(function (h) {
                            if (h.jaql && h.jaql.datasource) {
                                h.jaql.datasource = replaceDatasource();
                            }
                            if (h.jaql) {
                                h.jaql = replaceDIM(h.jaql);
                            }
                        });
                    });
                }
                if (config.cleanup.doCleanup) {
                    prismWebDB.getCollection('widgets').save(e);
                }
            });
    } catch (error) {
        print(error);
    }
}
