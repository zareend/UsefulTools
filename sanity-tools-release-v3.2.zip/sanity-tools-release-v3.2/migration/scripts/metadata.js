/**
 * Created by yaroslav.korzh
 * Updated 13/01/2020
 */
// General Info
var version = '3.1.3';
var scriptName = 'Metadata migration';

// Configuration
var showLogs = true;

var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};
//region Common utils
var scriptsFolder = '../scripts';
var utilsFolder = '../utils';

function loadScript(script, scriptPath) {
    var path;
    if (scriptPath) {
        path = scriptPath + '/' + script;
        load(path);
    } else if (scriptsFolder) {
        path = scriptsFolder + '/' + script;
        load(path);
    } else {
        load(script);
    }
}

loadScript('utils.js', utilsFolder);
loadScript('mapping.js');
//endregion

//metadata recursive
var change_JAQL = true;

loadScript('mapping.js');

/* Auxiliary functions */
function JAQLsanity(JAQL) {
    if (!change_JAQL) {
        return JAQL;
    }
    if (JAQL.table && JAQL.column && JAQL.dim) {
        if (JAQL.dim.indexOf('(Calendar)') === -1) {
            JAQL.dim = '[' + JAQL.table + '].[' + JAQL.column + ']';
        } else {
            JAQL.dim = '[' + JAQL.table + '].[' + JAQL.column + ' (Calendar)]';
        }
    }

    return JAQL;
}

function fullnameToTitle(fullname) {
    return fullname.substring(fullname.indexOf('/') + 1);
}

function titleToId(title) {
    return title.replace(/ /g, 'IAAa')
        .replace(/_/g, 'XwAa')
        .replace(/-/g, 'LQAa')
        .replace(/&/g, 'JgAa');
}

function processContext(object) {
    if (!Object.keys(object).includes('context')) {
        if (object.datasource) {
            object.datasource = replaceDatasource(object.datasource);
        }
        return object;
    } else {
        for (var context in object.context) {
            if (object.datasource) {
                object.datasource = replaceDatasource(object.datasource);
            }
            object.context[context] = JAQLsanity(object.context[context]);
            object.context[context] = processContext(object.context[context]);
        }
        return object;
    }
}

function replaceDatasource(datasource) {
    if (datasource.fullname && datasource.fullname.startsWith('LocalHost/')) {
        datasource.id = 'localhost_a' + titleToId(fullnameToTitle(datasource.fullname));
        return datasource;
    }

    if (datasource.fullname && datasource.fullname in nameMapping) {
        if (datasource.title) {
            datasource.title = fullnameToTitle(nameMapping[datasource.fullname]);
            datasource.id = 'localhost_a' +
                titleToId(fullnameToTitle(nameMapping[datasource.fullname]));
        }
        datasource.fullname = nameMapping[datasource.fullname];
    } else {
        print(datasource.title + ' was not found!');
        if (datasource.fullname && !datasource.fullname.startsWith('SET') &&
            !datasource.fullname.startsWith('live:')) {
            datasource.title = fullnameToTitle(datasource.fullname);
            datasource.id = 'localhost_a' + titleToId(fullnameToTitle(datasource.fullname));
            datasource.fullname = 'LocalHost/' + fullnameToTitle(datasource.fullname);
        }
    }
    return datasource;
}

db.getCollection('metadata').find({}).forEach(function (metadata) {
    metadata = processContext(metadata);
    if (config.cleanup.doCleanup) {
        db.getCollection('metadata').save(metadata);
    }
});
