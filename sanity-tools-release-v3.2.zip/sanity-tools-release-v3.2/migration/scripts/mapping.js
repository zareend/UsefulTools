var migrationConfig = {
    set: 'set',
    setPrefix: 'Set/',
    setSuffix: '_SET',
    localhost: 'LocalHost',
    servers: [],
    cubesList: [

    ],
    dictionary: {
        strStart: 'a',
        slash: '_a',
        dot: 'LgAa',
        underscore: 'wAa'
    },
    template: {
        dashboard:{
            "title" : "YalagoDeposits", // cubeName
            "fullname" : "10.13.8.110/YalagoDeposits", // server + / + cubeName
            "id" : "a10LgAa13LgAa8LgAa110_aYALAGODEPOSITS", // generated with dictionary
            "address" : "10.13.8.110", // server
            "database" : "aYalagoDeposits" // a + cubeName
        }
    }
};
var rolesMap = {
    super: {
        old: ObjectId(),
        new: ObjectId(),
    },
    admin: {
        old: ObjectId(),
        new: ObjectId(),
    },
    consumer: {
        old: ObjectId(),
        new: ObjectId(),
    },
    contributor: {
        old: ObjectId(),
        new: ObjectId(),
    },
    dataAdmin: {
        old: ObjectId(),
        new: ObjectId(),
    },
    dataDesigner: {
        old: ObjectId(),
        new: ObjectId(),
    }
};
var nameMapping = {
    "Set/Usage Analytics Model Set" : "LocalHost/Usage Analytics Model",
    "Set/ContactCentreAnalytics_SET" : "LocalHost/ContactCentreAnalytics",
    "10.13.8.110/ContactCentreAnalytics" : "LocalHost/ContactCentreAnalytics",
    "10.13.5.82/Yalago" : "LocalHost/Yalago",
    "Set/YalagoOverride_SET" : "LocalHost/YalagoOverride",
    "Set/Yalago_SET" : "LocalHost/Yalago",
    "Set/PurchasingManagerSuite_SET" : "LocalHost/PurchasingManagerSuite",
    "Set/yalagoKPIReporting_SET" : "LocalHost/yalagoKPIReporting",
    "Set/BlueEstablishmentMappings_SET" : "LocalHost/BlueEstablishmentMappings",
    "Set/YalagoEstablishmentMappings_SET" : "LocalHost/YalagoEstablishmentMappings",
    "Set/yalagoKPIManual_SET" : "LocalHost/yalagoKPIManual",
    "Set/YalagoOverrideLookup_SET" : "LocalHost/YalagoOverrideLookup",
    "Set/YalagoMapping_SET" : "LocalHost/YalagoMapping",
    "Set/YalagoLoadedHotels_SET" : "LocalHost/YalagoLoadedHotels",
    "Set/RoomMapping_SET" : "LocalHost/RoomMapping",
    "Set/YalagoRoomMapping_SET" : "LocalHost/YalagoRoomMapping",
    "Set/yalagoSearchesNew_SET" : "LocalHost/YalagoSearchesNew",
    "Set/AdminCloudDBUpdateStatus_SET" : "LocalHost/AdminCloudDBUpdateStatus",
    "Set/PPC_TravelRepublic_SET" : "LocalHost/B2CPPC_TravelRepublic",
    "Set/TripAdvisor_TravelRepublic_SET" : "LocalHost/B2CTripadvisor_TravelRepublic",
    "Set/Trivago_TravelRepublic_SET" : "LocalHost/B2CTrivago_TravelRepublic",
    "Set/Searches_TravelRepublic_SET" : "LocalHost/B2CSearches_TravelRepublic",
    "Set/AAPerformance_SET" : "LocalHost/AAPerformance",
    "Set/CustomerRetention_TravelRepublic_SET" : "LocalHost/B2CCustomerRetention_TravelRepublic",
    "Set/TB & NF Performance_SET" : "LocalHost/TB & NF Performance",
    "Set/Sessions_TravelRepublic_SET" : "LocalHost/B2CSessions_TravelRepublic",
    "Set/Searches_dnataTravel_SET" : "LocalHost/B2CSearches_dnataTravel",
    "Set/Corporate Travel_SET" : "LocalHost/Corporate Travel",
    "Set/Bookings_TravelRepublic_SET" : "LocalHost/B2C_TR_Bookings",
    "10.13.5.103/Corporate Travel" : "LocalHost/Corporate Travel",
    "10.13.5.103/Contact Centre Analysis" : "LocalHost/Contact Centre Analysis",
    "10.13.8.110/Contact Centre Analysis" : "LocalHost/Contact Centre Analysis",
    "Set/Contact_Centre_Analysis_SET" : "LocalHost/Contact Centre Analysis",
    "Set/EGIT_data_load_SET" : "LocalHost/EGIT_data_load",
    "Set/Sessions_dnataTravel_SET" : "LocalHost/B2CSessions_dnataTravel",
    "Set/dnata Air_SET" : "LocalHost/Dnata Air",
    "Set/Regional Travel - AUH_SET" : "LocalHost/Regional Travel - AUH",
    "Set/OverrideAir_SET" : "LocalHost/OverrideAir",
    "10.13.5.103/CMSUpload" : "LocalHost/CMSUpload",
    "10.13.5.103/ContactCentre-CSAT" : "LocalHost/ContactCentre-CSAT",
    "Set/Marketdata_PackagePricing_SET" : "LocalHost/PackagePricing",
    "Set/Crisis_Management_Accomodations_SET" : "LocalHost/CrisisManagementAccomodations",
    "Set/Crisis_Management_Flights_SET" : "LocalHost/CrisisManagementFlights",
    "Set/Bookings_NetFlights_SET" : "LocalHost/B2C_NF_Bookings",
    "10.13.5.103/ContactCentre-CSRPerAgent" : "LocalHost/ContactCentre-CSRPerAgent",
    "10.13.8.110/ContactCentre-CSRPerAgent" : "LocalHost/ContactCentre-CSRPerAgent",
    "Set/Erosions_TravelRepublic_SET" : "LocalHost/B2CErosion_TravelRepublic",
    "Set/ProjectBooster_SET" : "LocalHost/Project Booster",
    "10.13.8.110/Corporate Travel" : "LocalHost/Corporate Travel",
    "Set/C0_TravelRepublic_SET" : "LocalHost/B2C_TR_C0",
    "LocalHost/NF_TodaysBookings_FC" : "LocalHost/NF_TodaysBookings_FC",
    "LocalHost/NF_Daily_Bookings" : "LocalHost/NF_Daily_Bookings",
    "LocalHost/NF_Daily_Target" : "LocalHost/NF_Daily_Target",
    "10.13.5.103/Yalago" : "LocalHost/Yalago",
    "10.13.8.110/Yalago" : "LocalHost/Yalago",
    "10.13.8.110/B2C_TR_C0" : "LocalHost/B2C_TR_C0",
    "10.13.5.103/B2C_TR_C0" : "LocalHost/B2C_TR_C0",
    "Set/NetFlights_Intraday_SET" : "LocalHost/NetFlights_Intraday",
    "Set/Tropo_SET" : "LocalHost/Tropo",
    "10.13.8.110/dnataTravel_Intraday" : "LocalHost/dnataTravel_Intraday",
    "LocalHost/Contact Centre Analysis" : "LocalHost/Contact Centre Analysis",
    "Set/ContactCentreCSRPerAgent_SET" : "LocalHost/ContactCentre-CSRPerAgent",
    "LocalHost/ContactCentre-CSRPerAgent" : "LocalHost/ContactCentre-CSRPerAgent",
    "LocalHost/NetFlights_Intraday_MIS" : "LocalHost/NetFlights_Intraday_MIS",
    "LocalHost/TravelRepublic_Intraday" : "LocalHost/TravelRepublic_Intraday",
    "Set/yalagoErosions_Set" : "LocalHost/yalagoErosions",
    "Set/dnataTravel_Intraday_set" : "LocalHost/dnataTravel_Intraday",
    "10.13.8.110/B2C_TR_HotelErrors" : "LocalHost/B2C_TR_HotelErrors",
    "10.13.5.82/B2C_TR_HotelErrors" : "LocalHost/B2C_TR_HotelErrors",
    "LocalHost/B2C_TR_HotelErrors" : "LocalHost/B2C_TR_HotelErrors",
    "Set/yalagoIntraday_Set" : "LocalHost/yalago_Intraday",
    "10.13.5.82/GoldMedal_Intraday_MIS" : "LocalHost/GoldMedal_Intraday_MIS",
    "10.13.5.82/Travel2_Intraday" : "LocalHost/Travel2_Intraday",
    "Set/B2C_TR_Hotels360_Set" : "LocalHost/B2C_TR_Hotels360",
    "10.13.5.103/Regional Travel - India" : "LocalHost/Regional Travel - India",
    "LocalHost/Yalago" : "LocalHost/Yalago",
    "10.13.5.82/ContactCentre-CSRPerAgent" : "LocalHost/ContactCentre-CSRPerAgent",
    "10.13.5.103/GoldMedal_Intraday_MIS" : "LocalHost/GoldMedal_Intraday_MIS",
    "10.13.5.82/Regional Travel - India" : "LocalHost/Regional Travel - India",
    "10.13.5.103/B2C_TR_Hotels360" : "LocalHost/B2C_TR_Hotels360",
    "10.13.8.110/B2C_TR_Hotels360" : "LocalHost/B2C_TR_Hotels360",
    "Set/B2C_TR_Hotels360" : "LocalHost/B2C_TR_Hotels360",
    "10.13.8.110/B2C_TR_Bookings" : "LocalHost/B2C_TR_Bookings",
    "10.13.5.103/B2C_TR_Bookings" : "LocalHost/B2C_TR_Bookings",
    "Set/AAPerformance" : "LocalHost/AAPerformance",
    "10.13.5.103/AAPerformance" : "LocalHost/AAPerformance",
    "10.13.8.110/AAPerformance" : "LocalHost/AAPerformance",
    "RoomMapping_SET/RoomMapping" : "LocalHost/RoomMapping",
    "10.13.8.110/CrisisManagementFlights" : "LocalHost/CrisisManagementFlights",
    "10.13.5.103/CrisisManagementFlights" : "LocalHost/CrisisManagementFlights",
    "10.13.8.110/ContactCentre-CSRPerAgentV2" : "LocalHost/ContactCentre-CSRPerAgentV2",
    "10.13.5.82/YalagoDeposits" : "LocalHost/YalagoDeposits",
    "10.13.8.110/ContactCentre-CSAT" : "LocalHost/ContactCentre-CSAT",
    "10.13.8.110/CrisisManagementAccomodations" : "LocalHost/CrisisManagementAccomodations",
    "Set/Regional Travel - India_Set" : "LocalHost/Regional Travel - India",
    "10.13.5.103/CrisisManagementAccomodations" : "LocalHost/CrisisManagementAccomodations",
    "Set/Regional Travel - India v2 - SET" : "LocalHost/Regional Travel - India v2",
    "10.13.5.82/YalagoMappingV2" : "LocalHost/YalagoMappingV2",
    "10.13.8.110/Regional Travel - India v2" : "LocalHost/Regional Travel - India v2",
    "10.13.5.103/TravelRepublic_Intraday" : "LocalHost/TravelRepublic_Intraday",
    "10.13.8.110/TravelRepublic_Intraday" : "LocalHost/TravelRepublic_Intraday",
    "Set/Air Bsp Regions_SET" : "LocalHost/Air Bsp Regions",
    "10.13.5.82/AAPerformance" : "LocalHost/AAPerformance",
    "10.13.5.82/Corporate Travel" : "LocalHost/Corporate Travel",
    "10.13.5.103/YalagoDeposits" : "LocalHost/YalagoDeposits",
    "10.13.8.110/YalagoDeposits" : "LocalHost/YalagoDeposits",
    "Set/WebsitePerformance_SET" : "LocalHost/WebsitePerformance",
    "Set/B2CSessions_dnataTravelv2_Set" : "LocalHost/B2CSessions_dnataTravel v2",
    "Set/dnataTravel_Test2_SET" : "LocalHost/dnataTravel_Test2",
    "10.13.5.82/Contact Centre Analysis" : "LocalHost/Contact Centre Analysis",
    "Set/dnataTravel_Bookings_SET" : "LocalHost/dnataTravel_Bookings",
    "Set/TravelBag_Intraday_SET" : "LocalHost/TravelBag_Intraday_MIS",
    "Set/B2C_TB_Bookings_SET" : "LocalHost/B2C_TB_Bookings",
    "10.13.5.82/B2C_TR_Bookings" : "LocalHost/B2C_TR_Bookings",
    "Set/YalagoEstablishmentStatus_SET" : "LocalHost/YalagoEstablishmentStatus",
    "10.13.5.82/Dnata Air" : "LocalHost/Dnata Air",
    "10.13.5.82/NetFlights_Intraday" : "LocalHost/NetFlights_Intraday",
    "10.13.5.82/PurchasingManagerSuite" : "LocalHost/PurchasingManagerSuite",
    "10.13.5.82/B2C_TR_C0" : "LocalHost/B2C_TR_C0",
    "10.13.5.103/NetFlights_Intraday" : "LocalHost/NetFlights_Intraday",
    "10.13.8.110/PurchasingManagerSuite" : "LocalHost/PurchasingManagerSuite",
    "10.13.8.110/B2CSessions_TravelRepublic" : "LocalHost/B2CSessions_TravelRepublic",
    "10.13.5.103/Dnata Air" : "LocalHost/Dnata Air",
    "10.13.5.103/PurchasingManagerSuite" : "LocalHost/PurchasingManagerSuite",
    "10.13.5.82/ContactCentre-CSAT" : "LocalHost/ContactCentre-CSAT",
    "10.13.5.82/TravelRepublic_Intraday" : "LocalHost/TravelRepublic_Intraday",
    "10.13.8.110/B2CSearches_TravelRepublic" : "LocalHost/B2CSearches_TravelRepublic",
    "10.13.5.82/B2CSearches_TravelRepublic" : "LocalHost/B2CSearches_TravelRepublic",
    "Set/CCPerformanceSummary_SET" : "LocalHost/CCPerformanceSummary",
    "Set/Corporate Customer Transaction_SET" : "LocalHost/Corporate Customer Transaction",
    "10.13.5.82/CCPerformanceSummary" : "LocalHost/CCPerformanceSummary",
    "10.13.8.110/CCPerformanceSummary" : "LocalHost/CCPerformanceSummary"
};
var idMapping = {
    "5bc70a18d70619200c68bd77" : "5ed1631f2bfcc1d7b9d22897",
    "5bcd96130171522be0d681da" : "5ed163152bfcc1d7b9d225d8",
    "5bced583f2bae0028c75fbc8" : "5ed163052bfcc1d7b9d221e9",
    "5bd1627c3fddac50dc55911c" : "5ed1631b2bfcc1d7b9d227ae",
    "5bd178243fddac50dc5593b4" : "5ed162ee2bfcc1d7b9d21d0a",
    "5bd1784c3fddac50dc5593c3" : "5ed163182bfcc1d7b9d226ed",
    "5bd1853a3fddac50dc559541" : "5ed1631a2bfcc1d7b9d2277e",
    "5bd748675f926321343e4a60" : "5ed163212bfcc1d7b9d228f2",
    "5bd807de5f926321343e501d" : "5ed1631d2bfcc1d7b9d2281e",
    "5bd81add5f926321343e5264" : "5ed1631c2bfcc1d7b9d227f7",
    "5bd83a645f926321343e55c3" : "5ed1630d2bfcc1d7b9d2241d",
    "5bd856e15f926321343e58ac" : "5ed163222bfcc1d7b9d2291a",
    "5bdacc419a72a209d0696d4b" : '5ed163232bfcc1d7b9d22969',
    "5be9867281af5d2ab42c1bf3" : "5ed162d22bfcc1d7b9d21458",
    "5bf6b92f39802120e01de96c" : "5ed162d72bfcc1d7b9d215a5",
    "5bf6b98f39802120e01de97b" : "5ed162de2bfcc1d7b9d217da",
    "5bf6b9d239802120e01de989" : "5ed162df2bfcc1d7b9d21829",
    "5c0121c3cb1a442744cf989a" : "5ed162d92bfcc1d7b9d21631",
    "5c04ca964d82f106dc76249d" : "5ed162aa2bfcc1d7b9d2114f",
    "5c0fa053a5e3ad1cc0430adf" : "5ed162d52bfcc1d7b9d21533",
    "5c0fa0d8a5e3ad1cc0430d9f" : "5ed163102bfcc1d7b9d224b5",
    "5c13958b1ef45e02b07a269b" : "5ed162db2bfcc1d7b9d2171a",
    "5c3dfb62a4e7f3043ce642f4" : "5ed162d82bfcc1d7b9d215eb",
    "5c485ef0f9b2b32a90420b75" : "5ed162f62bfcc1d7b9d21e6b",
    "5c48d74df2276e1c10cf8795" : "5ed162ea2bfcc1d7b9d21b5d",
    "5c49a2cfa200d6e6c04221af" : "5ed162f62bfcc1d7b9d21e6b",
    "5c4e9ed59cc4aa1dc8a6e1bc" : "5ed162f02bfcc1d7b9d21d74",
    "5c4e9f079cc4aa1dc8a6e1d0" : "5ed162f02bfcc1d7b9d21d74",
    "5c4e9f349cc4aa1dc8a6e1dd" : "5ed162f02bfcc1d7b9d21d74",
    "5c50001eeb5add23302efded" : "5ed162fe2bfcc1d7b9d220a0",
    "5c5c3885a48a602fd02bcffe" : "5ed162da2bfcc1d7b9d216d9",
    "5c6520afad5cf824ec8d98f9" : "5ed162f92bfcc1d7b9d21f41",
    "5c652871ad5cf824ec8da8ec" : "5ed163072bfcc1d7b9d222a2",
    "5c74e5afc0a54c298c941c87" : "5ed163022bfcc1d7b9d22160",
    "5c7df2f4d83da625783bab75" : "5ed162ef2bfcc1d7b9d21d51",
    "5c7df317d83da625783bab7d" : "5ed162f12bfcc1d7b9d21da2",
    "5c80db6150e6801f4cb3aa43" : "5ed163032bfcc1d7b9d22199",
    "5ca0a5a5b06e69182cc2e8bb" : "5ed162f72bfcc1d7b9d21ee5",
    "5ca0a687b06e69182cc2e93d" : "5ed162f82bfcc1d7b9d21f1c",
    "5caf014e0cd6c6212040650a" : "5ed162e52bfcc1d7b9d21a50",
    "5cc00dc5ec60101cb8b5f3b4" : "5ed162f22bfcc1d7b9d21de1",
    "5cc83603248275024803125f" : "5ed162f22bfcc1d7b9d21de1",
    "5cd1afb091808404500d84db" : "5ed162d62bfcc1d7b9d21573",
    "5cda9598959d5e1b08b57edf" : "5ed163042bfcc1d7b9d221c3",
    "5cf8806e56b643f1c385a402" : "5ed162f62bfcc1d7b9d21e6b",
    "5d017d33ff403c1b289f8b6d" : "5ed162eb2bfcc1d7b9d21c4e",
    "5d0816de48a50f2bc8132ce9" : "5ed171102bfcc1d7b9d305e1",
    "5d0816de48a50f2bc8132ced" : "5ed171302bfcc1d7b9d3092a",
    "5d0816de48a50f2bc8132ceb" : "5ed171212bfcc1d7b9d3079f",
    "5d2551d5d9e3f26da7f1f1ab" : "5ed163152bfcc1d7b9d225d8",
    "5d2551d8d9e3f26da7f1f403" : "5ed163152bfcc1d7b9d225d8",
    "5d361713f0e0f72076977640" : "5ed162eb2bfcc1d7b9d21c4e",
    "5d361750f0e0f72076977e87" : "5ed162eb2bfcc1d7b9d21c4e",
    "5d3a275057bf6412289ce3d2" : "5ed163002bfcc1d7b9d220f2",
    "5d5bd6c0d5515b1f7ce365ea" : "5ed163132bfcc1d7b9d2255d",
    "5d6b6ab7cd6a761dccbbe3e4" : "5ed162fb2bfcc1d7b9d22005",
    "5d7dde47a844fa1444734a7f" : "5ed162f02bfcc1d7b9d21d74",
    "5d7ded0024e6e110d849c4d5" : "5ed162f22bfcc1d7b9d21de1",
    "5d80a1059f9c2921c0e80f58" : "5ed162f22bfcc1d7b9d21de1",
    "5d8a4878b74d301fa45328b5" : "5ed163012bfcc1d7b9d22130",
    "5da63c8832371c0e58f18b9e" : "5ed163122bfcc1d7b9d2253d",
    "5da82ccb32371c0e58f226f7" : "5ed163172bfcc1d7b9d226a8",
    "5db06b3343346913480e9cca" : "5ed162fb2bfcc1d7b9d22005",
    "5dc2e4624be51c0a28f5589b" : "5ed162ec2bfcc1d7b9d21c7f",
    "5dc2e4784be51c0a28f5589c" : "5ed162ec2bfcc1d7b9d21c7f",
    "5dc2e5d94be51c0a28f5589e" : "5ed162ec2bfcc1d7b9d21c7f",
    "5dd23d8a049bc21a3033fedd" : "5ed163242bfcc1d7b9d229c1",
    "5df0bee7cf690b1df46db495" : "5ed162ff2bfcc1d7b9d220c7",
    "5df0bf26cf690b1df46db496" : "5ed163112bfcc1d7b9d224f4",
    "5e01f56b97d4d31e382aaa65" : "5ed162ed2bfcc1d7b9d21cca",
    "5e03520569cd6c1ab0533d0e" : "5ed1630a2bfcc1d7b9d2233d",
    "5e1547dc22749d1414147e66" : "5ed163152bfcc1d7b9d225d8",
    "5e1afce87f6a325543589fea" : "5ed162f22bfcc1d7b9d21de1",
    "5e1d5d2cf8c8aa142463e455" : "5ed162ff2bfcc1d7b9d220c7",
    "5e1da77b7f6a32554310d707" : "5ed1630a2bfcc1d7b9d2233d",
    "5e241198f81efd1ffc7209b0" : "5ed162ed2bfcc1d7b9d21cca",
    "5e2411aef81efd1ffc7209b1" : "5ed162ed2bfcc1d7b9d21cca",
    "5e243aa3a085212104f31fa0" : "5ed162ed2bfcc1d7b9d21cca",
    "5e26d36e07daffd5090ea340" : "5ed162ea2bfcc1d7b9d21b5d",
    "5e26d75907daffd5091071a6" : "5ed162ea2bfcc1d7b9d21b5d",
    "5e27d9d1f81efd1ffc725517" : "5ed162aa2bfcc1d7b9d2114f",
    "5e27d9f37efe672114d770e8" : "5ed162aa2bfcc1d7b9d2114f",
    "5e27da027efe672114d770ea" : "5ed162aa2bfcc1d7b9d2114f",
    "5e282ad3f81efd1ffc72666b" : "5ed1630d2bfcc1d7b9d2241d",
    "5e2d378cd0620454033669bb" : "5ed162f82bfcc1d7b9d21f1c",
    "5e2d37dcd062045403367c33" : "5ed162f82bfcc1d7b9d21f1c",
    "5e2d6522d062045403468f4d" : "5ed162f42bfcc1d7b9d21e14",
    "5e2ec969329adf1ca0fc2754" : "5ed163162bfcc1d7b9d2265a",
    "5e48cbb52420861dd4288d8a" : "5ed162f12bfcc1d7b9d21da2",
    "5e490dc724a8421e76bf2471" : "5ed162f72bfcc1d7b9d21ee5",
    "5e4a73921b70ff1e8c142330" : "5ed1630a2bfcc1d7b9d2233d",
    "5e5f5cd97a26282ca137dab6" : "5ed162f72bfcc1d7b9d21ee5",
    "5e64b726ac60d21e1447647a" : "5ed163092bfcc1d7b9d222f4",
    "5e69c1805ee34a1da0834ecb" : "5ed1631e2bfcc1d7b9d22841",
    "5e6a1619c6a703e7d3dfe410" : "5ed163092bfcc1d7b9d222f4",
    "5e70b8b652f42a1db088ff86" : "5ed163122bfcc1d7b9d2253d",
    "5e70b8d82155281c84ff79bd" : "5ed163122bfcc1d7b9d2253d",
    "5e71fb9052f42a1db0890f03" : "5ed162d32bfcc1d7b9d21481",
    "5e79e3ed84f4af7163ea25d8" : "5ed162aa2bfcc1d7b9d2114f",
    "5e7b540c84f4af71633f1727" : "5ed162f62bfcc1d7b9d21e6b",
    "5e82cf7dc3f6ec1d7043605f" : "5ed163162bfcc1d7b9d2265a",
    "5e82cf917bff3c137ca0fd21" : "5ed163162bfcc1d7b9d2265a",
    "5e8318947bff3c137ca10170" : "5ed163142bfcc1d7b9d225a4",
    "5e838dafc3f6ec1d70437f9f" : "5ed162da2bfcc1d7b9d2167a",
    "5e8438517bff3c137ca10ac4" : "5ed162fd2bfcc1d7b9d22045",
    "5e85cbb2531231b3c7a09c37" : "5ed162f02bfcc1d7b9d21d74",
    "5e8b1d245438c61cc875c403" : "5ed162fa2bfcc1d7b9d21f9a",
    "5e8c39ce5438c61cc875f83c" : "5ed163122bfcc1d7b9d22517",
    "5e8c3e5f5438c61cc875fc83" : "5ed162e72bfcc1d7b9d21aba",
    "5e8d647cca459b91ecd3b213" : "5ed162ea2bfcc1d7b9d21b5d",
    "5e8eb47cc8eac81e6ced3577" : "5ed163192bfcc1d7b9d22710",
    "5e94ce043d035ded4b99aa12" : "5ed162f92bfcc1d7b9d21f41",
    "5e94ce323d035ded4b99bab7" : "5ed163002bfcc1d7b9d220f2",
    "5e94ce503d035ded4b99be07" : "5ed163052bfcc1d7b9d221e9",
    "5e95ad0c3d035ded4bce16fc" : "5ed162eb2bfcc1d7b9d21c4e",
    "5e95b08f3d035ded4bcef356" : "5ed163002bfcc1d7b9d220f2",
    "5e95b1933d035ded4bcf2c4c" : "5ed163052bfcc1d7b9d221e9",
    "5e9850b83d035ded4b6ccbfa" : "5ed162db2bfcc1d7b9d2171a",
    "5e9888623d035ded4b7a151a" : "5ed162f92bfcc1d7b9d21f41",
    "5e9b02863d035ded4bf07294" : "5ed163052bfcc1d7b9d221e9",
    "5e9ea6ad09d547d413f7aecd" : "5ed162f12bfcc1d7b9d21da2",
    "5ea02f445bbd961d30938265" : "5ed163122bfcc1d7b9d2253d",
    "5ea0a0b109d547d4139ce99a" : "5ed162d92bfcc1d7b9d21631",
    "5ea6dc08062dea922e70917e" : "5ed162d92bfcc1d7b9d21631",
    "5eaabc49a7db8c03b838e873" : "5ed162ef2bfcc1d7b9d21d28",
    "5eb11c89517d1d0588213764" : "5ed162f52bfcc1d7b9d21e3e",
    "5eb2bb061f0f85d3e672385b" : "5ed162ef2bfcc1d7b9d21d28",
    "5eb2bc821f0f85d3e6728b9a" : "5ed162ef2bfcc1d7b9d21d28"
};

var arrays = [
    {
        'address': 'Set/Usage Analytics Model Set',
        'title': 'Usage Analytics Model',
        'fullname': 'LocalHost/Usage Analytics Model',
        'id': 'localhost_aUsageIAAaAnalyticsIAAaModel'
    },
    {
        'address': 'Set/ContactCentreAnalytics_SET',
        'title': 'ContactCentreAnalytics',
        'fullname': 'LocalHost/ContactCentreAnalytics',
        'id': 'localhost_aContactCentreAnalytics'
    },
    {
        'address': '10.13.8.110/ContactCentreAnalytics',
        'title': 'ContactCentreAnalytics',
        'fullname': 'LocalHost/ContactCentreAnalytics',
        'id': 'localhost_aContactCentreAnalytics'
    },
    {
        'address': '10.13.5.82/Yalago',
        'title': 'Yalago',
        'fullname': 'LocalHost/Yalago',
        'id': 'localhost_aYalago'
    },
    {
        'address': 'Set/YalagoOverride_SET',
        'title': 'YalagoOverride',
        'fullname': 'LocalHost/YalagoOverride',
        'id': 'localhost_aYalagoOverride'
    },
    {
        'address': 'Set/Yalago_SET',
        'title': 'Yalago',
        'fullname': 'LocalHost/Yalago',
        'id': 'localhost_aYalago'
    },
    {
        'address': 'Set/PurchasingManagerSuite_SET',
        'title': 'PurchasingManagerSuite',
        'fullname': 'LocalHost/PurchasingManagerSuite',
        'id': 'localhost_aPurchasingManagerSuite'
    },
    {
        'address': 'Set/yalagoKPIReporting_SET',
        'title': 'yalagoKPIReporting',
        'fullname': 'LocalHost/yalagoKPIReporting',
        'id': 'localhost_ayalagoKPIReporting'
    },
    {
        'address': 'Set/BlueEstablishmentMappings_SET',
        'title': 'BlueEstablishmentMappings',
        'fullname': 'LocalHost/BlueEstablishmentMappings',
        'id': 'localhost_aBlueEstablishmentMappings'
    },
    {
        'address': 'Set/YalagoEstablishmentMappings_SET',
        'title': 'YalagoEstablishmentMappings',
        'fullname': 'LocalHost/YalagoEstablishmentMappings',
        'id': 'localhost_aYalagoEstablishmentMappings'
    },
    {
        'address': 'Set/yalagoKPIManual_SET',
        'title': 'yalagoKPIManual',
        'fullname': 'LocalHost/yalagoKPIManual',
        'id': 'localhost_ayalagoKPIManual'
    },
    {
        'address': 'Set/YalagoOverrideLookup_SET',
        'title': 'YalagoOverrideLookup',
        'fullname': 'LocalHost/YalagoOverrideLookup',
        'id': 'localhost_aYalagoOverrideLookup'
    },
    {
        'address': 'Set/YalagoMapping_SET',
        'title': 'YalagoMapping',
        'fullname': 'LocalHost/YalagoMapping',
        'id': 'localhost_aYalagoMapping'
    },
    {
        'address': 'Set/YalagoLoadedHotels_SET',
        'title': 'YalagoLoadedHotels',
        'fullname': 'LocalHost/YalagoLoadedHotels',
        'id': 'localhost_aYalagoLoadedHotels'
    },
    {
        'address': 'Set/RoomMapping_SET',
        'title': 'RoomMapping',
        'fullname': 'LocalHost/RoomMapping',
        'id': 'localhost_aRoomMapping'
    },
    {
        'address': 'Set/YalagoRoomMapping_SET',
        'title': 'YalagoRoomMapping',
        'fullname': 'LocalHost/YalagoRoomMapping',
        'id': 'localhost_aYalagoRoomMapping'
    },
    {
        'address': 'Set/yalagoSearchesNew_SET',
        'title': 'YalagoSearchesNew',
        'fullname': 'LocalHost/YalagoSearchesNew',
        'id': 'localhost_aYalagoSearchesNew'
    },
    {
        'address': 'Set/AdminCloudDBUpdateStatus_SET',
        'title': 'AdminCloudDBUpdateStatus',
        'fullname': 'LocalHost/AdminCloudDBUpdateStatus',
        'id': 'localhost_aAdminCloudDBUpdateStatus'
    },
    {
        'address': 'Set/PPC_TravelRepublic_SET',
        'title': 'B2CPPC_TravelRepublic',
        'fullname': 'LocalHost/B2CPPC_TravelRepublic',
        'id': 'localhost_aB2CPPCXwAaTravelRepublic'
    },
    {
        'address': 'Set/TripAdvisor_TravelRepublic_SET',
        'title': 'B2CTripadvisor_TravelRepublic',
        'fullname': 'LocalHost/B2CTripadvisor_TravelRepublic',
        'id': 'localhost_aB2CTripadvisorXwAaTravelRepublic'
    },
    {
        'address': 'Set/Trivago_TravelRepublic_SET',
        'title': 'B2CTrivago_TravelRepublic',
        'fullname': 'LocalHost/B2CTrivago_TravelRepublic',
        'id': 'localhost_aB2CTrivagoXwAaTravelRepublic'
    },
    {
        'address': 'Set/Searches_TravelRepublic_SET',
        'title': 'B2CSearches_TravelRepublic',
        'fullname': 'LocalHost/B2CSearches_TravelRepublic',
        'id': 'localhost_aB2CSearchesXwAaTravelRepublic'
    },
    {
        'address': 'Set/AAPerformance_SET',
        'title': 'AAPerformance',
        'fullname': 'LocalHost/AAPerformance',
        'id': 'localhost_aAAPerformance'
    },
    {
        'address': 'Set/CustomerRetention_TravelRepublic_SET',
        'title': 'B2CCustomerRetention_TravelRepublic',
        'fullname': 'LocalHost/B2CCustomerRetention_TravelRepublic',
        'id': 'localhost_aB2CCustomerRetentionXwAaTravelRepublic'
    },
    {
        'address': 'Set/TB & NF Performance_SET',
        'title': 'TB & NF Performance',
        'fullname': 'LocalHost/TB & NF Performance',
        'id': 'localhost_aTBIAAaJgAaIAAaNFIAAaPerformance'
    },
    {
        'address': 'Set/Sessions_TravelRepublic_SET',
        'title': 'B2CSessions_TravelRepublic',
        'fullname': 'LocalHost/B2CSessions_TravelRepublic',
        'id': 'localhost_aB2CSessionsXwAaTravelRepublic'
    },
    {
        'address': 'Set/Searches_dnataTravel_SET',
        'title': 'B2CSearches_dnataTravel',
        'fullname': 'LocalHost/B2CSearches_dnataTravel',
        'id': 'localhost_aB2CSearchesXwAadnataTravel'
    },
    {
        'address': 'Set/Corporate Travel_SET',
        'title': 'Corporate Travel',
        'fullname': 'LocalHost/Corporate Travel',
        'id': 'localhost_aCorporateIAAaTravel'
    },
    {
        'address': 'Set/Bookings_TravelRepublic_SET',
        'title': 'B2C_TR_Bookings',
        'fullname': 'LocalHost/B2C_TR_Bookings',
        'id': 'localhost_aB2CXwAaTRXwAaBookings'
    },
    {
        'address': '10.13.5.103/Corporate Travel',
        'title': 'Corporate Travel',
        'fullname': 'LocalHost/Corporate Travel',
        'id': 'localhost_aCorporateIAAaTravel'
    },
    {
        'address': '10.13.5.103/Contact Centre Analysis',
        'title': 'Contact Centre Analysis',
        'fullname': 'LocalHost/Contact Centre Analysis',
        'id': 'localhost_aContactIAAaCentreIAAaAnalysis'
    },
    {
        'address': '10.13.8.110/Contact Centre Analysis',
        'title': 'Contact Centre Analysis',
        'fullname': 'LocalHost/Contact Centre Analysis',
        'id': 'localhost_aContactIAAaCentreIAAaAnalysis'
    },
    {
        'address': 'Set/Contact_Centre_Analysis_SET',
        'title': 'Contact Centre Analysis',
        'fullname': 'LocalHost/Contact Centre Analysis',
        'id': 'localhost_aContactIAAaCentreIAAaAnalysis'
    },
    {
        'address': 'Set/EGIT_data_load_SET',
        'title': 'EGIT_data_load',
        'fullname': 'LocalHost/EGIT_data_load',
        'id': 'localhost_aEGITXwAadataXwAaload'
    },
    {
        'address': 'Set/Sessions_dnataTravel_SET',
        'title': 'B2CSessions_dnataTravel',
        'fullname': 'LocalHost/B2CSessions_dnataTravel',
        'id': 'localhost_aB2CSessionsXwAadnataTravel'
    },
    {
        'address': 'Set/dnata Air_SET',
        'title': 'Dnata Air',
        'fullname': 'LocalHost/Dnata Air',
        'id': 'localhost_aDnataIAAaAir'
    },
    {
        'address': 'Set/Regional Travel - AUH_SET',
        'title': 'Regional Travel - AUH',
        'fullname': 'LocalHost/Regional Travel - AUH',
        'id': 'localhost_aRegionalIAAaTravelIAAaLQAaIAAaAUH'
    },
    {
        'address': 'Set/OverrideAir_SET',
        'title': 'OverrideAir',
        'fullname': 'LocalHost/OverrideAir',
        'id': 'localhost_aOverrideAir'
    },
    {
        'address': '10.13.5.103/CMSUpload',
        'title': 'CMSUpload',
        'fullname': 'LocalHost/CMSUpload',
        'id': 'localhost_aCMSUpload'
    },
    {
        'address': '10.13.5.103/ContactCentre-CSAT',
        'title': 'ContactCentre-CSAT',
        'fullname': 'LocalHost/ContactCentre-CSAT',
        'id': 'localhost_aContactCentreLQAaCSAT'
    },
    {
        'address': 'Set/Marketdata_PackagePricing_SET',
        'title': 'PackagePricing',
        'fullname': 'LocalHost/PackagePricing',
        'id': 'localhost_aPackagePricing'
    },
    {
        'address': 'Set/Crisis_Management_Accomodations_SET',
        'title': 'CrisisManagementAccomodations',
        'fullname': 'LocalHost/CrisisManagementAccomodations',
        'id': 'localhost_aCrisisManagementAccomodations'
    },
    {
        'address': 'Set/Crisis_Management_Flights_SET',
        'title': 'CrisisManagementFlights',
        'fullname': 'LocalHost/CrisisManagementFlights',
        'id': 'localhost_aCrisisManagementFlights'
    },
    {
        'address': 'Set/Bookings_NetFlights_SET',
        'title': 'B2C_NF_Bookings',
        'fullname': 'LocalHost/B2C_NF_Bookings',
        'id': 'localhost_aB2CXwAaNFXwAaBookings'
    },
    {
        'address': '10.13.5.103/ContactCentre-CSRPerAgent',
        'title': 'ContactCentre-CSRPerAgent',
        'fullname': 'LocalHost/ContactCentre-CSRPerAgent',
        'id': 'localhost_aContactCentreLQAaCSRPerAgent'
    },
    {
        'address': '10.13.8.110/ContactCentre-CSRPerAgent',
        'title': 'ContactCentre-CSRPerAgent',
        'fullname': 'LocalHost/ContactCentre-CSRPerAgent',
        'id': 'localhost_aContactCentreLQAaCSRPerAgent'
    },
    {
        'address': 'Set/Erosions_TravelRepublic_SET',
        'title': 'B2CErosion_TravelRepublic',
        'fullname': 'LocalHost/B2CErosion_TravelRepublic',
        'id': 'localhost_aB2CErosionXwAaTravelRepublic'
    },
    {
        'address': 'Set/ProjectBooster_SET',
        'title': 'Project Booster',
        'fullname': 'LocalHost/Project Booster',
        'id': 'localhost_aProjectIAAaBooster'
    },
    {
        'address': '10.13.8.110/Corporate Travel',
        'title': 'Corporate Travel',
        'fullname': 'LocalHost/Corporate Travel',
        'id': 'localhost_aCorporateIAAaTravel'
    },
    {
        'address': 'Set/C0_TravelRepublic_SET',
        'title': 'B2C_TR_C0',
        'fullname': 'LocalHost/B2C_TR_C0',
        'id': 'localhost_aB2CXwAaTRXwAaC0'
    },
    {
        'address': 'LocalHost/NF_TodaysBookings_FC',
        'title': 'NF_TodaysBookings_FC',
        'fullname': 'LocalHost/NF_TodaysBookings_FC',
        'id': 'localhost_aNFXwAaTodaysBookingsXwAaFC'
    },
    {
        'address': 'LocalHost/NF_Daily_Bookings',
        'title': 'NF_Daily_Bookings',
        'fullname': 'LocalHost/NF_Daily_Bookings',
        'id': 'localhost_aNFXwAaDailyXwAaBookings'
    },
    {
        'address': 'LocalHost/NF_Daily_Target',
        'title': 'NF_Daily_Target',
        'fullname': 'LocalHost/NF_Daily_Target',
        'id': 'localhost_aNFXwAaDailyXwAaTarget'
    },
    {
        'address': '10.13.5.103/Yalago',
        'title': 'Yalago',
        'fullname': 'LocalHost/Yalago',
        'id': 'localhost_aYalago'
    },
    {
        'address': '10.13.8.110/Yalago',
        'title': 'Yalago',
        'fullname': 'LocalHost/Yalago',
        'id': 'localhost_aYalago'
    },
    {
        'address': '10.13.8.110/B2C_TR_C0',
        'title': 'B2C_TR_C0',
        'fullname': 'LocalHost/B2C_TR_C0',
        'id': 'localhost_aB2CXwAaTRXwAaC0'
    },
    {
        'address': '10.13.5.103/B2C_TR_C0',
        'title': 'B2C_TR_C0',
        'fullname': 'LocalHost/B2C_TR_C0',
        'id': 'localhost_aB2CXwAaTRXwAaC0'
    },
    {
        'address': 'Set/NetFlights_Intraday_SET',
        'title': 'NetFlights_Intraday',
        'fullname': 'LocalHost/NetFlights_Intraday',
        'id': 'localhost_aNetFlightsXwAaIntraday'
    },
    {
        'address': 'Set/Tropo_SET',
        'title': 'Tropo',
        'fullname': 'LocalHost/Tropo',
        'id': 'localhost_aTropo'
    },
    {
        'address': '10.13.8.110/dnataTravel_Intraday',
        'title': 'dnataTravel_Intraday',
        'fullname': 'LocalHost/dnataTravel_Intraday',
        'id': 'localhost_adnataTravelXwAaIntraday'
    },
    {
        'address': 'LocalHost/Contact Centre Analysis',
        'title': 'Contact Centre Analysis',
        'fullname': 'LocalHost/Contact Centre Analysis',
        'id': 'localhost_aContactIAAaCentreIAAaAnalysis'
    },
    {
        'address': 'Set/ContactCentreCSRPerAgent_SET',
        'title': 'ContactCentre-CSRPerAgent',
        'fullname': 'LocalHost/ContactCentre-CSRPerAgent',
        'id': 'localhost_aContactCentreLQAaCSRPerAgent'
    },
    {
        'address': 'LocalHost/ContactCentre-CSRPerAgent',
        'title': 'ContactCentre-CSRPerAgent',
        'fullname': 'LocalHost/ContactCentre-CSRPerAgent',
        'id': 'localhost_aContactCentreLQAaCSRPerAgent'
    },
    {
        'address': 'LocalHost/NetFlights_Intraday_MIS',
        'title': 'NetFlights_Intraday_MIS',
        'fullname': 'LocalHost/NetFlights_Intraday_MIS',
        'id': 'localhost_aNetFlightsXwAaIntradayXwAaMIS'
    },
    {
        'address': 'LocalHost/TravelRepublic_Intraday',
        'title': 'TravelRepublic_Intraday',
        'fullname': 'LocalHost/TravelRepublic_Intraday',
        'id': 'localhost_aTravelRepublicXwAaIntraday'
    },
    {
        'address': 'Set/yalagoErosions_Set',
        'title': 'yalagoErosions',
        'fullname': 'LocalHost/yalagoErosions',
        'id': 'localhost_ayalagoErosions'
    },
    {
        'address': 'Set/dnataTravel_Intraday_set',
        'title': 'dnataTravel_Intraday',
        'fullname': 'LocalHost/dnataTravel_Intraday',
        'id': 'localhost_adnataTravelXwAaIntraday'
    },
    {
        'address': '10.13.8.110/B2C_TR_HotelErrors',
        'title': 'B2C_TR_HotelErrors',
        'fullname': 'LocalHost/B2C_TR_HotelErrors',
        'id': 'localhost_aB2CXwAaTRXwAaHotelErrors'
    },
    {
        'address': '10.13.5.82/B2C_TR_HotelErrors',
        'title': 'B2C_TR_HotelErrors',
        'fullname': 'LocalHost/B2C_TR_HotelErrors',
        'id': 'localhost_aB2CXwAaTRXwAaHotelErrors'
    },
    {
        'address': 'LocalHost/B2C_TR_HotelErrors',
        'title': 'B2C_TR_HotelErrors',
        'fullname': 'LocalHost/B2C_TR_HotelErrors',
        'id': 'localhost_aB2CXwAaTRXwAaHotelErrors'
    },
    {
        'address': 'Set/yalagoIntraday_Set',
        'title': 'yalago_Intraday',
        'fullname': 'LocalHost/yalago_Intraday',
        'id': 'localhost_ayalagoXwAaIntraday'
    },
    {
        'address': '10.13.5.82/GoldMedal_Intraday_MIS',
        'title': 'GoldMedal_Intraday_MIS',
        'fullname': 'LocalHost/GoldMedal_Intraday_MIS',
        'id': 'localhost_aGoldMedalXwAaIntradayXwAaMIS'
    },
    {
        'address': '10.13.5.82/Travel2_Intraday',
        'title': 'Travel2_Intraday',
        'fullname': 'LocalHost/Travel2_Intraday',
        'id': 'localhost_aTravel2XwAaIntraday'
    },
    {
        'address': 'Set/B2C_TR_Hotels360_Set',
        'title': 'B2C_TR_Hotels360',
        'fullname': 'LocalHost/B2C_TR_Hotels360',
        'id': 'localhost_aB2CXwAaTRXwAaHotels360'
    },
    {
        'address': '10.13.5.103/Regional Travel - India',
        'title': 'Regional Travel - India',
        'fullname': 'LocalHost/Regional Travel - India',
        'id': 'localhost_aRegionalIAAaTravelIAAaLQAaIAAaIndia'
    },
    {
        'address': 'LocalHost/Yalago',
        'title': 'Yalago',
        'fullname': 'LocalHost/Yalago',
        'id': 'localhost_aYalago'
    },
    {
        'address': '10.13.5.82/ContactCentre-CSRPerAgent',
        'title': 'ContactCentre-CSRPerAgent',
        'fullname': 'LocalHost/ContactCentre-CSRPerAgent',
        'id': 'localhost_aContactCentreLQAaCSRPerAgent'
    },
    {
        'address': '10.13.5.103/GoldMedal_Intraday_MIS',
        'title': 'GoldMedal_Intraday_MIS',
        'fullname': 'LocalHost/GoldMedal_Intraday_MIS',
        'id': 'localhost_aGoldMedalXwAaIntradayXwAaMIS'
    },
    {
        'address': '10.13.5.82/Regional Travel - India',
        'title': 'Regional Travel - India',
        'fullname': 'LocalHost/Regional Travel - India',
        'id': 'localhost_aRegionalIAAaTravelIAAaLQAaIAAaIndia'
    },
    {
        'address': '10.13.5.103/B2C_TR_Hotels360',
        'title': 'B2C_TR_Hotels360',
        'fullname': 'LocalHost/B2C_TR_Hotels360',
        'id': 'localhost_aB2CXwAaTRXwAaHotels360'
    },
    {
        'address': '10.13.8.110/B2C_TR_Hotels360',
        'title': 'B2C_TR_Hotels360',
        'fullname': 'LocalHost/B2C_TR_Hotels360',
        'id': 'localhost_aB2CXwAaTRXwAaHotels360'
    },
    {
        'address': 'Set/B2C_TR_Hotels360',
        'title': 'B2C_TR_Hotels360',
        'fullname': 'LocalHost/B2C_TR_Hotels360',
        'id': 'localhost_aB2CXwAaTRXwAaHotels360'
    },
    {
        'address': '10.13.8.110/B2C_TR_Bookings',
        'title': 'B2C_TR_Bookings',
        'fullname': 'LocalHost/B2C_TR_Bookings',
        'id': 'localhost_aB2CXwAaTRXwAaBookings'
    },
    {
        'address': '10.13.5.103/B2C_TR_Bookings',
        'title': 'B2C_TR_Bookings',
        'fullname': 'LocalHost/B2C_TR_Bookings',
        'id': 'localhost_aB2CXwAaTRXwAaBookings'
    },
    {
        'address': 'Set/AAPerformance',
        'title': 'AAPerformance',
        'fullname': 'LocalHost/AAPerformance',
        'id': 'localhost_aAAPerformance'
    },
    {
        'address': '10.13.5.103/AAPerformance',
        'title': 'AAPerformance',
        'fullname': 'LocalHost/AAPerformance',
        'id': 'localhost_aAAPerformance'
    },
    {
        'address': '10.13.8.110/AAPerformance',
        'title': 'AAPerformance',
        'fullname': 'LocalHost/AAPerformance',
        'id': 'localhost_aAAPerformance'
    },
    {
        'address': 'RoomMapping_SET/RoomMapping',
        'title': 'RoomMapping',
        'fullname': 'LocalHost/RoomMapping',
        'id': 'localhost_aRoomMapping'
    },
    {
        'address': '10.13.8.110/CrisisManagementFlights',
        'title': 'CrisisManagementFlights',
        'fullname': 'LocalHost/CrisisManagementFlights',
        'id': 'localhost_aCrisisManagementFlights'
    },
    {
        'address': '10.13.5.103/CrisisManagementFlights',
        'title': 'CrisisManagementFlights',
        'fullname': 'LocalHost/CrisisManagementFlights',
        'id': 'localhost_aCrisisManagementFlights'
    },
    {
        'address': '10.13.8.110/ContactCentre-CSRPerAgentV2',
        'title': 'ContactCentre-CSRPerAgentV2',
        'fullname': 'LocalHost/ContactCentre-CSRPerAgentV2',
        'id': 'localhost_aContactCentreLQAaCSRPerAgentV2'
    },
    {
        'address': '10.13.5.82/YalagoDeposits',
        'title': 'YalagoDeposits',
        'fullname': 'LocalHost/YalagoDeposits',
        'id': 'localhost_aYalagoDeposits'
    },
    {
        'address': '10.13.8.110/ContactCentre-CSAT',
        'title': 'ContactCentre-CSAT',
        'fullname': 'LocalHost/ContactCentre-CSAT',
        'id': 'localhost_aContactCentreLQAaCSAT'
    },
    {
        'address': '10.13.8.110/CrisisManagementAccomodations',
        'title': 'CrisisManagementAccomodations',
        'fullname': 'LocalHost/CrisisManagementAccomodations',
        'id': 'localhost_aCrisisManagementAccomodations'
    },
    {
        'address': 'Set/Regional Travel - India_Set',
        'title': 'Regional Travel - India',
        'fullname': 'LocalHost/Regional Travel - India',
        'id': 'localhost_aRegionalIAAaTravelIAAaLQAaIAAaIndia'
    },
    {
        'address': '10.13.5.103/CrisisManagementAccomodations',
        'title': 'CrisisManagementAccomodations',
        'fullname': 'LocalHost/CrisisManagementAccomodations',
        'id': 'localhost_aCrisisManagementAccomodations'
    },
    {
        'address': 'Set/Regional Travel - India v2 - SET',
        'title': 'Regional Travel - India v2',
        'fullname': 'LocalHost/Regional Travel - India v2',
        'id': 'localhost_aRegionalIAAaTravelIAAaLQAaIAAaIndiaIAAav2'
    },
    {
        'address': '10.13.5.82/YalagoMappingV2',
        'title': 'YalagoMappingV2',
        'fullname': 'LocalHost/YalagoMappingV2',
        'id': 'localhost_aYalagoMappingV2'
    },
    {
        'address': '10.13.8.110/Regional Travel - India v2',
        'title': 'Regional Travel - India v2',
        'fullname': 'LocalHost/Regional Travel - India v2',
        'id': 'localhost_aRegionalIAAaTravelIAAaLQAaIAAaIndiaIAAav2'
    },
    {
        'address': '10.13.5.103/TravelRepublic_Intraday',
        'title': 'TravelRepublic_Intraday',
        'fullname': 'LocalHost/TravelRepublic_Intraday',
        'id': 'localhost_aTravelRepublicXwAaIntraday'
    },
    {
        'address': '10.13.8.110/TravelRepublic_Intraday',
        'title': 'TravelRepublic_Intraday',
        'fullname': 'LocalHost/TravelRepublic_Intraday',
        'id': 'localhost_aTravelRepublicXwAaIntraday'
    },
    {
        'address': 'Set/Air Bsp Regions_SET',
        'title': 'Air Bsp Regions',
        'fullname': 'LocalHost/Air Bsp Regions',
        'id': 'localhost_aAirIAAaBspIAAaRegions'
    },
    {
        'address': '10.13.5.82/AAPerformance',
        'title': 'AAPerformance',
        'fullname': 'LocalHost/AAPerformance',
        'id': 'localhost_aAAPerformance'
    },
    {
        'address': '10.13.5.82/Corporate Travel',
        'title': 'Corporate Travel',
        'fullname': 'LocalHost/Corporate Travel',
        'id': 'localhost_aCorporateIAAaTravel'
    },
    {
        'address': '10.13.5.103/YalagoDeposits',
        'title': 'YalagoDeposits',
        'fullname': 'LocalHost/YalagoDeposits',
        'id': 'localhost_aYalagoDeposits'
    },
    {
        'address': '10.13.8.110/YalagoDeposits',
        'title': 'YalagoDeposits',
        'fullname': 'LocalHost/YalagoDeposits',
        'id': 'localhost_aYalagoDeposits'
    },
    {
        'address': 'Set/WebsitePerformance_SET',
        'title': 'WebsitePerformance',
        'fullname': 'LocalHost/WebsitePerformance',
        'id': 'localhost_aWebsitePerformance'
    },
    {
        'address': 'Set/B2CSessions_dnataTravelv2_Set',
        'title': 'B2CSessions_dnataTravel v2',
        'fullname': 'LocalHost/B2CSessions_dnataTravel v2',
        'id': 'localhost_aB2CSessionsXwAadnataTravelIAAav2'
    },
    {
        'address': 'Set/dnataTravel_Test2_SET',
        'title': 'dnataTravel_Test2',
        'fullname': 'LocalHost/dnataTravel_Test2',
        'id': 'localhost_adnataTravelXwAaTest2'
    },
    {
        'address': '10.13.5.82/Contact Centre Analysis',
        'title': 'Contact Centre Analysis',
        'fullname': 'LocalHost/Contact Centre Analysis',
        'id': 'localhost_aContactIAAaCentreIAAaAnalysis'
    },
    {
        'address': 'Set/dnataTravel_Bookings_SET',
        'title': 'dnataTravel_Bookings',
        'fullname': 'LocalHost/dnataTravel_Bookings',
        'id': 'localhost_adnataTravelXwAaBookings'
    },
    {
        'address': 'Set/TravelBag_Intraday_SET',
        'title': 'TravelBag_Intraday_MIS',
        'fullname': 'LocalHost/TravelBag_Intraday_MIS',
        'id': 'localhost_aTravelBagXwAaIntradayXwAaMIS'
    },
    {
        'address': 'Set/B2C_TB_Bookings_SET',
        'title': 'B2C_TB_Bookings',
        'fullname': 'LocalHost/B2C_TB_Bookings',
        'id': 'localhost_aB2CXwAaTBXwAaBookings'
    },
    {
        'address': '10.13.5.82/B2C_TR_Bookings',
        'title': 'B2C_TR_Bookings',
        'fullname': 'LocalHost/B2C_TR_Bookings',
        'id': 'localhost_aB2CXwAaTRXwAaBookings'
    },
    {
        'address': 'Set/YalagoEstablishmentStatus_SET',
        'title': 'YalagoEstablishmentStatus',
        'fullname': 'LocalHost/YalagoEstablishmentStatus',
        'id': 'localhost_aYalagoEstablishmentStatus'
    },
    {
        'address': '10.13.5.82/Dnata Air',
        'title': 'Dnata Air',
        'fullname': 'LocalHost/Dnata Air',
        'id': 'localhost_aDnataIAAaAir'
    },
    {
        'address': '10.13.5.82/NetFlights_Intraday',
        'title': 'NetFlights_Intraday',
        'fullname': 'LocalHost/NetFlights_Intraday',
        'id': 'localhost_aNetFlightsXwAaIntraday'
    },
    {
        'address': '10.13.5.82/PurchasingManagerSuite',
        'title': 'PurchasingManagerSuite',
        'fullname': 'LocalHost/PurchasingManagerSuite',
        'id': 'localhost_aPurchasingManagerSuite'
    },
    {
        'address': '10.13.5.82/B2C_TR_C0',
        'title': 'B2C_TR_C0',
        'fullname': 'LocalHost/B2C_TR_C0',
        'id': 'localhost_aB2CXwAaTRXwAaC0'
    },
    {
        'address': '10.13.5.103/NetFlights_Intraday',
        'title': 'NetFlights_Intraday',
        'fullname': 'LocalHost/NetFlights_Intraday',
        'id': 'localhost_aNetFlightsXwAaIntraday'
    },
    {
        'address': '10.13.8.110/PurchasingManagerSuite',
        'title': 'PurchasingManagerSuite',
        'fullname': 'LocalHost/PurchasingManagerSuite',
        'id': 'localhost_aPurchasingManagerSuite'
    },
    {
        'address': '10.13.8.110/B2CSessions_TravelRepublic',
        'title': 'B2CSessions_TravelRepublic',
        'fullname': 'LocalHost/B2CSessions_TravelRepublic',
        'id': 'localhost_aB2CSessionsXwAaTravelRepublic'
    },
    {
        'address': '10.13.5.103/Dnata Air',
        'title': 'Dnata Air',
        'fullname': 'LocalHost/Dnata Air',
        'id': 'localhost_aDnataIAAaAir'
    },
    {
        'address': '10.13.5.103/PurchasingManagerSuite',
        'title': 'PurchasingManagerSuite',
        'fullname': 'LocalHost/PurchasingManagerSuite',
        'id': 'localhost_aPurchasingManagerSuite'
    },
    {
        'address': '10.13.5.82/ContactCentre-CSAT',
        'title': 'ContactCentre-CSAT',
        'fullname': 'LocalHost/ContactCentre-CSAT',
        'id': 'localhost_aContactCentreLQAaCSAT'
    },
    {
        'address': '10.13.5.82/TravelRepublic_Intraday',
        'title': 'TravelRepublic_Intraday',
        'fullname': 'LocalHost/TravelRepublic_Intraday',
        'id': 'localhost_aTravelRepublicXwAaIntraday'
    },
    {
        'address': '10.13.8.110/B2CSearches_TravelRepublic',
        'title': 'B2CSearches_TravelRepublic',
        'fullname': 'LocalHost/B2CSearches_TravelRepublic',
        'id': 'localhost_aB2CSearchesXwAaTravelRepublic'
    },
    {
        'address': '10.13.5.82/B2CSearches_TravelRepublic',
        'title': 'B2CSearches_TravelRepublic',
        'fullname': 'LocalHost/B2CSearches_TravelRepublic',
        'id': 'localhost_aB2CSearchesXwAaTravelRepublic'
    },
    {
        'address': 'Set/CCPerformanceSummary_SET',
        'title': 'CCPerformanceSummary',
        'fullname': 'LocalHost/CCPerformanceSummary',
        'id': 'localhost_aCCPerformanceSummary'
    },
    {
        'address': 'Set/Corporate Customer Transaction_SET',
        'title': 'Corporate Customer Transaction',
        'fullname': 'LocalHost/Corporate Customer Transaction',
        'id': 'localhost_aCorporateIAAaCustomerIAAaTransaction'
    },
    {
        'address': '10.13.5.82/CCPerformanceSummary',
        'title': 'CCPerformanceSummary',
        'fullname': 'LocalHost/CCPerformanceSummary',
        'id': 'localhost_aCCPerformanceSummary'
    },
    {
        'address': '10.13.8.110/CCPerformanceSummary',
        'title': 'CCPerformanceSummary',
        'fullname': 'LocalHost/CCPerformanceSummary',
        'id': 'localhost_aCCPerformanceSummary'
    }
];
