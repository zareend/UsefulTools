// General Info
var version = '3.1.3';

var count = 0;
var cap = 300;
var prismWebDB = db.getSiblingDB('prismWebDB');
prismWebDB.getCollection('users')
    .find({ ldapDomainId: ObjectId('5bae49f5e08c135428f38d82') })
    .forEach(function (user) {
        count += 1;
        print(count);
        if (count > cap) {
            print('remove' + user.userName);
            db.getCollection('users').remove({ _id: user._id });
        }
    });

prismWebDB.getCollection('users').aggregate(
    { '$group': { '_id': '$userName', 'count': { '$sum': 1 } } },
    { '$match': { '_id': { '$ne': null }, 'count': { '$gt': 1 } } },
    { '$sort': { 'count': -1 } },
    { '$project': { 'name': '$_id', '_id': 0 } },
    { $group: { '_id': null, 'duplicateNames': { $push: '$name' } } },
    { $project: { '_id': 0, 'duplicateNames': 1 } }
);

prismWebDB.getCollection('users')
    .find({ ldapDomainId: { $type: 'string' } })
    .forEach(function (user) {
        prismWebDB.getCollection('users').updateOne(
            { _id: user._id },
            { $set: { ldapDomainId: ObjectId(user.ldapDomainId) } },
            { upsert: true }
        );
    });
