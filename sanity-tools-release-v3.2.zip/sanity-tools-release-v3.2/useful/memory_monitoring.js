

var withAngStats = false;
var homepageTest = false;

(function () {
    var script = document.createElement('script');
    script.src = 'https://rawgit.com/paulirish/memory-stats.js/master/bookmarklet.js';
    document.head.appendChild(script);
})();
(function () {
    var script = document.createElement('script');
    script.onload = function () {
        var stats = new Stats();
        stats.showPanel(2);

        document.body.appendChild(stats.dom);
        requestAnimationFrame(function loop() {
            stats.update();
            requestAnimationFrame(loop);
        });
    };
    // noinspection SpellCheckingInspection
    script.src = '//rawgit.com/mrdoob/stats.js/master/build/stats.min.js';
    document.head.appendChild(script);
})();
if (withAngStats) {
    (function () {
        var a = document.createElement('script');
        a.src = 'https://rawgit.com/kentcdodds/ng-stats/master/dist/ng-stats.js';
        a.onload = function () {window.showAngularStats();};
        document.head.appendChild(a);
    })();
}

// noinspection SpellCheckingInspection
var testBoards = {
    empty: '5982e1a56e09ef28eca64967',
    onlyfilter: '598c371925a3ea49b0cadce7', // no leaks
    allwidgets: '598acbfa07e2cf36640bda22',
    allwidgetscopy: '59938797cb0f41399043e37d',
    allleaks: '598c875925a3ea49b0cae2a3',
    widgeteditor: '598c875925a3ea49b0cae2a3/widgets/598c875925a3ea49b0cae2a8',
    noleakwidgets: '598c5d8125a3ea49b0cae0ba',
    ltA: '5981fe7c6e09ef28eca6472b',
    ltB: '5981ffe36e09ef28eca647c3',
    ltC: '5984300de0f085547cad1eb6',
    testA: '5981fe7c6e09ef28eca6472b',
    testB: '5981ffe36e09ef28eca647c3',
    richtext: '59899823e7f30f2aa0faa7c0', // no leaks
    indicator: '5989983de7f30f2aa0faa7de', // no leaks
    areachart: '598ad2cd07e2cf36640bddcd',// no leaks
    barchart: '598ad41807e2cf36640bde32',// no leaks
    columnchart: '598ad3cf07e2cf36640bde00',// no leaks
    linechart: '598ad29707e2cf36640bdd9f', // no leaks
    polarchart: '598ad15107e2cf36640bdcaf', // no leaks
    areamap: '598ad22307e2cf36640bdd41',// no leaks
    pie: '598998fce7f30f2aa0faa85b', // no leaks
    map: '598998dae7f30f2aa0faa83d',// no leaks
    pivot: '598ad18307e2cf36640bdcdf', // no leaks
    scattermap: '598ad24207e2cf36640bdd6d', // no leaks
    calendar: '598998a6e7f30f2aa0faa81e',// no leaks
    sunburst: '598997eee7f30f2aa0faa7a0', // leaks
    treemap: '5989987fe7f30f2aa0faa7ff', // minor leaks + dom nodes leak
    table: '598ad1e407e2cf36640bdd0f' // leaks, huge dom tree leak
};

var prevMemInfo = {};

function runTest(num) {
    console.info('memleak: start loop!', ' | JS heap', performance.memory);
    prevMemInfo = performance.memory;
    var step = 0;
    var maxCount = num ? num : 30;
    var timeStep = 25000;
    var sampleA = 'testA';
    var sampleB = 'testB';
    var dashboardA = testBoards[sampleA];
    var dashboardB = testBoards[sampleB];
    var intA, intB;

    setTimeout(function () {
        var growthNum = performance.memory.usedJSHeapSize - prevMemInfo.usedJSHeapSize;
        var growthPercent = ((growthNum / prevMemInfo.usedJSHeapSize) * 100).toFixed(2);
        console.log('memleak: start 1', ' | growth: ', growthNum, ' | percent: ', growthPercent,
            ' | JS heap', performance.memory.usedJSHeapSize
        );
        prevMemInfo = performance.memory;
        intA = setInterval(function () {
            if (step > maxCount) {
                window.cleanIntervals();
            } else {
                step++;
                var growthNumberA = performance.memory.usedJSHeapSize - prevMemInfo.usedJSHeapSize;
                var growthPercentA = ((growthNumber / prevMemInfo.usedJSHeapSize) * 100).toFixed(2);
                console.log('memleak: ' + sampleA + ' step ', step, ' | growth: ', growthNumberA,
                    ' | percent: ', growthPercentA, ' | JS heap', performance.memory.usedJSHeapSize
                );
                prevMemInfo = performance.memory;
                window.location.href = window.location.origin + '/app/main#/dashboards/' +
                    dashboardA;
            }

        }, timeStep * 2);
    }, 0);

    setTimeout(function () {
        var growthNum = performance.memory.usedJSHeapSize - prevMemInfo.usedJSHeapSize;
        var growthPercent = ((growthNum / prevMemInfo.usedJSHeapSize) * 100).toFixed(2);
        console.log('memleak: start 2', ' | growth: ', growthNum, ' | percent: ', growthPercent,
            ' | JS heap', performance.memory.usedJSHeapSize
        );
        prevMemInfo = performance.memory;
        intB = setInterval(function () {
            if (step > maxCount) {
                window.cleanIntervals();
            } else {
                step++;
                var growthNumberB = performance.memory.usedJSHeapSize - prevMemInfo.usedJSHeapSize;
                var growthPercentB = ((growthNumberB / prevMemInfo.usedJSHeapSize) * 100).toFixed(2);
                var text = homepageTest ? 'homepage' : sampleB;
                console.log('memleak: ' + text + ' step ', step, ' | growth: ', growthNumberB,
                    ' | percent: ', growthPercentB, ' | JS heap', performance.memory.usedJSHeapSize
                );
                prevMemInfo = performance.memory;
                if (homepageTest) {
                    window.location.href = window.location.origin + '/app/main#/home';
                } else {
                    window.location.href = window.location.origin + '/app/main#/dashboards/' +
                        dashboardB;
                }

                //
            }

        }, timeStep * 2);
    }, timeStep);

    function cleanIntervals() {
        console.info('memleak: stopping loop!', ' | JS heap', performance.memory);
        clearInterval(intA);
        clearInterval(intB);
        console.log('memleak: test ended:', performance.memory);
    }

    window.cleanIntervals = cleanIntervals;
}

window.runTest = runTest;
runTest();
