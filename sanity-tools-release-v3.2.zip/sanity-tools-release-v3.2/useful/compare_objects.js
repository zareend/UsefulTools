function findDifferences(objectA, objectB) {
    var propertyChanges = [];
    var objectGraphPath = ['this'];
    (function (a, b) {
        var plainType = a.constructor !== Number &&
            a.constructor !== String &&
            a.constructor !== Boolean;
        var constructorFlag = a.constructor !== Date &&
            a.constructor !== RegExp && a.constructor !== Function;
        if (a.constructor === Array) {
            // BIG assumptions here: That both arrays are same length, that
            // the members of those arrays are _essentially_ the same, and
            // that those array members are in the same order...
            for (var i = 0; i < a.length; i++) {
                objectGraphPath.push('[' + i.toString() + ']');
                arguments.callee(a[i], b[i]);
                objectGraphPath.pop();
            }
        } else if (a.constructor === Object || (constructorFlag && plainType)) {
            // we can safely assume that the objects have the
            // same property lists, else why compare them?
            for (var property in a) {
                objectGraphPath.push(('.' + property));
                if (a.hasOwnProperty(property) && a[property]) {
                    if (a[property].constructor !== Function) {
                        arguments.callee(a[property], b[property]);
                    }
                    objectGraphPath.pop();
                }

            }
        } else if (a.constructor !== Function) { // filter out functions
            if (a !== b) {
                propertyChanges.push(
                    { 'property': objectGraphPath.join(''), 'objectA': a, 'objectB': b });
            }
        }
    })(objectA, objectB);
    return propertyChanges;
}

// noinspection SpellCheckingInspection
db.getCollection('widgets')
    .find(
        { oid: ObjectId('5b96aea52ab105264c2c9e0c'), userId: ObjectId('5c7dee459aedaa3f60c30f96') })
    .toArray()
    .forEach(function (widget, index, array) {
        if (index > 0) {
            var result = findDifferences(array[0], widget);
            print(JSON.stringify(result, undefined, 2));
        }
    });

/*
Output looks like this
[
  {
    "property": "this._id.str",
    "objectA": "5ca213d6b8b0dd4104a2da2c",
    "objectB": "5ca213d7f2b3dc1c38501933"
  },
  {
    "property": "this.title.desc.created",
    "objectA": "2019-04-01T13:36:22.396Z",
    "objectB": "2019-04-01T13:36:23.398Z"
  },
  {
    "property": "this.title.desc.lastUpdated",
    "objectA": "2019-04-01T13:36:22.396Z",
    "objectB": "2019-04-01T13:36:23.398Z"
  },
  {
    "property": "this.title.desc.lastUsed",
    "objectA": "2019-04-01T13:36:22.396Z",
    "objectB": "2019-04-01T13:36:23.398Z"
  }
]

 */
