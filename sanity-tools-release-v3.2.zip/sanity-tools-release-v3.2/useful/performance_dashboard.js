/*
Welcome to your Dashboard's Script.

To learn how you can access the Widget and Dashboard objects, see the online documentation at https://developer.sisense.com/pages/viewpage.action?pageId=557127
*/

function timeDiff(d1, d2) {
    var dateDiff = d2.getTime() - d1.getTime();
    var secDiff = dateDiff / (1000);
    var minDiff = dateDiff / (1000 * 60);
    var hourDiff = dateDiff / (1000 * 60 * 60);
    var milliseconds = dateDiff;
    var hh = Math.floor(milliseconds / 1000 / 60 / 60);
    milliseconds -= hh * 1000 * 60 * 60;
    var mm = Math.floor(milliseconds / 1000 / 60);
    milliseconds -= mm * 1000 * 60;
    var ss = Math.floor(milliseconds / 1000);
    milliseconds -= ss * 1000;
    if (hh < 10) {
        hh = '0' + hh;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    if (ss < 10) {
        ss = '0' + ss;
    }

    return {
        text: hh+':'+mm+':'+ss,
        milliseconds: milliseconds,
        seconds: secDiff > 0 ? secDiff : 0,
        minutes: minDiff > 0 ? minDiff : 0,
        hours: hourDiff > 0 ? hourDiff : 0
    };
}

var info = {
    dashboard: {
        oid: dashboard.oid,
        render: 0
    },
    widgets: []
};
var startTime, endTime;
dashboard.on('initialized', function (context, options) {
    console.log('d initialized');
    console.log(context, options);
    options.dashboard.widgets.$$widgets.forEach(function (widget) {
        var wData = {
            oid: widget.oid,
            render: 0,
            query: 0
        };
        var qStart, qEnd;
        var rStart, rEnd;

        widget.on('querystart', function () {
            console.log('w querystart');
            qStart = new Date();
        });
        widget.on('queryend', function () {
            console.log('w queryend');
            qEnd = new Date();

            var qTime = timeDiff(qStart, qEnd);
            wData.query = qTime.seconds;
        });
        widget.on('render', function (scope, args) {
            console.log('w initialized');
            console.log(scope, args);
            rStart = new Date();

        });
        widget.on('ready', function (scope, args) {
            console.log('w domready');
            console.log(scope, args);
            rEnd = new Date();

            var rTime = timeDiff(rStart, rEnd);
            wData.render = rTime.seconds;
        });

        widget.on('initialized', function (scope, args) {
            console.log('w initialized');
            console.log(scope, args);

        });
        widget.on('domready', function (scope, args) {
            console.log('w domready');
            console.log(scope, args);

        });



        info.widgets.push(wData);
    });
});

dashboard.on('refreshstart', function (scope, args) {
    console.log('refreshstart');

    startTime = new Date();
    console.log(scope, args);

});

dashboard.on('refreshend', function (scope, args) {
    endTime = new Date();
    console.log('refreshend');

    var execTime = timeDiff(startTime, endTime);
    console.log('Dashboard time: ' + execTime.seconds);
    info.dashboard.render = execTime.seconds;
    console.log(scope, args);
    console.log(info);
});

